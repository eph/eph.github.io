function [systemMatrix, RC] = sw_sysmat(para);


   %% names for parameters 
   gambar    = para(22);
   lbar      = para(21);
   pibar     = para(19);
   sigmac    = para(2);
   betin     = para(20);
   gam       = gambar/100 + 1;
   bet       = 1/(betin/100 + 1);
   pistar    = pibar/100 + 1;
   rbar      = 100*(bet^-1*gam^sigmac*pistar - 1);
  
   sigmaa = para(35);
   sigmab = para(36);
   sigmag = para(37);
   sigmai = para(38);
   sigmar = para(39);
   sigmap = para(40);
   sigmaw = para(41);
   
   npara  = 41;
   %% observation indices 
   eq_ygr = 1;
   eq_cgr = 2;
   eq_igr = 3;
   eq_wgr = 4;
   eq_lnh = 5;
   eq_pi  = 6;
   eq_r   = 7;
   
   %% variable indices 
   v_y    = 8;
   v_c    = 9;
   v_i    = 10;
   v_w    = 19;
   v_l    = 20;
   v_pi   = 17;
   v_r    = 21;
   v_ylag = 47;
   v_clag = 48;
   v_ilag = 49;
   v_wlag = 50;
   
   %% shock indices 
   e_g       = 1;
   e_b       = 2;
   e_ia      = 3;
   e_a       = 4;
   e_lp      = 5;
   e_lw      = 6;
   e_mp      = 7;
   
   [T1,TC,T0,RC,GAM0,GAM1,C,PSI] = sw_model(para,1);
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %% transition equations with augmentation       %%
   %% z(t) = T1*z(t-1) + T0*e(t)                   %%
   %% x(t) = [z(t)',...]'                          %%
   %%                                              %%
   %% x(t) = TT*x(t-1) + RR*e(t)                   %% 
   %% e(t) ~ iid N(0,QQ)                           %% 
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   [nz, ~]  = size(T1);
   [~, nep] = size(T0);
   %% augmentation %%
   
   TT = zeros(nz,nz);
   TT(1:nz, 1:nz) = T1;
   
   QQ = zeros(nep,nep);
   QQ(e_g,e_g  ) = sigmag^2;
   QQ(e_b,e_b  ) = sigmab^2;
   QQ(e_ia,e_ia) = sigmai^2;
   QQ(e_a,e_a  ) = sigmaa^2;
   QQ(e_lp,e_lp) = sigmap^2;
   QQ(e_lw,e_lw) = sigmaw^2;
   QQ(e_mp,e_mp) = sigmar^2;
   
   RR = T0;
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %% measurement equations                        %%
   %%                                              %%
   %% dlGDP  = gambar + y - y(-1)                  %%
   %% dlCONS = gambar + c - c(-1)                  %%
   %% dlINV  = gambar + i - i(-1)                  %%
   %% dlWAGE = gambar + w - w(-1)                  %%
   %% dlHOUR = lbar   + l                          %%
   %% INF    = pibar  + pi                         %%
   %% FEDFND = rbar   + r                          %%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   ny = 7;
   [npara, ~] = size(para);

   DD = zeros(ny,1);
   DD(eq_ygr,1) = gambar;
   DD(eq_cgr,1) = gambar;
   DD(eq_igr,1) = gambar;
   DD(eq_wgr,1) = gambar;
   DD(eq_lnh,1) = lbar;
   DD(eq_pi,1 ) = pibar;
   DD(eq_r,1 ) = rbar;

   DDD = zeros(ny,npara);
   DDD(eq_ygr,22) = 1;
   DDD(eq_cgr,22) = 1;
   DDD(eq_igr,22) = 1;
   DDD(eq_wgr,22) = 1;
   DDD(eq_lnh,21) = 1;
   DDD(eq_pi,19)  = 1;
   DDD(eq_r,20)   = (gambar/100+1)^sigmac*(pibar/100+1);
   DDD(eq_r,22)   = (betin/100+1)*(gambar/100+1)^(sigmac-1)*(pibar/100+1)*sigmac;
   DDD(eq_r,19)   = (betin/100+1)*(gambar/100+1)^sigmac;
   DDD(eq_r,2 )   = 100*(betin/100+1)*log(gambar/100+1)*(gambar/100+1)^sigmac*(pibar/100+1);

   ZZ = zeros(ny,nz);
   ZZ(eq_ygr,v_y   ) =  1;
   ZZ(eq_ygr,v_ylag) = -1;
   ZZ(eq_cgr,v_c   ) =  1;
   ZZ(eq_cgr,v_clag) = -1;
   ZZ(eq_igr,v_i   ) =  1;
   ZZ(eq_igr,v_ilag) = -1;
   ZZ(eq_wgr,v_w   ) =  1;
   ZZ(eq_wgr,v_wlag) = -1;
   ZZ(eq_lnh,v_l   ) =  1;
   ZZ(eq_pi,v_pi   ) =  1;
   ZZ(eq_r,v_r     ) =  1;
     
   HH = zeros(ny,ny);
   VV = zeros(nep,ny);

   %% pack matrices into structure
   systemMatrix.TT = TT;
   systemMatrix.RR = RR;
   systemMatrix.QQ = QQ;
   systemMatrix.VV = VV;
   systemMatrix.ZZ = ZZ;
   systemMatrix.DD = DD;
   systemMatrix.HH = HH;
   systemMatrix.GAM0 = GAM0;
   systemMatrix.GAM1 = GAM1;
   systemMatrix.PSI = PSI;
   systemMatrix.C = C;
end
   