function in = inbounds(x)

in1 = x(1) < 1 & x(1) > 0;
in2 = x(2) < 1 & x(2) > 0;

in = in1 * in2;

end