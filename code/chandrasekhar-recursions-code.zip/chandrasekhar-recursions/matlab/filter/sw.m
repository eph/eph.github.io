% file: sw.m
% 
%  function: kf(y, TT, RR, QQ, DD, ZZ, HH, t0) 
% 
%  Evaluates the log-likelihood of stationary LGSS model using the
%  (2) Block Kalman Filter -- Strid and Walentin (2009). 
%    s_t = TT*s_{t-1} + RR*eps_t,  eps_t ~ iidN(0, QQ)
%    y_t = DD + ZZ*s_t + eta_t, eta_t ~ iidN(0, HH)
% 
%  y should be nobs x ny, that is, each row corresponding to a time period. 
%
%  With TT is block lower triangular, with the left most block
%  being diagonal.  ZZ should have a leading matrix of zeros
%  corresponding to upper TT block.
%
%  The state is initialized from the stationary distribution.
%
%  t0 is the number of initial observations to condition on.
%
%  Returns:
%    loglh -- the log likelihood (scalar).
%
%
% Implemented by Ed Herbst <edward.p.herbst@frb.gov>
%------------------------------------------------------------------------------- 
function loglh = sw(y, TT, RR, QQ, DD, ZZ, HH, t0)

    Pt = dlyap(TT, RR*QQ*RR');
%Pt = lyapunov_symm(TT, RR*QQ*RR', 1, 1e-6);
    [ns, ~] = size(Pt);
    % just call their code
    [loglh, ~] = kf2(ZZ, DD, HH, TT, zeros(ns, 1), RR, QQ, Pt, ...
                     zeros(ns, 1), y', t0, RR*QQ*RR');
   
% $$$     [nobs, ny] = size(y);
% $$$ 
% $$$     [ns, ~] = size(TT);
% $$$     nendo = ns - nexo;
% $$$ 
% $$$     A = TT(1:nexo, 1:nexo);
% $$$     B = TT(nexo+1:ns, 1:nexo)*inv(A);
% $$$     C = TT(nexo+1:ns, nexo+1:ns);
% $$$ 
% $$$     At1 = zeros(nexo, 1);
% $$$     At2 = zeros(nendo, 1);
% $$$     
% $$$     Pt = P0;
% $$$     P11 = Pt(1:nexo, 1:nexo);
% $$$     P12 = Pt(1:nexo, nexo+1:ns);
% $$$     P22 = Pt(nexo+1:ns, nexo+1:ns);
% $$$     Z2 = ZZ(:, nexo+1:end);
% $$$     loglh = 0;
% $$$     for i = 1:nobs
% $$$ 
% $$$         % prediction
% $$$         diagA = diag(A);
% $$$         P11 = P11.*(A*A') + QQ;
% $$$         Lt = (P12*C').*(diagA*ones(1, nendo));
% $$$ 
% $$$         P12 = P11*B' + Lt;
% $$$         P22 = B*P12 + B*Lt + (B*Lt)' + C*P22*C';
% $$$         
% $$$         At1 = diagA.*At1;
% $$$         At2 = B*At1 + C*At2;
% $$$         
% $$$         yhat = Z2*At2 + DD;
% $$$         nut = y(i, :) - yhat';
% $$$         
% $$$         Ft = Z2*P22*Z2' + HH;
% $$$         iFt = inv(Ft);
% $$$         dFt = det(Ft);
% $$$         
% $$$         loglh = loglh - 0.5*ny*log(2*pi) - 0.5*log(dFt) - 0.5*nut*iFt*nut';
% $$$         
% $$$         % updating
% $$$         At1 = At1 + P12*Z2'*iFt*nut';
% $$$         At2 = At2 + P22*Z2'*iFt*nut';
% $$$         
% $$$         P11 = P11 - P12*Z2'*iFt*Z2*P12';
% $$$         P12 = P12 - P12*Z2'*iFt*Z2*P22;
% $$$         P22 = P22 - P22*Z2'*iFt*Z2*P22;
% $$$     end
    
end