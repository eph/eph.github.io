function [lnpost, lnpY, lnprio] = objfcn_dsge(para, phi_smc, prio, bounds, data)
% objfcn_dsge
%  - phi_smc is tempering parameter
%  - evaluates "TEMPERED" posterior density given parameter bounds
%
%  - Author: Minsu Chang (minsuc@sas.upenn.edu)
%  - Last modified : 3/5/2016

% recover prior information
pshape   = prio(:,1);
pmean    = prio(:,2);
pstdd    = prio(:,3);
pmask    = prio(:,4);
pfix     = prio(:,5);
pmaskinv = 1- pmask;
pshape   = pshape.*pmaskinv;

% check bounds

parabd_ind1 = para > bounds(:,1); % lower bounds
parabd_ind2 = para < bounds(:,2); % upper bounds
parabd_ind1 = parabd_ind1(logical(pmaskinv));
parabd_ind2 = parabd_ind2(logical(pmaskinv));

% 
modelpara = para;

if and(parabd_ind1 == 1, parabd_ind2 == 1) % in bounds
    
   [T1, ~, T0, ~, GEV, ~] = model_solution(modelpara);
   
   if GEV(2) == 1
   [A,B,H,R,Se,Phi] = sysmat(T1,T0,modelpara);
%    liki = kalman(A,B,H,R,Se,Phi,data);
    liki = kalman2(A,B,H,R,Se,Phi,data);
    lnpY = sum(liki);
    
   else
       
    lnpY = -inf;
   
   end
    
    % evaluate the prior distribution
    lnprio = priodens(modelpara, pmean, pstdd, pshape);
    
    % log posterior
    lnpost = (phi_smc*lnpY + lnprio);
    
    
else % if parameter proposal is out of bounds

    lnpost  = -inf;
    lnpY    = -inf;
    lnprio = -inf;
	
end
