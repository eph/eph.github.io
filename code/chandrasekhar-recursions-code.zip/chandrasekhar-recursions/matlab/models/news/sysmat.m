function [system_matrix, RC] = sysmat (para)

  %% usage:  ~ = news_big_sysmat (para, msel, calc_grad, calc_hess, psel = [])
  %%
  %% 

  %% set calibrated parameters -- not the optimal way of doing things
  rhoxg = para(6)*0.99;

  alpk  = para(14);
  alph  = para(15);
  del0	= para(16);
  bet	= para(17);
  hss	= para(18);
  muss	= para(19);
  muass = para(20);
  muxss = para(21);
  sig	= para(22);
  g_y	= para(23);

  %% find steady states, et cetera 
  mukss = muass^(1/(alpk-1))*muxss;	% steady state growth for captial
  muyss = muass^(alpk/(alpk-1))*muxss;	% steady state output growth rate

  [T1, TC, T0, VSEL, RC, GAM0, GAM1, C, PSI] = news_big_model (para);

  [~, nep] = size(T0);
  ny  = 7;
  [ns, ~]  = size(T1);
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% Transition Equations                          %%
  %%                                               %%
  %% x(t) = TT*x(t-1) + RR*e(t)                    %%
  %% e(t) ~ iid N(0,QQ)                            %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  TT = T1;
  RR = T0;
  QQ = diag ((para(24:44)./100).^2 );

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% Measurement Equations                         %%
  %%                                               %%
  %% y(t) = DD + ZZ*x(t) + u(t)                    %%
  %% u(t) ~ iid N(0,HH)                            %%
  %% cov(e(t),u(t)) = VV                           %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  eq_ygr = 1;
  eq_cgr = 2;
  eq_igr = 3;
  eq_hgr = 4;
  eq_ggr = 5;
  eq_agr = 6;
  eq_tfp = 7;

  v_muy    = 1;
  v_muk    = 2;
  v_xg	   = 3;
  v_mua    = 4;
  v_mua8_1 = 5;
  v_mua8_2 = 6;
  v_mua8_3 = 7;
  v_mua8_4 = 8;
  v_mua8_5 = 9;
  v_mua8_6 = 10;
  v_mua8_7 = 11;
  v_mua8_8 = 12;
  v_mux    = 13;
  v_mux8_1 = 14;
  v_mux8_2 = 15;
  v_mux8_3 = 16;
  v_mux8_4 = 17;
  v_mux8_5 = 18;
  v_mux8_6 = 19;
  v_mux8_7 = 20;
  v_mux8_8 = 21;
  v_zi	   = 22;
  v_zi8_1  = 23;
  v_zi8_2  = 24;
  v_zi8_3  = 25;
  v_zi8_4  = 26;
  v_zi8_5  = 27;
  v_zi8_6  = 28;
  v_zi8_7  = 29;
  v_zi8_8  = 30;
  v_z	   = 31;
  v_z8_1   = 32;
  v_z8_2   = 33;
  v_z8_3   = 34;
  v_z8_4   = 35;
  v_z8_5   = 36;
  v_z8_6   = 37;
  v_z8_7   = 38;
  v_z8_8   = 39;
  v_mu	   = 40;
  v_mu8_1  = 41;
  v_mu8_2  = 42;
  v_mu8_3  = 43;
  v_mu8_4  = 44;
  v_mu8_5  = 45;
  v_mu8_6  = 46;
  v_mu8_7  = 47;
  v_mu8_8  = 48;
  v_g	   = 49;
  v_g8_1   = 50;
  v_g8_2   = 51;
  v_g8_3   = 52;
  v_g8_4   = 53;
  v_g8_5   = 54;
  v_g8_6   = 55;
  v_g8_7   = 56;
  v_g8_8   = 57;
  v_zet    = 58;
  v_zet8_1 = 59;
  v_zet8_2 = 60;
  v_zet8_3 = 61;
  v_zet8_4 = 62;
  v_zet8_5 = 63;
  v_zet8_6 = 64;
  v_zet8_7 = 65;
  v_zet8_8 = 66;
  v_glag   = 67;
  v_xglag  = 68;
  v_zlag   = 69;
  v_k1	   = 70;
  v_u	   = 71;
  v_i	   = 72;
  v_c	   = 73;
  v_y	   = 74;
  v_s	   = 75;
  v_h	   = 76;
  v_p	   = 77;
  v_q	   = 78;
  v_v	   = 79;
  v_lam    = 80;
  v_ylag   = 81;
  v_clag   = 82;
  v_ilag   = 83;
  v_hlag   = 84;
  v_Elam   = 85;
  v_Emuy   = 86;
  v_Emuk   = 87;
  v_Ei	   = 88;
  v_Eu	   = 89;
  v_Ez	   = 90;
  v_Eh	   = 91;
  v_Emua   = 92;
  v_Eq	   = 93;
  v_Ep	   = 94;
  v_Es	   = 95;
  v_Ezet   = 96;
  v_Ec	   = 97;
  v_Ev	   = 98;

  DD = zeros(ny,1);
  DD(eq_ygr) = 100*log(muyss);
  DD(eq_cgr) = 100*log(muyss);
  DD(eq_igr) = 100*log(muyss);
  DD(eq_ggr) = 100*log(muyss);
  DD(eq_agr) = 100*log(muass);
  DD(eq_tfp) = 100*(1-alpk)*log(muxss);

  ZZ = zeros(ny,ns);
  ZZ(eq_ygr, v_y)    =  100;
  ZZ(eq_ygr, v_ylag) = -100;
  ZZ(eq_ygr, v_muy)  =  100;
  
  ZZ(eq_cgr, v_c)    =  100;
  ZZ(eq_cgr, v_clag) = -100;
  ZZ(eq_cgr, v_muy)  =  100;
  
  ZZ(eq_igr, v_i)    =  100;
  ZZ(eq_igr, v_ilag) = -100;
  ZZ(eq_igr, v_muy)  =  100;
  
  ZZ(eq_hgr, v_h)    =  100;
  ZZ(eq_hgr, v_hlag) = -100;

  ZZ(eq_ggr, v_g)    =  100;
  ZZ(eq_ggr, v_glag) = -100;
  ZZ(eq_ggr, v_muy)  =  100;
  ZZ(eq_ggr, v_xg)   =  100;
  ZZ(eq_ggr, v_xglag)= -100;

  ZZ(eq_agr, v_mua)  =  100;
  
  ZZ(eq_tfp, v_z)    =  100;
  ZZ(eq_tfp, v_zlag) = -100;
  ZZ(eq_tfp, v_mux)  =  100*(1-alpk);


  HH = zeros(ny,ny);
  HH(eq_ygr,eq_ygr) = para(45)^2;
  
  VV = zeros(ny,ns);

  %packfields ("system_matrix", "TT", "RR", "QQ", "VV", "HH", "DD", "ZZ");
  system_matrix.TT = TT;
  system_matrix.RR = RR;
  system_matrix.QQ = QQ;
  
  system_matrix.VV = VV;
  system_matrix.HH = HH;
  system_matrix.DD = DD;
  system_matrix.ZZ = ZZ;
end