function pos = eph_lnpy(Y, p0);

global epshape epmean epstdd epfix

[sm, RC] = sysmat(p0);

temp = sm.ZZ(6, :);                     
sm.ZZ(6, :) = sm.ZZ(7, :);
sm.ZZ(7, :) = temp;                     

pos = log_like_kalman(Y, real(sm.TT), real(sm.RR*sm.QQ*sm.RR'), sm.ZZ', sm.HH);

[sigy, sigx] = mom(sm.ZZ/100, sm.TT, 10000*sm.RR*sm.QQ*sm.RR');

sigy(1, 1) = sigy(1, 1) + p0(end)^2;

pri = priodens(p0, epmean, epstdd, epshape);
pos = pos;% + pri;
eph_sigy = sqrt(diag(sigy));
eph_cory = sigy(:, 1) ./ (eph_sigy * eph_sigy(1));
[eph_sigy, eph_cory]

end