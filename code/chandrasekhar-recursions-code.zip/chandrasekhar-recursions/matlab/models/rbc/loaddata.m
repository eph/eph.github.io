y = load('yh2.txt');
y = y(1:80, :);