%MODEL.M
%[fx,fxp,fy,fyp,f, statevar_cu,controlvar_cu, varshock, varme, ETASHOCK, approx] = model;
%computes a log-linear approximation to the  function f, which defines  the DSGE model: 
%  E_t f(yp,y,xp,x) =0. 
%here, a p denotes next-period variables.  
%
%Output: Analytical expressions for f and its first derivatives as well as x and y
%
%Calls: anal_deriv.m
%
%(c) Stephanie Schmitt-Grohe and Martin Uribe
%
%Date November 2009
function [fx,fxp,fy,fyp,f, statevar_cu,controlvar_cu, varshock, varme, ETASHOCK, approx] = model;


%******************
%Create anticipated-shocks block
%********************

%Type of shocks considered
SHOCK = {'z'; 'mua'; 'g'; 'mux'; 'muw'; 'zetta'; 'ziv'}; 

 %Anticipation horizons considered (quarters)
ah = [ 4 8];
ahz = ah;
ahmua = ah;
ahg = ah;
ahmux = ah;
ahmuw = ah;
ahzetta = ah;
ahziv = ah;

for jshock = 1:length(SHOCK)
shock = SHOCK{jshock};
eval(['anticipation_horizons{' num2str(jshock) '}= ah' shock ';']);
end 

%Indicate whether serial correlations for a given shock at different horizons are the same or not
same_serial_correlations = 1; %(1 if same, 0 if different)
 

%run create_anticipated_shocks.m to obtain EQ, exogenous_state, exogenous_statep, and Shockshock for shock=z,mua,mux,g, innovations, STDinnovations all of which are used below

create_anticipated_shocks;


%End of construction of  anticipated-shocks block
%******************************************

iv = []; zp=[];

syms SIG THETA GAMA DELTA0 DELTA1 DELTA2 KAPA ALFAK ALFAL BETTA MUX MUY MUA MUK RHOmux RHOmua RHOz RHOziv  RHOzetta  RHOg  RHOXG Y SC G PSSI B RHOmuw MUW IHF

syms gtfp gtfpp vvback vvbackp zback zbackp vv vvp gv gvp 

syms c cp cb cbp v vp stock stockp pai paip muy muyp  u up xi xip iv ivp ivb ivbp muk mukp k kp y yb g gp gb gbp h hp hb hbp gh ghp z zp zetta zettap la lap q qp mua muap mux muxp gy gyp gc gcp gg ggp giv givp  xg xgp muw muwp   ziv zivp

syms  STDmey STDmec STDmeiv STDmeg STDmetfp STDmesp STDmew STDmeh STDmea

%Give functional form for  production, and utility functions

%Depreciation rate
delta = DELTA0 + DELTA1 * (u-1) + DELTA2/2*(u-1)^2; 

deltap = DELTA0 + DELTA1 * (up-1) + DELTA2/2*(up-1)^2; 

%Investment adjustment cost
s = KAPA/2 * (xi - MUK)^2;
sp = KAPA/2 * (xip - MUK)^2;
xi = iv * muk / ivb;
xip = ivp * mukp / iv;

%wage rate
w =  z * (1-ALFAK-ALFAL) * (u*k/muk/h)^ALFAK * h^(-ALFAL); 


%Equilibrium conditions

%Evolution of capital
e1 = -kp + (1-delta)*k/muk + ziv *  iv * (1-s);

%Resource constraint
e2 = -y + c + iv + g * xgp;

%Production technology
e3 = -y + z * (u*k/muk)^ALFAK * h^(1-ALFAK-ALFAL); 

%Optimality conditions w.r.t. consumption
e4 = -la + zetta * v^(-SIG) - pai * GAMA * stockp / (c-B*cb/muy) - B*BETTA* IHF *muyp^(-SIG) * (zettap*vp^(-SIG) - paip * GAMA * (stockp / muyp/ (cp-B*c/muyp))^(1-GAMA));

%argument of period utility function
e5 =  -v + (c-B*cb/muy) - PSSI*h^THETA* stockp; 

%Optimality conditions w.r.t. leisure
e6 = THETA * PSSI * zetta * v^(-SIG) * h^(THETA-1) * stockp - la * w / muw;

%Evolution of the shadow price of s_t 
e7 =  -pai + PSSI * zetta * v^(-SIG) * h^THETA + BETTA * (1-GAMA) * paip * muyp^(1-SIG) * ((cp-B*c/muyp) /stockp)^GAMA * muyp^(GAMA-1);

%Law of motion of s_t
e8 =  -stockp + (c-B*cb/muy)^GAMA*(stock/muy)^(1-GAMA);

%Euler eq'n for capital
e9 = -q*la + BETTA * muap * muyp^(-SIG) * lap * (zp * up * ALFAK * (up*kp/mukp/hp)^(ALFAK-1) * hp^(-ALFAL) + qp * (1-deltap));

%FOC w.r.t. u
e10   = -q * diff(delta,'u') + z* ALFAK * (u*k/muk/h)^(ALFAK-1)*h^(-ALFAL);

%FOC w.r.t. investment
e11 = -la + q*la * ziv * (1-s-xi*diff(s,'xi')) + BETTA * muap*muyp^(-SIG) * qp * lap * zivp *  xip^2 * diff(sp,'xip');

%GDP-trend gross growth rate
e12 = -muy+mua^(ALFAK/(ALFAK-1))*mux;

%Capital-trend gross growth rate
e13 = -muk + mua^(1/(ALFAK-1))* mux;

%Output Growth
e14 = -gy + y * muy / yb;

%Consumption Growth
e15 = -gc + c * muy / cb;

%Investment Growth
e16 = -giv + iv * muy / ivb;

%Government Spending Growth
e17 = -gg + g / gb * xg^(RHOXG-1);

%Driving processes
e19 = [-log(zp) + RHOz * log(z) + ANTICIPz;
-log(zivp) + RHOziv * log(ziv) +  ANTICIPziv];


e20 = -log(muap/MUA) + RHOmua * log(mua/MUA) +  ANTICIPmua;

e21 = -log(gp/G) + RHOg * log(g/G) +  ANTICIPg;

e22 = -log(muxp/MUX)  + RHOmux * log(mux/MUX) +  ANTICIPmux;

e23 = -log(muwp/MUW) + RHOmuw * log(muw/MUW) +  ANTICIPmuw;

e24 = -log(zettap) + RHOzetta * log(zetta) +  ANTICIPzetta;


%Law of motion of trend in government spending
e25 = -xgp + xg^RHOXG / muy;

% Link ba_1 with cu
e26 =  [-ivbp + iv;  
        -hbp + h;
        -cbp + c;
        -gbp + g];


%Beginning-of-period value of the firm
e28 = - vv + y - w * h - iv + BETTA * lap / la * muyp^(1-SIG) * vvp;

% Add growth rates of Q, Q^a, Q^e, V, V^e, TFP
%
e30 = [ -gv+vv/vvback*muy;
-vvbackp+ vv;
-gtfp + z/zback * mux^(1-ALFAK);
-zbackp + z;
];

%Law of motion of anticipated components (EQ is created by running create_anticipated_shocks.m
e31 = EQ;

% Growth rate of hours
e32 = -gh + h / hb;

%Create function f
f = eval(eval([e1;e2;e3;e4;e5;e6;e7;e8;e9;e10;e11;e12;e13;e14;e15;e16;e17;e19;e20;e21;e22;e23;e24;e25;e26;e28; e30;e31;e32]));

% Define the vector of controls in periods t and t+1, controlvar_cu and controlvar_cup, and the vector of states in periods t and t+1, statevar_cu and statevar_cup


%States to substitute from levels to logs
states_in_logs = [stock xg cb gb hb ivb yb vvback zback  k z mua g mux muw zetta ziv];

statevar_cu = [transpose(EPS)  states_in_logs];

states_in_logsp = [stockp xgp cbp gbp hbp ivbp y   vvbackp zbackp   kp  zp muap gp muxp muwp zettap zivp];

statevar_cup = [transpose(EPSp) states_in_logsp];
 
controlvar_cu = [gy gc giv gh gg gtfp gv    c iv la muk muy q u pai v vv  h]; 

controlvar_cup = [gyp gcp givp ghp ggp gtfpp gvp    cp ivp lap mukp muyp qp up paip vp vvp  hp];

%Number of states
ns = length(statevar_cu);

%Make f a function of the logarithm of the state and control vector

%variables to substitute from levels to logs
variables_in_logs = transpose([states_in_logs, controlvar_cu, states_in_logsp, controlvar_cup]);

f = subs(f, variables_in_logs, exp(variables_in_logs));

approx = 1;

%Compute analytical derivatives of f
[fx,fxp,fy,fyp]=anal_deriv(f,statevar_cu,controlvar_cu,statevar_cup,controlvar_cup,approx);

%Make f and its derivatives a function of the level of its arguments rather than the log
f = subs(f, variables_in_logs, log(variables_in_logs));
fx = subs(fx, variables_in_logs, log(variables_in_logs));
fy = subs(fy, variables_in_logs, log(variables_in_logs));
fxp = subs(fxp, variables_in_logs, log(variables_in_logs));
fyp = subs(fyp, variables_in_logs, log(variables_in_logs));

%Eliminate future variables
cu = transpose([statevar_cu controlvar_cu c g h iv vv z]);
cup = transpose([statevar_cup controlvar_cup cb gb hb ivb vvback zback]);


for subcb=1:2 %we have to do it twice because in the first round cbp is replaced by cb and in the second round the remaining  occurrences of cb is replaced by c
f = subs(f, cup,cu,0);
fx = subs(fx, cup,cu,0);
fy = subs(fy, cup,cu,0);
fxp = subs(fxp, cup,cu,0);
fyp = subs(fyp, cup,cu,0);
end

%Set exogenous_state and exogenous_statep to zero
f = subs(f, [EPS;EPSp],0*[EPS;EPSp],0);

%Construct ETASHOCK matrix, which determines the var/cov of the forcing term of the system. The symbolic vectors innovations and STDinnovations were created by create_anticipated_shocks.m
ni = length(innovations);

for j=1:ni
ETASHOCK(find(statevar_cu==innovations(j)),j) = STDinnovations(j);
end

if size(ETASHOCK,1)<ns
ETASHOCK(ns,ni) = 0;
end

varshock = ETASHOCK*ETASHOCK';

%Var/Cov matrix of measurement errors
varme = diag([STDmey; STDmec; STDmeiv; STDmeh; STDmeg; STDmetfp; STDmea].^2); 

%Print derivatives to file `model_num_eval.m'  for model evaluation
filename = 'model';
anal_deriv_print2f_1st(filename,fx,fxp,fy,fyp,f,ETASHOCK,varme);


save model.mat