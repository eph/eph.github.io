%%% fig_news_hours_decomp.m --- 
%% 
%% Description: Plots the decomposition of hours in anticipated and
%%   unanticipated components.
%% 
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 05/31/13
%% 
rwmh = {'/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial1/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial2/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial3/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial4/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial5/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial6/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial7/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial8/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial9/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial10/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial11/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial12/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial13/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial14/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial15/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial16/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial17/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial18/vdcmp.txt', ...        
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial19/vdcmp.txt', ...
        '/mq/scratch/m1eph00/dsge-smc/draft-2/news/rwmh/standard/rwmh-news-new-nsim-10000000-nblocks-1-trial20/vdcmp.txt', ...        
       }

smc = {'/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial1-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial2-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial3-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial4-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial5-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial6-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial7-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial8-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial9-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial10-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial11-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial12-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial13-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial14-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial15-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial16-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial17-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial18-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial19-phibend/500vdcmp.txt', ...
       '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial20-phibend/500vdcmp.txt'};


prior = '/mq/scratch/m1eph00/dsge-smc/draft-1/smc-news-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial3-phibend/001vdcmp.txt';
 
vsel = 4;
with_prior = 1;

clf
hold on

flat_vsel = vsel(:);

labels = {'Output Growth', 'Consumption Growth', 'Investment Growth', 'Hours'};

antind = [2+0:3:21, 3+0:3:21];
unaind = [1:3:19];

grid = linspace(0, 1, 11);
ngrid = length(grid);
bin = zeros(ngrid-1, 1);
for j = 1:length(flat_vsel)

    subplot(size(vsel, 1), size(vsel, 2),  j);
    vind = flat_vsel(j);
    
    prvar = load(prior);
    prior_hours = zeros(size(prvar, 1), 2);

    for i = 1:size(prvar, 1)
        temp = reshape(prvar(i, :), 7, [])';

        prior_hours(i, 1) = sum(temp(antind, vind));
        prior_hours(i, 2) = sum(temp(unaind, vind));
        
    end
    prbin = zeros(1, length(bin));
    for i = 1:ngrid-1
        
        in_interval = grid(i) < prior_hours(:, 1) & prior_hours(:, 1) <= grid(i+1);
        prbin(1, i) = mean(double(in_interval));

    end
    
    %    [f0, x0] = ksdensity(prior_hours(:, 1), 'support', [0, 1]); 

    %if with_prior
    %    line(x0, f0, 'Color', 'Blue', 'LineWidth', 5)
    %end 
    rwmhgrid = zeros(length(rwmh), length(bin));
    for ii = 1:length(rwmh)

        rwvar = load(rwmh{ii});
        rwmh_hours = zeros(size(rwvar, 1), 2);

        for i = 1:size(rwvar, 1)
            temp = reshape(rwvar(i, :), 7, [])';

            rwmh_hours(i, 1) = sum(temp(antind, vind));
            rwmh_hours(i, 2) = sum(temp(unaind, vind));
        end

        for i = 1:ngrid-1
            in_interval = grid(i) < rwmh_hours(:, 1) & rwmh_hours(:, 1) <= grid(i+1);
            rwmhgrid(ii, i) = mean(double(in_interval));
        end

        %[f0, x0] = ksdensity(rwmh_hours(:, 1), 'support', [0, 1]); 
        %line(x0, f0, 'Color', 'Black', 'LineWidth', 5)
    end

    smcgrid = zeros(length(smc), length(bin));
    
    for ii = 1:length(smc);
        smcvar = load(smc{ii});

        smc_hours = zeros(size(smcvar, 1), 2);

        for i = 1:size(smcvar, 1)
            temp = reshape(smcvar(i, :), 7, [])';

            smc_hours(i, 1) = sum(temp(antind', vind));
            smc_hours(i, 2) = sum(temp(unaind', vind));
        end

        for i = 1:ngrid-1
            in_interval = grid(i) < smc_hours(:, 1) & smc_hours(:, 1) <= grid(i+1);
            smcgrid(ii, i) = mean(double(in_interval));
        end

        %        [f1, x1] = ksdensity(smc_hours(:, 1), 'support', [0, 1]);  

        %line(x1, f1, 'Color', 'Red', 'LineWidth', 5)
    end

    title(labels{vind})
end

x0 = 0;
rwmhmu = mean(rwmhgrid);
rwmhsig = std(rwmhgrid);
smcmu = mean(smcgrid);
smcsig = std(smcgrid);

line([0 grid(3:end-1)-0.05 1], prbin', 'LineWidth', 5)
for i = 1:length(bin)
   
    colspec = {'Facecolor', 'Black', 'EdgeColor', 'Black'};
    
    mul = rwmhmu(i) - 2*rwmhsig(i);
    height = 4*rwmhsig(i);
    if (height == 0), height = 1e-6; end
    rpos = [x0, mul, (grid(i+1)-grid(i))/2, height];
    rectangle('Position', rpos, colspec{:});

    x0 = x0 + 0.05;
    

    colspec = {'Facecolor', 'Red', 'EdgeColor', 'Black'};
    
    mul = smcmu(i) - 2*smcsig(i);
    height = 4*smcsig(i);
    if (height == 0), height = 1e-6; end
    rpos = [x0, mul, (grid(i+1)-grid(i))/2, height];
    rectangle('Position', rpos, colspec{:});

    x0 = x0 + 0.05;
end

axis([0 1 0 1])
