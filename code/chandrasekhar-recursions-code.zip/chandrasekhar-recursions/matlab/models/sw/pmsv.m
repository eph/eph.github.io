function pmsv = pmsv(msel);

   % these starting values come from SW dynare file ##
   varphi = 6.3325;
   sigmac = 1.2312;
   h      = 0.7205;
   lamw   = 1.5000;
   xiw    = 0.7937;
   epsw   = 10.000;
   sigmal = 2.8401;
   del    = 0.0250;
   xip    = 0.7813;
   epsp   = 10.000;
   iotaw  = 0.4425;
   iotap  = 0.3291;
   ppsi   = 0.2648;
   capphi = 1.4672;
   rpi    = 1.7985;
   rho    = 0.8258;
   ry     = 0.0893;
   rdely  = 0.2239;
   pibar  = 0.7000;
   betin  = 0.7420;
   lbar   = 0;
   gambar = 0.3982;
   alp    = 0.2400;
   g_y    = 0.1800;

   rhoa   = 0.9676;
   rhob   = 0.2703;
   rhog   = 0.9930;
   rhoi   = 0.5724;
   rhor   = 0.3000;
   rhop   = 0.8692;
   rhow   = 0.9546;

   mup    = 0;0.7652;
   muw	  = 0;0.8936;
   rhoga  = 0;0.0500;

   sigmaa = 0.4618;
   sigmab = 0.1818;
   sigmag = 0.6090;
   sigmai = 0.4601;
   sigmar = 0.2397;
   sigmap = 0.1455;
   sigmaw = 0.2089;

   pmsv = [varphi;sigmac;h;lamw;xiw;epsw;sigmal;del;xip;epsp;iotaw;
	 iotap;ppsi;capphi;rpi;rho;ry;rdely;pibar;betin;lbar;gambar;
	 alp;g_y;rhoa;rhob;rhog;rhoi;rhor;rhop;rhow;mup;muw;rhoga;
	 sigmaa;sigmab;sigmag;sigmai;sigmar;sigmap;sigmaw];
   
end