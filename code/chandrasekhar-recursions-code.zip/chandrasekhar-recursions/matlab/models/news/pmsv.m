function para = pmsv()

   thet      = 4.74; 
   gam       = 0.05; 
   kap       = 9.11; 
   del2_del1 = 0.34; 
   b         = 0.91; 
   rhoxg     = 0.72; 
   rhoz      = 0.92; 
   rhoa      = 0.48; 
   rhog      = 0.96; 
   rhox      = 0.38; 
   rhom      = 0.98; 
   rhozet    = 0.17; 
   rhozi     = 0.47; 
   alpk      = 0.225;
   alph      = 0.675;
   del0      = 0.025;
   bet       = 0.99;
   hss       = 0.20;
   muss      = 0.15;
   muass     = 0.9957;
   muxss     = 1.00324407709013;
   sig       = 1;
   g_y       = 0.2;
   sigmua0   = 0.21; 
   sigmua4   = 0.16; 
   sigmua8   = 0.16; 
   sigmux0   = 0.38; 
   sigmux4   = 0.08; 
   sigmux8   = 0.10; 
   sigzi0    = 11.7; 
   sigzi4    = 1.93; 
   sigzi8    = 5.50; 
   sigz0     = 0.65; 
   sigz4     = 0.11; 
   sigz8     = 0.09; 
   sigmu0    = 0.50; 
   sigmu4    = 4.79; 
   sigmu8    = 0.51; 
   sigg0     = 0.62; 
   sigg4     = 0.57; 
   sigg8     = 0.37; 
   sigzet0   = 4.03; 
   sigzet4   = 1.89; 
   sigzet8   = 2.21; 
   sigygr    = 0.29; 

   para = [thet; gam; kap; del2_del1; b; rhoxg; rhoz; rhoa; rhog; rhox; rhom;
           rhozet; rhozi; alpk; alph; del0; bet; hss; muss; muass; 
           muxss; sig; g_y;sigmua0; sigmua4; sigmua8; sigmux0; sigmux4; sigmux8;
           sigzi0; sigzi4; sigzi8; sigz0; sigz4; sigz8; sigmu0; sigmu4; sigmu8;
           sigg0; sigg4; sigg8; sigzet0; sigzet4; sigzet8; sigygr];
   
   
   
end
