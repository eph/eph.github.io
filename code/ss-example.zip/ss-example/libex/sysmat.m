%%% sysmat.m --- 
%% 
%% Description: This is returns the state space system
%%   considered in Schorfheide (2012).
%% 
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 06/19/13
%% 
function [sm, RC] = sysmat (para);

  RC = [1;1];
  phi1 = para(1)^2;
  phi2 = 1 - para(1)^2;
  phi3 = -para(1)*para(2) + phi2;
  TT = [phi1, 0; phi3, phi2];


  sm.TT = TT;
  sm.RR = [1;0];
  sm.QQ = 1;
  sm.DD = 0;
  sm.ZZ = [1 1];
  sm.HH = 0;
  sm.VV = 0;
  
end
