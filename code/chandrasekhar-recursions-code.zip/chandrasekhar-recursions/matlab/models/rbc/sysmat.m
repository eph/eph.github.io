function [sm,RC] = sysmat(para)


  %% usage:  [TT,QQ,RR,HH,DD,ZZ,VV,RC] = sysmat (para,msel)
  %%
  %% 

  %% Parameters

  alp  = para(1);         
  bet  = para(2);          
  del  = para(3);
  gam  = 1+para(4);          
  theta= para(5);
  rhoA = para(6);
  rhoG = para(7);
  sigA = para(8);
  sigG = para(9);
  
  rhoAG  = para(10);
  rhoGA  = para(11);
  corrAG = para(12);
   
  covAG  = corrAG*(sigA*sigG);


  %% Number of Observable Variables %%
  ny = 2;
  
  %% Model variable indices %%
  r_t    = 1;
  w_t    = 2;
  c_t    = 3;
  k_t    = 4;
  h_t    = 5;
  y_t    = 6;
  i_t    = 7;
  lam_t  = 8;
  Er_t   = 9;
  Elam_t = 10;
  g_t    = 12;
  a_t    = 11;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      matrices of canonical system                            %%
  %%    s(t) = [ r(t), w(t), c(t), k(t+1), h(t), y(t), i(t),      %%
  %%    E[r(t+1)], E[c(t+1)], a(t), v(t), b(t), a(t-1), v(t-1)]', %%
  %%    da(t), dv(t), g(t)                                        %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% equation indices %%
  eq_r    = 1;  % Firm FOC for r(t) %
  eq_w    = 2;  % Firm FOC for w(t) %
  eq_mu   = 3;  % Household Marginal Utility %
  eq_h    = 4;  % Household FOC for h(t) %
  eq_eu   = 5;  % Household Euler Equation %
  eq_mc   = 6;  % Market Clearing %
  eq_y    = 7;  % Production Function %
  eq_kacc = 8;  % Capital Accumulation %
  eq_Er   = 9;  % E(r(t+1)) %
  eq_Elam = 10;	% E(lam(t+1)) % 
  eq_a    = 11;	% a process %
  eq_g    = 12;	% b process % 
  
  %% variable indices %%
  r_t    = 1;
  w_t    = 2;
  c_t    = 3;
  k_t    = 4;
  h_t    = 5;
  y_t    = 6;
  i_t    = 7;
  lam_t  = 8;
  Er_t   = 9;
  Elam_t = 10;
  g_t    = 12;
  a_t    = 11;

  %% expectation error indices (eta) %%
  Er_sh    = 1;
  Elam_sh  = 2;
  
  %% shock indices (eps) %%
  a_sh = 1;
  g_sh = 2;

  %% summary %%
  neq  = 12;
  neta = 2;
  neps = 2;

  vsel           = zeros(neps,3);
  vsel(1,:)      = [Er_t,r_t , eq_Er];
  vsel(2,:)      = [Elam_t,lam_t, eq_Elam];
  
  %% initialize matrices %%
  GAM0 = zeros(neq,neq);
  GAM1 = zeros(neq,neq);
  C    = zeros(neq,1);        
  PSI  = zeros(neq,neps);
  PPI  = zeros(neq,neta);

  %% Determine the steady states %% 
  [sst, valid] = dsgess(para); 
 
  c_y = sst(1);
  i_y = sst(2);
  g_y = sst(3);
  i_k = sst(4);
  h_l = sst(5);
  rst = sst(6);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      1. Firm FOC for r(t)                             %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_r,r_t)   =  1;
  GAM0(eq_r,y_t)   = -1;
  GAM1(eq_r,k_t)   = -1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      2. Firm FOC for w(t)                            %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_w,w_t)   =  1;
  GAM0(eq_w,y_t)   = -1;
  GAM0(eq_w,h_t)   =  1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      3. HH FOC for Marginal Utility                  %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_mu,lam_t)  = 1;
  GAM0(eq_mu,c_t  )  = gam;
  GAM0(eq_mu,h_t  )  = (1-gam)*theta*h_l;
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      4. HH FOC for h(t)                              %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_h,w_t)   = -1;
  GAM0(eq_h,c_t)   =  1;
  GAM0(eq_h,h_t)   =  h_l;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      5. HH Euler Equation                            %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_eu,lam_t)  = -1;
  GAM0(eq_eu,Er_t )  =  rst/(rst+1-del);
  GAM0(eq_eu,Elam_t) =  1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      5. Market Clearing Condition                    %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_mc,c_t)   = -c_y;
  GAM0(eq_mc,i_t)   = -i_y;
  GAM0(eq_mc,g_t)   = -g_y;
  GAM0(eq_mc,y_t)   =  1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      6. Production Function                          %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_y,y_t)   =  1;
  GAM0(eq_y,h_t)   = -(1-alp);
  GAM0(eq_y,a_t)   = -(1-alp); 
  GAM1(eq_y,k_t)   =  alp;
   
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      7. Capital Accumulation                         %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_kacc,k_t)  =  1;
  GAM0(eq_kacc,i_t)  = -i_k;
  GAM1(eq_kacc,k_t)  = (1-del);
   
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      Expectation error                               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% E(r) %%
  GAM0(eq_Er,r_t)   = 1;
  GAM1(eq_Er,Er_t)  = 1;
  PPI(eq_Er,Er_sh)  = 1;

  %% E(lam) %%
  GAM0(eq_Elam,lam_t)   = 1;
  GAM1(eq_Elam,Elam_t)  = 1;
  PPI(eq_Elam,Elam_sh)  = 1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      Shock process                                   %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% a(t) %%
  GAM0(eq_a,a_t) = 1;
  GAM1(eq_a,a_t) = rhoA;
  GAM1(eq_a,g_t) = rhoAG;
  PSI(eq_a,a_sh) = 1;
  
  %% g(t) %%
  GAM0(eq_g,g_t)  = 1;
  GAM1(eq_g,g_t)  = rhoG;
  GAM1(eq_g,a_t)  = rhoGA;
  PSI(eq_g,g_sh)  = 1;




  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% Transition Equations                          %%
  %%                                               %%
  %% x(t) = TT*x(t-1) + RR*e(t)                    %%
  %% e(t) ~ iid N(0,QQ)                            %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %% Model Solution
  [T1,TC,T0,TY,M,TZ,GEV,RC] = gensys(GAM0,GAM1,C,PSI,PPI,1+1E-8);
  
  nep = size(T0, 2);

  TT  = T1;
  RR  = T0;
  QQ  = [sigA^2,covAG;covAG,sigG^2];

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% Measurement Equations                         %%
  %%                                               %%
  %% y(t) = DD + ZZ*x(t) + u(t)                    %%
  %% u(t) ~ iid N(0,HH)                            %%
  %% cov(e(t),u(t)) = VV                           %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% Observation Indices %%
  eq_y = 1;
  eq_h = 2;


  DD = zeros(ny,1);
  nx = size(TT, 2);
  
  ZZ = zeros(ny,nx);
  ZZ(eq_y,y_t) = 1;
  ZZ(eq_h,h_t) = 1;

  HH = zeros(ny,ny);
  VV = zeros(nep,ny);
  
  sm.TT = T1;
  sm.RR = T0;
  sm.QQ = QQ;
  sm.DD = DD;
  sm.ZZ = ZZ;
  sm.HH = HH;
  sm.VV = VV;
  
end

function [sst,valid] = dsgess (para)

  %% usage:  [sst,valid] = dsgess (para,msel)
  %%
  %% 

  sst=zeros(6,1); 
  valid=1;
  
  alp  = para(1);         
  bet  = para(2);        
  del  = para(3);
  gam  = para(4);          
  theta= para(5);
  rhoA = para(6); 
  rhoG = para(7);
  sigA = para(8);
  sigG = para(9);
  
  rhoAG  = para(10);
  rhoGA  = para(11);
  corrAG = para(12);
   
  
  if or(1/bet-1+del < 1E-7, alp < 1E-7)
    valid=0; 
    return; 
  end
  
  rst = 1/bet-1+del;
  k_y = alp/rst;
  i_y = (1-(1-del))*k_y;
  i_k = i_y/k_y;
  g_y = 0.20; 
  c_y = 1-i_y-g_y;
  h_l = (1-alp)/(theta*c_y);	% hours/(1-hours)
                                          
  sst = [c_y ; i_y ; g_y ; i_k ; h_l ; rst];

end