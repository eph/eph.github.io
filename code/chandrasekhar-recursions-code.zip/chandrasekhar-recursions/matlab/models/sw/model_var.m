function [c, v, acf] = model_var(SM)
    
    TT = SM.TT; 
    RR = SM.RR; 
    QQ = SM.QQ; 
    
    DD = SM.DD;
    ZZ = SM.ZZ;
    HH = SM.HH;
    format short

    Pt = dlyap(TT, RR*QQ*RR');
    
    for i = 1:10
        Pt = TT*Pt*TT' + RR*QQ*RR';
    end
    v = diag(ZZ*Pt*ZZ')';
    c = diag(1./sqrt(v))*ZZ*Pt*ZZ'*diag(1./sqrt(v));
    acf = diag(ZZ*TT*Pt*ZZ')./v';
    acf = acf(4);
end