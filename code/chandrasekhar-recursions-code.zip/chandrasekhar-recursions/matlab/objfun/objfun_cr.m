function loglh = objfun_cr(yy, p0, t0)

[sm, rc] = sysmat(p0);

TT = sm.TT; 
RR = sm.RR;
QQ = sm.QQ;

DD = sm.DD; 
ZZ = sm.ZZ;
HH = sm.HH;

loglh = cr(yy, TT, RR, QQ, DD, ZZ, HH, t0);

end