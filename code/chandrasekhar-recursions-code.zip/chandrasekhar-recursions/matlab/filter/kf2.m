function  [logL, stateM]=kf2(Z,d,H,T,c,R,Q,P10,a10,dataMatrix,discard,RQR)

%C -------------------------------------------------------------------------
%C Ingvar Strid
%C Dep. of Economic Statistics, Stockholm School of Economics
%C Karl Walentin
%C Sveriges Riksbank
%C 2008-01-07


%C Purpose: 2 block Kalman filter (first version)
%C See accompanying paper for details
%C -------------------------------------------------------------------------
%C Comment: use KF_translator function to obtain the model on the
%C appropriate state-space form.  
%C
%C -------------------------------------------------------------------------
%C Model:
%C OBSERVATION: y(t)=d+Z*x(t)+v(t) , v(t)=N(0,H)
%C STATE: x(t)=T*x(t-1) + R*eps(t),    eps(t)=N(0,Q)  
%C
%C # observables =N
%C # states      =m
%C # exogenous, AR/diagonal, not linked to observation equation = m1
%C # endogenous + # exogenous, AR/VAR, linked to observation equation +  
%C # exogenous, VAR, not linked to observation equation = m2
%C m = m1+m2
%C
%C -------------------------------------------------------------------------
%C Assumptions:
%C
%C      T = [A1     0
%C           B1*A1  C]
%C where A1 is diagonal. 
%C
%C
%C      R = [ I  ;
%C            B1 ];
%C            
%C      
%C      Z = [Z1 Z2]=[0 Z2]
%C -------------------------------------------------------------------------
%C Input:
%C Z: N*m
%C d: N*1
%C H: N*N
%C T: m*m
%C c: m*1, note: c=0 assumed in this version
%C R: m*m1
%C Q: m1*m1
%C P10: m*m
%C a10: m*1
%C dataMatrix: N*timePeriods
%C discard: scalar (skip first discard observations in calculating
%C likelihood)


%C -------------------------------------------------------------------------

% dimensions
m1 = size(Q,1);
m = size(T,1);
m2 = m-m1;
N = size(Z,1);
timeP=size(dataMatrix,2);

% matrices
A=T(1:m1,1:m1);
B=R(m1+1:m,1:m1);
Btr =B';
C=T(m1+1:m,m1+1:m);
Ctr = C';
Z2 = Z(1:N,m1+1:m);
Z2tr = Z2';
R22 = RQR(m1+1:m,m1+1:m);
R22 = R22 - B*Q*Btr;


P12_Z2=zeros(m1,N);
P22_Z2=zeros(m2,N);
APC = zeros(m1,m2);
Ft = zeros(N,N);
cholFt = zeros(N,N);
cholFtInvTr = zeros(N,N);
eyeN=eye(N);

stateM=zeros(m,timeP);

diagA=diag(A);
Atilde =diagA*diagA';
Atilde2 = 2*diagA*ones(1,m2);


% C ! ------------------ Mean vectors

a1 = a10(1:m1);
a2 = a10(m1+1:m);

% C	! ----------------- Covariance blocks

P11 = P10(1:m1,1:m1);
P12 = P10(1:m1,m1+1:m);
P22 = P10(m1+1:m,m1+1:m);

% % C	! ----------------- Constants

Nlog2pi = N*log(2.0*pi);

logL = 0.0;

% % C!------------------------------------------------------------------------------

for i=1:timeP

    % % 	! ------step 1: get F(t) = Z*P(t|t-1)*Z' + H

    P12_Z2=P12*Z2tr;
    P22_Z2=P22*Z2tr;

    Ft = Z2*P22_Z2+H;
    logdetFt=log(det(Ft));
    

% %     FtInv=inv(Ft);
% %     cholFtInvTr = chol(FtInv)';
    
    cholFt=chol(Ft);
    cholFtInvTr=cholFt\eyeN;
       
    vt= dataMatrix(:,i);
       
    vt = vt - d;

    vt = vt - Z2*a2;

    P12_Z2=P12_Z2*cholFtInvTr;
    P22_Z2=P22_Z2*cholFtInvTr;
    vt=cholFtInvTr'*vt;

    addFactor = sum(vt.*vt) + logdetFt + Nlog2pi;
%     storeC(i,1)=sum(vt.*vt) + logdetFt + Nlog2pi;
    sLinAdd(i) = -0.5*addFactor;

    if (i > discard)
        logL	= logL + addFactor;
    end

    % % C        ! ------ step 3: Filtering step, t|t-1 -> t|t

    a1 = a1 + P12_Z2*vt;
    a2 = a2 + P22_Z2*vt;

    P11 = P11 - P12_Z2*P12_Z2';
    P12 = P12 - P12_Z2*P22_Z2';
    P22 = P22 - P22_Z2*P22_Z2';
    
%         if i==2
%     sumP11=sum(sum(P11))
%     sumP12=sum(sum(P12))
%     sumP22=sum(sum(P22))
%     end;
    
    
    %----------------------------------------------------------------------
  
    

    P22 = Ctr'*P22*Ctr;

    P22 = P22+R22;

    stateM(1:m1,i)=a1;
    stateM(m1+1:m,i)=a2;

    % % C         ! ------ step 4: Prediction step, t|t->t+1|t
    
    
    a1 = diagA.*a1;								%!a1_t1_t,a1_t_t

    P11 = Atilde.*P11 + Q;

    a2 = Ctr'*a2 + Btr'*a1;

    APC = P12*Ctr;
    APC = Atilde2.*APC;

    P12=APC+P11*Btr;
%     sumAPC=sum(sum(APC))
%     test=Btr'*P12+P12'*Btr;
%     sumTest=sum(sum(test))
    P22 = 0.5*(P22+Btr'*P12);
    P22 = P22+P22';
    P12 = P12 - 0.5*APC;

end
% storeC
logL = -0.5*logL;
