function out = init_InEff_diff(phi_1, yy, perror, H, rstar)

N = size(perror,2); % number of particles

temp_lik = zeros(N,1);

for nn = 1:N
temp_lik(nn,1) = (2*pi)^(-size(yy,2)/2)*phi_1^(size(yy,2)/2)*det(H)^(-1/2)* ...
            exp(-1/2*perror(:,nn)'*phi_1*inv(H)*perror(:,nn));
end

new_Weights = temp_lik/mean(temp_lik);

init_InEff = sum(new_Weights.^2)/N;

out = init_InEff - rstar;