function [ind_s, ind_eps, ind_acpt] = mutation_RWMH_multistep(s0, eps0, Phi, sqrtS2, A, B, H, yy, tune)
% RWMH for mutation step

ind_acpt = 0;

for nn = 1:tune.N_mh

% RW proposal
epsx = eps0 + tune.c*chol(tune.R)'*randn(size(tune.R,1),1);

 sx_fore   = Phi*s0 + sqrtS2*epsx;
 s0_fore   = Phi*s0 + sqrtS2*eps0;
        
 perrorx = yy'-A - B*sx_fore;
 perror0 = yy'-A - B*s0_fore;
    
 postx = log(mvnpdf(perrorx', zeros(1,size(yy,2)), H)*mvnpdf(epsx'));
 post0 = log(mvnpdf(perror0', zeros(1,size(yy,2)), H)*mvnpdf(eps0'));

% Accept/Reject
alp = exp(postx - post0); % this is RW, so q is canceled out
if rand < alp % accept
    ind_s   = sx_fore;
    ind_eps  = epsx;
    ind_acpt   = ind_acpt + 1;
else
    ind_s   = s0_fore;
    ind_eps  = eps0;
    ind_acpt   = 0;
end

eps0 = ind_eps;

end

ind_acpt = ind_acpt/tune.N_mh;

% % outside of function
% parasim(i,j,:) = ind_para;
% loglh(j)       = ind_loglh;
% temp_acpt(j,1) = ind_acpt;
