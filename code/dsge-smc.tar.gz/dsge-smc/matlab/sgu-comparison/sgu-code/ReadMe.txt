Data and code for: 
``What's News in Business Cycles,''  by Schmitt-Grohe, Stephanie and Martin Uribe, published in Econometrica. 

Data:
------
The data is stored in the Matlab file read_data.mat under the name Y, which is   a 207 by 7 matrix. 
Rows correspond to quarters  and columns to different variables. 
The data is quarterly. The sample is 1955:Q2 - 2006:Q4
The data sources and defintions are described in detail in the appendix to  ``What's News in Business Cycles''
Each variable is demeaned and then multiplied by 100. 

Columns of the matrix Y:
Column 1: gy = diff(log(y)); y = real per capita GDP  (line 12. in appendix) 
Column 2: gc = diff(log(c)); c= real per capita consumption  (line 13. in appendix) 
Column 3: giv = diff(log(iv)); iv = real  per capital investment  (line 14 in appendix)
Column 4: gh = diff(log(h));  h =   per capita hours (line 16. in appendix) 
Column 5: gg= diff(log(g)); g =  real per capita government expenditure (line 15. in appendix) 
Column 6:  gtfp = diff(ltfp); ltfp = natural log of total factor productivity (line 20. in appendix) 
Column 7: gpa = diff(log(pa)); pa = relative price of investment. (line 17. in appendix)


Matlab Code
Model Predictions:
-----------------------

Step 1: Run model.m this creates 2 files: model.mat and model_num_eval.m

Step 2: Load a paramter vector by issuing the matlab command load paramter_vector.mat 
the mat file parameter_vector.mat contains 
4 parameter vectors of size 35x1:
mean_bayesian
median_bayesian
mean_mle
and 
median_prior
The names are self-explanatory. 
 Note that these parameter vectors are not ordered or transformed exactly as they appear on table 2 of the paper  ``What's News in Business Cycles.'' To obain the right order and transformation, see the beginning of the program gx_hx_inputs.m. 


Step 3: Run moments_shares_and_likelihood.m: This file computes (a) Population second moments predicted by the model (shown in Table 3); Variance Decompositions (shown in Tables 5 and 6); (c) the classical log likelihood  function (to obtain the posterior likelihood, add the log of the prior likelihood). 

 