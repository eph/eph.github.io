function pos = lnpy(Y, p0);

    global pmean pshape pstdd 
    [nfx, nfy, nfxp, nfyp, nvarshock, nvarme, nETASHOCK ] = gx_hx_inputs(p0); 
    [gx,hx,exitflag]=gx_hx(nfy,nfx,nfyp,nfxp);

    if exitflag == 0 || exitflag > 1
        pos = -10e10
        return
    end
    load model statevar_cu
    ns = length(statevar_cu);
    nmua = find(statevar_cu=='mua');
    emua = zeros(1,ns);
    emua(nmua) = 1;

    %stack the law of motion of variables of interest in one matrix
    GX = [gx(1:6 ,:); emua];


    lik = log_like_kalman(Y, hx, nvarshock, GX', nvarme);
    
    pri = priodens(p0, pmean, pstdd, pshape);
    varcov = mom(GX,hx,nvarshock) + nvarme;

    sgu_sigy = sqrt(diag(varcov));
    sgu_cory = varcov(:, 1) ./ (sgu_sigy * sgu_sigy(1));
    [sgu_sigy sgu_cory]

    pos = lik + pri;
end 