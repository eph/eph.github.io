#!/bin/bash
#PBS -l procs=20,mem=50gb,walltime=1000:00:00 -S /bin/csh

runcmd=rwmh_driver
outdir=$OUTPUT_BASE/dsge-smc/draft-2/news/rwmh/standard/
exedir=~/code/staging/

cd /arc/home/m1cpl01/torque/mpi
cat $PBS_NODEFILE

cd $exedir
./rwmh_driver --nsim 10000000 -c 0.01 -i 1 --output-dir $outdir > $outdir/log1.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 2 --output-dir $outdir > $outdir/log2.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 3 --output-dir $outdir > $outdir/log3.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 4 --output-dir $outdir > $outdir/log4.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 5 --output-dir $outdir > $outdir/log5.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 6 --output-dir $outdir > $outdir/log6.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 7 --output-dir $outdir > $outdir/log7.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 8 --output-dir $outdir > $outdir/log8.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 9 --output-dir $outdir > $outdir/log9.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 10 --output-dir $outdir > $outdir/log10.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 11 --output-dir $outdir > $outdir/log11.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 12 --output-dir $outdir > $outdir/log12.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 13 --output-dir $outdir > $outdir/log13.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 14 --output-dir $outdir > $outdir/log14.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 15 --output-dir $outdir > $outdir/log15.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 16 --output-dir $outdir > $outdir/log16.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 17 --output-dir $outdir > $outdir/log17.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 18 --output-dir $outdir > $outdir/log18.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 19 --output-dir $outdir > $outdir/log19.txt &
./rwmh_driver --nsim 10000000 -c 0.01 -i 20 --output-dir $outdir > $outdir/log20.txt 


