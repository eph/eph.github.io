function out = InEff(phi_new, phi_old, yy, perror, H)

N = size(perror,2);

temp_lik = zeros(N,1);

for nn = 1:N
    temp_lik(nn,1) = (phi_new/phi_old)^(size(yy,2)/2)* ...
        exp(-1/2*perror(:,nn)'*(phi_new-phi_old)*inv(H)*perror(:,nn));
end

new_Weights = temp_lik/mean(temp_lik);

out = sum(new_Weights.^2)/N;

