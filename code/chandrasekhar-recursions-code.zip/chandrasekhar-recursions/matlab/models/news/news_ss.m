function ss = news_ss(para)


  thet		= para(1)+1;
  gam		= para(2);
  kap		= para(3);
  del2_del1	= para(4);
  b		= 0.99*para(5);
  rhoxg		= 0.99*para(6);
  rhoz		= 0.99*para(7);
  rhoa		= 0.99*para(8);
  rhog		= 0.99*para(9);
  rhox		= para(10);
  rhom		= 0.99*para(11);
  rhozet	= 0.99*para(12);
  rhozi		= 0.99*para(13);

  %% set calibrated parameters -- not the optimal way of doing things
  alpk  = para(14);
  alph	= para(15);
  del0	= para(16);
  bet	= para(17);
  hss	= para(18);
  muss	= para(19);
  muass = para(20);
  muxss = para(21);
  sig	= para(22);
  g_y	= para(23);

  %% find steady states, et cetera 
  mukss = muass^(1/(alpk-1))*muxss;	% steady state growth for captial
  muyss = muass^(alpk/(alpk-1))*muxss;	% steady state output growth rate
  xgss  = ((1/muyss)^(1/(1-rhoxg)));
  g_y   = g_y/xgss;
  y_k   = (1/(bet*muass*muyss^-sig) - (1-del0))/(alpk*mukss);
  i_k   = 1 - (1-del0)/mukss;
  i_y   = i_k/y_k;
  c_y   = 1 - g_y*xgss - i_y;
  y_c   = 1/c_y;
  betbar= bet*b*muyss^-sig;
  badj  = b/muyss;
  ppsi   = ((1-betbar)*alph/(muss)*y_c)/(hss^thet*(1/muyss)^((1-gam)/gam)*(thet*(1-badj)+gam/(1-bet*(1-gam)*muyss^(1-sig))*alph/(muss)*y_c*(1-betbar)));
  del1  = alpk*y_k*mukss;
  del2  = del2_del1*del1;
  xi    = 1-bet*(1-gam)*muyss^(1-sig);
  eta   = ppsi*hss^thet*gam*(1/muyss)^((1-gam)/gam)/xi;
  l = 1;
  kss   = (y_k/(l^(1-alpk-alph)*hss^alph)*1/(mukss^-alpk))^(1/(alpk-1));
  yss   = y_k*kss;
  css   = c_y*(y_k*kss);

  stock = css*(1-b/muyss)*muyss^((gam-1)/gam);
  ss = [mukss; muyss; xgss; g_y; y_k; i_k; i_y; c_y; y_c; betbar; ...
        badj; ppsi; del1; del2; xi; eta; kss; stock; css; yss; c_y; ...
       y_k*kss];

end