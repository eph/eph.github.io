function file_list = get_file_list(fstr)
    
    file = fileread(fstr);
    file_list = regexp(file, '\n', 'split');

    file_list = file_list(1:end-1);
    
end