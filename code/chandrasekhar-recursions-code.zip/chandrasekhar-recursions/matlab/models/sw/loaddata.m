%yall = load('~/code/fortran/models/sw/YY.txt');
yall = load('SWDATA.txt');
y = yall;
y = yall(74:end, :);
