%clear all
addpath('~/code/matlab/dsge/models/news');
addpath('~/code/matlab/dsge/gensys');
addpath('~/code/matlab/dsge/objfun');
addpath('~/code/matlab/filter');
addpath('~/code/matlab/from-dynare');

addpath('sgu-code');
names = {'gy', 'gc', 'gi', 'gh', 'gg', 'gtfp', 'gpa'};
ssnames = {'MUK', 'MUY', 'xg', 'g/y', 'y/k', 'iv/k', 'iv/y', 'c/y', 'y/c', 'B*BETTATILDE', 'B/MUY', 'PSSI', 'DELTA1', 'DELTA2', 'XI', 'ETA', 'k', 'stock', 'c', 'y', 'SC', 'y'};
%model;
load parameter_vector.mat
load read_data
param_estim = mean_mle;

%p0 = sgu2eph_para(param_estim)';
p0 = para1(53, :);
%p0(2)= 0.08;
%p0 = sgu2eph_para(mean_mle)';

nss = news_ss(p0);
sguss = sgu_ss(eph2sgu_para(p0'));
fprintf('Steady State             EPH         SGU\n');
fprintf('---------------        -------      -------\n');
for i = 1:length(ssnames)
    fprintf('%15s   %10.3f   %10.3f\n', ssnames{i}, nss(i), sguss(i));
end    
fprintf('\n\n')
[sm, RC] = sysmat(p0);
for i = 1:1000
    p0 = para1(i, :);
    [sm, RC] = sysmat(p0);
    RC
end
RC
break
temp = sm.ZZ(6, :);
sm.ZZ(6, :) = sm.ZZ(7, :);
sm.ZZ(7, :) = temp;

[sigy, sigx] = mom(sm.ZZ, sm.TT, sm.RR*sm.QQ*sm.RR');
eph_eig = sort(eig(real(sm.TT)));

sigy(1, 1) = sigy(1, 1) + p0(end)^2;

eph_sigy = sqrt(diag(sigy));
eph_cory = sigy(:, 1) ./ (eph_sigy * eph_sigy(1));

[acfy, acfx] = mom(sm.ZZ/100, sm.TT, 10000*sm.RR*sm.QQ*sm.RR', 1);

[nfx, nfy, nfxp, nfyp, nvarshock, nvarme, nETASHOCK ] = gx_hx_inputs(eph2sgu_para(p0'));

%Obtain numerical values for the matrices defining the law of motion of the economy up to first order
[gx,hx,exitflag]=gx_hx(nfy,nfx,nfyp,nfxp);

%Collect the law of motion of the variables of interest in the matrix G. The laws of motion of the first  6 variables of interest are the first 6 rows of the matrix gx. The law of motioin of mua is in the matrix hx.  So we have to identify the location of the growth rate of the investment-specific technology shock
load model statevar_cu
ns = length(statevar_cu);
nmua = find(statevar_cu=='mua');
emua = zeros(1,ns);
emua(nmua) = 1;

%stack the law of motion of variables of interest in one matrix
GX = [gx(1:6 ,:); emua];

%Predicted Var/Cov matrix with  measurement error
varcov = mom(GX,hx,nvarshock) + nvarme;
sgu_eig = sort(eig(real(hx)));
sgu_sigy = sqrt(diag(varcov));
sgu_cory = varcov(:, 1) ./ (sgu_sigy * sgu_sigy(1));

sgu_acfy = mom(GX, hx, nvarshock, 1);

X = [eph_sigy, sgu_sigy];
Z = [eph_cory, sgu_cory];
fprintf('  VAR     EPH     SGU\n')
fprintf('-----   -----   -----\n')
for i = 1:7
    fprintf('%5s   %5.2f   %5.2f\n', names{i}, X(i, :))
end
fprintf('\n\n');
fprintf('  VAR     EPH     SGU\n')
fprintf('-----   -----   -----\n')
for i = 1:7
    fprintf('%5s   %5.2f   %5.2f\n', names{i}, Z(i, :))
end


fprintf('\n\n');
% log likelihoods
L = log_like_kalman(Y, hx, nvarshock, GX', nvarme);
fprintf('SGU Model: l(p0) = %7.2f\n', L)
L = log_like_kalman(Y, sm.TT, sm.RR*sm.QQ*sm.RR', sm.ZZ', sm.HH);
fprintf('EPH Model: l(p0) = %7.2f\n', L)
nobs = size(Y, 1);
DDmat = repmat(sm.DD', [nobs, 1]);
YY = [Y(:, 1:5) Y(:, 7) Y(:, 6)] + DDmat;
L = objfun_cr(YY, p0, 0);
fprintf('EPH Model: l(p0) = %7.2f\n', L);