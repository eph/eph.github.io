% file: kf.m
% 
%  function: kf(y, TT, RR, QQ, DD, ZZ, HH, t0) 
% 
%  Evaluates the log-likelihood of stationary LGSS model using standard
%  techniques.
%    s_t = TT*s_{t-1} + RR*eps_t,  eps_t ~ iidN(0, QQ)
%    y_t = DD + ZZ*s_t + eta_t, eta_t ~ iidN(0, HH)
% 
%  y should be nobs x ny, that is, each row corresponding to a time period. 
%
%  The state are initialized from the stationary distribution.
%
%  t0 is the number of initial observations to condition on.
%  Returns:
%    loglh -- the log likelihood (scalar).
%
%
% Implemented by Ed Herbst <edward.p.herbst@frb.gov>
%------------------------------------------------------------------------------- 
function loglh = kf(y, TT, RR, QQ, DD, ZZ, HH, t0)
    
    [nobs, ny] = size(y);
    [ns, ~] = size(TT);

    RQR = RR*QQ*RR';

    At = zeros(ns, 1);

    Pt = dlyap(TT, RQR); %lyapunov_symm(TT, RQR, 1, 1e-6);
    
    loglh = 0;
    for i = 1:nobs

        yhat = ZZ*At + DD;
        nut = y(i, :) - yhat';
        Ft = ZZ*Pt*ZZ' + HH;
        Ft = 0.5*(Ft + Ft');
        dFt = det(Ft);
        iFtnut = Ft \ nut';
        
        if i > t0
            loglh = loglh - 0.5*ny*log(2*pi) - 0.5*log(dFt) - 0.5*nut*iFtnut;
        end
        TTPt = TT*Pt;
        Kt = TTPt*ZZ';
        At = TT*At + Kt*iFtnut;
        Pt = TTPt*TT' - Kt*(Ft\Kt') + RQR;

    end

end