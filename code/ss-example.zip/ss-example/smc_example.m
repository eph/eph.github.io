%%% smc_example.m --- 
%% 
%% Description: A simple SMC example using the 
%%   the bimodal "DSGE" model from Schorfheide (2012).
%% 
%%   The transition kernel is simplified to a random-walk 
%%    MH. 
%% 
%%  For more, see:
%%    "Sequential Monte Carlo Sampling for DSGE Models"
%%      by Ed Herbst and Frank Schorfheide.
%%
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 05/09/14
%% 
addpath('libex')

%------------------------------------------------------------
% settings
%------------------------------------------------------------
npart = 250;                            % # of particles
nphi  = 100;                            % # of stage
lam   = 1;                              % # bending coeff

% creating the tempering schedule.
phi = linspace(0, 1, nphi);
phi = phi.^lam;

c = 0.5;                                % initial scale cov
R = 10e-2*eye(2);                       % initial cov
acpt = 0.25;                            % "initial" acpt rate




%------------------------------------------------------------
% load data / initializatin
%------------------------------------------------------------
y = load('libex/data.txt');
y = y(1:200, :);

parasim = zeros(nphi, npart, 2);
wtsim = zeros(npart, nphi);
zhat = zeros(nphi, 1);
nresamp = 0;


% The log prior for an (in bounds) para draw is 0, so we ignore it.
% create f, the log likelihood, enforcing parameter bounders.
f = @(x) inbounds(x)*objfun(y, x, 0) + (1-inbounds(x))*-1000000;

%------------------------------------------------------------
% initial draws from the jointly uniform prior.
%------------------------------------------------------------
parasim(1, :, :) = rand(npart, 2);
wtsim(:, 1) = 1/npart;
zhat(1) = sum(wtsim(:, 1));

% initialize likelihood draws
loglh = zeros(npart, 1);
for i = 1:npart
    p0 = parasim(1, i, :);
    loglh(i) = f(p0);
end

%------------------------------------------------------------
% SMC algorithm
%------------------------------------------------------------
for i = 2:nphi
    

    %--------------------------------------------------------
    % correction
    %--------------------------------------------------------
    % incremental weights
    incwt = exp((phi(i)-phi(i-1))*loglh);

    % update weights
    wtsim(:, i) = wtsim(:, i-1).*incwt;
    zi(i) = sum(wtsim(:, i));
    
    % normalize weights
    wtsim(:, i) = wtsim(:, i)/zi(i);
    


    %--------------------------------------------------------
    % selection 
    %--------------------------------------------------------
    ESS = 1/sum(wtsim(:, i).^2);
    if (ESS < npart/2) 
        [id, m] = multinomial_resampling(wtsim(:, i)');

        parasim(i, :, :) = parasim(i, id, :);
        loglh = loglh(id);
        wtsim(:, i) = 1/npart;
        nresamp = nresamp + 1;
        

    end



    %--------------------------------------------------------
    % mutuation
    %--------------------------------------------------------
    % adapting the transition kernel
    c = c*(0.95 + 0.10*exp(16*(acpt-0.25))/(1 + exp(16*(acpt-0.25))));

    % calculate estimates of mean and variance
    para = squeeze(parasim(i-1, :, :));
    wght = repmat(wtsim(:, i), 1, 2);

    mu = sum(para.*wght);
    
    z = (para - repmat(mu, npart, 1));
    R = (z.*wght)'*z;

 
    % RWMH (this can be done in parallel...)
    acpt = 0;
    for j = 1:npart
        p0 = para(j, :)';

        px = p0 + c*chol(R)'*randn(2, 1);
        lx = f(px);
        
        alp = exp(phi(i)*(lx - loglh(j)));
        
        if rand < alp
            parasim(i, j, :) = px;
            loglh(j) = lx;
            
            acpt = acpt + 1;
        else
            parasim(i, j, :) = p0;
        end

    end     
    acpt = acpt/npart;

    
    
    % print some information
    if mod(i, 1) == 0
        fprintf('+------------------+\n')
        fprintf('+ phi  = %5.4f    +\n', phi(i));
        fprintf('+------------------+\n')
        fprintf('  c    = %5.4f\n', c);
        fprintf('  acpt = %5.4f\n', acpt);
        fprintf('  ESS  = %5.1f  (%d total resamples.)\n\n\n', ESS, nresamp);
    end
end

%------------------------------------------------------------
% report summary statistics
%------------------------------------------------------------
para = squeeze(parasim(nphi, :, :));
wght = repmat(wtsim(:, nphi), 1, 2);

mu = sum(para.*wght);
sig = sum((para - repmat(mu, npart, 1)).^2 .*wght);
sig = sqrt(sig);

fprintf('Finished SMC algorithm.\n')
fprintf('para   mean    std\n')
fprintf('----   ----    ----\n')
fprintf('thet1  %4.2f    %4.2f\n', mu(1), sig(1))
fprintf('thet2  %4.2f    %4.2f\n', mu(2), sig(2))

%------------------------------------------------------------
% waterfall plot
%------------------------------------------------------------
parai = 1;

itsel = 1:5:nphi;                      % plot every 10th dens.
nsel = length(itsel);


bins = 0:0.01:1;
post = zeros(nsel, length(bins));
for i = 1:nsel
    
    phisel = itsel(i);
    para = squeeze(parasim(phisel, :, parai));
    [id, m] = multinomial_resampling(wtsim(:, phisel)');
    para = para(id);
    
    post(i, :) = ksdensity(para, bins);
end

colscale = (0.65:-0.05:0);
colormap(repmat(colscale', 1, 3));

waterfall(bins, itsel/nphi, post)

title(['Density estimates of \theta_' num2str(parai)])
xlabel(['\theta_' num2str(parai)])
ylabel(['\phi'])