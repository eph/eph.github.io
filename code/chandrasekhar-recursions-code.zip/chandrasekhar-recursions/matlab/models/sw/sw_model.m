%% Copyright (C) 2010 by Ed Herbst.
%%
%% This program is free software; you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation; either version 2 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program; If not, see <http://www.gnu.org/licenses/>.
function varargout = sw_model(para,msel);

  %% assign names to parameters 
  varphi = para(1);   
  sigmac = para(2);
  h      = para(3);
  lamw   = para(4);
  xiw    = para(5);
  epsw   = para(6);
  sigmal = para(7);
  del    = para(8);
  xip    = para(9);
  epsp   = para(10);
  iotaw  = para(11);
  iotap  = para(12);
  ppsi   = para(13);
  capphi = para(14);
  rpi    = para(15);
  rho    = para(16);
  ry     = para(17);
  rdely  = para(18);
  pibar  = para(19);
  betin  = para(20);
  lbar   = para(21);
  gambar = para(22);
  alp    = para(23);
  g_y    = para(24);
  
  rhoa   = para(25);
  rhob   = para(26);
  rhog   = para(27);
  rhoi   = para(28);
  rhor   = para(29);
  rhop   = para(30);
  rhow   = para(31);
  
  mup    = para(32);
  muw    = para(33);
  rhoga  = para(34);
  
  sigmaa = para(35);
  sigmab = para(36);
  sigmag = para(37);
  sigmai = para(38);
  sigmar = para(39);
  sigmap = para(40);
  sigmaw = para(41);
  
  %% equation indices 
  eq_euler  = 8;
  eq_inv    = 9  ;
  eq_q      = 10 ;
  eq_output = 11 ;
  eq_caputl = 12 ;
  eq_capsrv = 13 ;
  eq_capev  = 14 ;
  eq_mkupp  = 15 ;
  eq_phlps  = 16 ;
  eq_caprnt = 17 ;
  eq_mkupw  = 18 ;
  eq_wage   = 19 ;
  eq_mp     = 20 ;
  eq_res    = 21 ;
  eq_g      = 1 ;
  eq_b      = 2 ;
  eq_ia     = 3 ;
  eq_a      = 4 ;
  eq_lp     = 5 ;
  eq_lw     = 6 ;
  eq_mps    = 7 ;
  eq_lp1    = 22  ;
  eq_lw1    = 23  ;
  eq_Ec     = 24  ;
  eq_Eq     = 25  ;
  eq_Ei     = 26  ;
  eq_Epi    = 27  ;
  eq_El     = 28  ;
  eq_Erk    = 29  ;
  eq_Ew     = 30  ;
  eq_euler_F  = 31;
  eq_inv_F    = 32;
  eq_q_F      = 33;
  eq_output_F = 34;
  eq_caputl_F = 35;
  eq_capsrv_F = 36;
  eq_capev_F  = 37;
  eq_mkupp_F  = 38;
  eq_caprnt_F = 39;
  eq_mkupw_F  = 40;
  eq_res_F    = 41;
  eq_Ec_F     = 42;
  eq_Eq_F     = 43;
  eq_Ei_F     = 44;
  eq_El_F     = 45;
  eq_Erk_F    = 46;
  eq_ylag     = 47;
  eq_clag     = 48;
  eq_ilag     = 49;
  eq_wlag     = 50;

  %% variable indices 
  v_y       = 8 ;
  v_c       = 9 ;
  v_i       = 10 ;
  v_q       = 11 ;
  v_ks      = 12 ;
  v_k       = 13 ;
  v_z       = 14 ;
  v_rk      = 15 ;
  v_mup     = 16 ;
  v_pi      = 17 ;
  v_muw     = 18 ;
  v_w       = 19 ;
  v_l       = 20 ;
  v_r       = 21 ;
  v_g       = 1 ;
  v_b       = 2 ;
  v_ia      = 3 ;
  v_a       = 4 ;
  v_lp      = 5 ;
  v_lp1     = 22 ;
  v_lw      = 6 ;
  v_lw1     = 23;
  v_mp      = 7 ;
  v_Ec      = 24;
  v_Eq      = 25;
  v_Ei      = 26;
  v_Epi     = 27;
  v_El      = 28;
  v_Erk     = 29;
  v_Ew      = 30;
  v_y_F     = 31;
  v_c_F     = 32;
  v_i_F     = 33;
  v_q_F     = 34;
  v_ks_F    = 35;
  v_k_F     = 36;
  v_z_F     = 37;
  v_rk_F    = 38;
  v_w_F     = 39;
  v_l_F     = 40;
  v_r_F     = 41;
  v_Ec_F    = 42;
  v_Eq_F    = 43;
  v_Ei_F    = 44;
  v_El_F    = 45;
  v_Erk_F   = 46;
  v_ylag    = 47;
  v_clag    = 48;
  v_ilag    = 49;
  v_wlag    = 50;
  
  %% link expectations with variables
  vsel = [v_Ec , v_c , eq_Ec ;
	  v_Eq , v_q , eq_Eq ;
	  v_Ei , v_i , eq_Ei ;
	  v_Epi, v_pi, eq_Epi;
	  v_El,  v_l,  eq_El ;
	  v_Erk, v_rk, eq_Erk;
	  v_Ew,  v_w,  eq_Ew ;
	  v_Ec_F, v_c_F, eq_Ec_F;
	  v_Eq_F , v_q_F , eq_Eq_F ;
	  v_Ei_F , v_i_F , eq_Ei_F ;
	  v_El_F,  v_l_F,  eq_El_F ;
	  v_Erk_F, v_rk_F, eq_Erk_F];
	  
  %% shock indices 
  e_g       = 1;
  e_b       = 2;
  e_ia      = 3;
  e_a       = 4;
  e_lp      = 5;
  e_lw      = 6;
  e_mp      = 7;
  
  %% expectation errors 
  n_c       = 1;
  n_q       = 2;
  n_i       = 3;
  n_pi      = 4;
  n_l       = 5;
  n_rk      = 6;
  n_w       = 7;
  n_c_F     = 8;
  n_q_F     = 9;
  n_i_F     = 10;
  n_l_F     = 11;
  n_rk_F    = 12;

  %% summary 
  neq  = 50;
  neps = 7;
  neta = 12;
  
  %% steady state parameters 
  gam    = gambar/100 + 1;
  pistar = pibar /100 + 1;
  bet    = 1/(betin/100 + 1);
  rbar   = 100*(bet^(-1)*gam^sigmac*pistar - 1);
  
  rk_ss   = (gam^sigmac)/bet - (1-del);
  w_ss    = (alp^alp*(1-alp)^(1-alp)/(capphi*rk_ss^alp))^(1/(1-alp));

  %% great ratios 
  i_k      = (1 - (1-del)/gam)*gam;
  l_k      = (1 - alp)/alp * rk_ss/w_ss;
  k_y      = capphi*l_k^(alp-1);
  i_y      = (gam-1+del)*k_y;
  c_y      = 1 - g_y - i_y;
  z_y      = rk_ss*k_y;
  wl_c     = 1/lamw*(1-alp)/alp*rk_ss*k_y/c_y;
  
  GAM0 = zeros(neq,neq);
  GAM1 = zeros(neq,neq);
  PSI  = zeros(neq,neps);
  PPI  = zeros(neq,neta);
  C    = zeros(neq,1);
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      1. Consumption Euler Equation               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages 
  GAM0(eq_euler,v_c  ) =  1;
  GAM0(eq_euler,v_Ec ) = -1/(1+h/gam);
  GAM0(eq_euler,v_l  ) = -(sigmac-1)*wl_c/(sigmac*(1+h/gam));
  GAM0(eq_euler,v_El ) =  (sigmac-1)*wl_c/(sigmac*(1+h/gam));
  GAM0(eq_euler,v_r  ) =  (1-h/gam)/( (1+h/gam)*sigmac);
  GAM0(eq_euler,v_Epi) = -(1-h/gam)/( (1+h/gam)*sigmac);
  GAM0(eq_euler,v_b  ) = -1; %(1-h/gam)/( (1+h/gam)*sigmac);
  GAM1(eq_euler,v_c  ) =  (h/gam)/(1+h/gam);

  %% flexible prices and wages
  GAM0(eq_euler_F,v_c_F ) =  1;
  GAM0(eq_euler_F,v_Ec_F) = -1/(1+h/gam);
  GAM0(eq_euler_F,v_l_F ) = -(sigmac-1)*wl_c/(sigmac*(1+h/gam));
  GAM0(eq_euler_F,v_El_F) =  (sigmac-1)*wl_c/(sigmac*(1+h/gam));
  GAM0(eq_euler_F,v_r_F ) =  (1-h/gam)/( (1+h/gam)*sigmac);
  GAM0(eq_euler_F,v_b   ) = -1; %(1-h/gam)/( (1+h/gam)*sigmac);
  GAM1(eq_euler_F,v_c_F ) =  (h/gam)/(1+h/gam);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      2. Investment Euler Equation               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %% sticky prices and wages %%
  GAM0(eq_inv,v_i )  =  1;
  GAM0(eq_inv,v_Ei)  = -bet*gam^(1-sigmac)/(1+bet*gam^(1-sigmac));
  GAM0(eq_inv,v_q )  = -1/(gam^2*varphi)*1/(1+bet*gam^(1-sigmac));
  GAM0(eq_inv,v_ia)  = -1;
  GAM1(eq_inv,v_i )  =  1/(1+bet*gam^(1-sigmac));
  
  %% flexible prices and wages %%
  GAM0(eq_inv_F,v_i_F )  =  1;
  GAM0(eq_inv_F,v_Ei_F)  = -bet*gam^(1-sigmac)/(1+bet*gam^(1-sigmac));
  GAM0(eq_inv_F,v_q_F )  = -1/(gam^2*varphi)*1/(1+bet*gam^(1-sigmac));
  GAM0(eq_inv_F,v_ia  )  = -1;
  GAM1(eq_inv_F,v_i_F )  =  1/(1+bet*gam^(1-sigmac));

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      3. Value of Capital                        %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_q,v_q  ) =  1;
  GAM0(eq_q,v_Eq ) = -bet*gam^-sigmac*(1-del);
  GAM0(eq_q,v_Erk) = -(1-bet*gam^-sigmac*(1-del));
  GAM0(eq_q,v_r  ) =  1;
  GAM0(eq_q,v_Epi) = -1;
  GAM0(eq_q,v_b  ) = -1/((1-h/gam)/((1+h/gam)*sigmac));
  
  %% flexible prices and wages %%
  GAM0(eq_q_F,v_q_F  ) =  1;
  GAM0(eq_q_F,v_Eq_F ) = -bet*gam^-sigmac*(1-del);
  GAM0(eq_q_F,v_Erk_F) = -(1-bet*gam^-sigmac*(1-del));
  GAM0(eq_q_F,v_r_F  ) =  1;
  GAM0(eq_q_F,v_b    ) = -1/((1-h/gam)/((1+h/gam)*sigmac));

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      4. Aggregate Production Function          %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_output,v_y ) =  1;
  GAM0(eq_output,v_ks) = -capphi*alp;
  GAM0(eq_output,v_l ) = -capphi*(1-alp);
  GAM0(eq_output,v_a ) = -capphi;
  
  %% flexible prices and wages %%
  GAM0(eq_output_F,v_y_F ) =  1;
  GAM0(eq_output_F,v_ks_F) = -capphi*alp;
  GAM0(eq_output_F,v_l_F ) = -capphi*(1-alp);
  GAM0(eq_output_F,v_a   ) = -capphi;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      5. Capital Utilization                   %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_caputl,v_ks) =  1;
  GAM1(eq_caputl,v_k ) =  1;
  GAM0(eq_caputl,v_z ) = -1;
  
  %% flexible prices and wages %%
  GAM0(eq_caputl_F,v_ks_F) =  1;
  GAM1(eq_caputl_F,v_k_F ) =  1;
  GAM0(eq_caputl_F,v_z_F ) = -1;
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      6. Rental Rate of Capital               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_capsrv,v_z ) =  1;
  GAM0(eq_capsrv,v_rk) = -(1-ppsi)/ppsi;

  %% flexible prices and wages %%
  GAM0(eq_capsrv_F,v_z_F ) =  1;
  GAM0(eq_capsrv_F,v_rk_F) = -(1-ppsi)/ppsi;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      7. Evolution of Capital                 %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% changed v_ia from (1-(1-del)/gam)*(1+bet*gam^(1-sigmac))*gam^2*varphi %%

  %% sticky prices and wages %%
  GAM0(eq_capev,v_k ) =  1;
  GAM0(eq_capev,v_ia) = -(1-(1-del)/gam)*gam^2*varphi*(1+bet*gam^(1-sigmac));
  GAM0(eq_capev,v_i ) = -(1-(1-del)/gam);
  GAM1(eq_capev,v_k ) =  (1-del)/gam;

  %% flexible prices and wages %%
  GAM0(eq_capev_F,v_k_F ) =  1;
  GAM0(eq_capev_F,v_ia  ) = -(1-(1-del)/gam)*gam^2*varphi*(1+bet*gam^(1-sigmac));
  GAM0(eq_capev_F,v_i_F ) = -(1-(1-del)/gam);
  GAM1(eq_capev_F,v_k_F ) =  (1-del)/gam;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      8. Price Markup                       %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %% sticky prices and wages %% 
  GAM0(eq_mkupp,v_mup) =  1;
  GAM0(eq_mkupp,v_ks ) = -alp;
  GAM0(eq_mkupp,v_l  ) =  alp;
  GAM0(eq_mkupp,v_a  ) = -1;
  GAM0(eq_mkupp,v_w  ) =  1;
  
  %% flexible prices and wages %%
  GAM0(eq_mkupp_F,v_ks_F ) = -alp;
  GAM0(eq_mkupp_F,v_l_F  ) =  alp;
  GAM0(eq_mkupp_F,v_a    ) = -1;
  GAM0(eq_mkupp_F,v_w_F  ) =  1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      9. Phillips Curve                     %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_phlps,v_pi ) =  1;
  GAM0(eq_phlps,v_Epi) = -bet*gam^(1-sigmac)/(1+bet*gam^(1-sigmac)*iotap);
  GAM0(eq_phlps,v_mup) =  (1-xip)/xip*1/((capphi-1)*epsp+1)*1/(1+bet*gam^(1-sigmac)*iotap)*(1-bet*gam^(1-sigmac)*xip);
  GAM0(eq_phlps,v_lp ) = -1;
  GAM1(eq_phlps,v_pi ) = iotap/(1+bet*gam^(1-sigmac)*iotap);

  %% flexible prices and wages %%
  %% not necesary %%

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%     10. Rental Rate of Capital            %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_caprnt,v_rk) =  1;
  GAM0(eq_caprnt,v_ks) =  1;	
  GAM0(eq_caprnt,v_l ) = -1;
  GAM0(eq_caprnt,v_w ) = -1;

  %% flexible prices and wages %%
  GAM0(eq_caprnt_F,v_rk_F) =  1;
  GAM0(eq_caprnt_F,v_ks_F) =  1; 
  GAM0(eq_caprnt_F,v_l_F ) = -1;
  GAM0(eq_caprnt_F,v_w_F ) = -1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%     11. Wage Markup                       %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_mkupw,v_muw) =  1;
  GAM0(eq_mkupw,v_w  ) = -1;
  GAM0(eq_mkupw,v_l  ) =  sigmal;
  GAM0(eq_mkupw,v_c  ) =  1/(1-h/gam);
  GAM1(eq_mkupw,v_c  ) =  (h/gam)/(1-h/gam);

  %% flexible prices and wages %%
  GAM0(eq_mkupw_F,v_w_F  ) = -1;
  GAM0(eq_mkupw_F,v_l_F  ) =  sigmal;
  GAM0(eq_mkupw_F,v_c_F  ) =  1/(1-h/gam);
  GAM1(eq_mkupw_F,v_c_F  ) =  (h/gam)/(1-h/gam);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%     12. Evolution of Wages               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %% sticky prices and wages %%
  GAM0(eq_wage,v_w  ) =  1;
  GAM0(eq_wage,v_Ew ) = -(1-1/(1+bet*gam^(1-sigmac)));
  GAM0(eq_wage,v_Epi) = -(1-1/(1+bet*gam^(1-sigmac)));
  GAM0(eq_wage,v_pi ) =  (1+bet*gam^(1-sigmac)*iotaw)/(1+bet*gam^(1-sigmac));
  GAM0(eq_wage,v_muw) =  1/(1+bet*gam^(1-sigmac))*(1-bet*gam^(1-sigmac)*xiw)*(1-xiw)/(xiw*((lamw-1)*epsw+1));
  GAM0(eq_wage,v_lw ) = -1;
  GAM1(eq_wage,v_w  ) =  1/(1+bet*gam^(1-sigmac));
  GAM1(eq_wage,v_pi ) =  iotaw/(1+bet*gam^(1-sigmac));

  %% flexible prices and wages %%
  %% not necessary %%

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%    13. Monetary Policy Rule               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %% sticky prices and wages %%
  GAM0(eq_mp,v_r  )   =  1;
  GAM1(eq_mp,v_r  )   =  rho;
  GAM0(eq_mp,v_pi )   = -(1-rho)*rpi;
  GAM0(eq_mp,v_y  )   = -(1-rho)*ry-rdely;
  GAM1(eq_mp,v_y  )   = -rdely;
  GAM0(eq_mp,v_y_F)   =  (1-rho)*ry+rdely;
  GAM1(eq_mp,v_y_F)   =  rdely;
  GAM0(eq_mp,v_mp )   = -1;

  %% flexible prices and wages %%
  %% not necessary %%

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%   14. Resource Constraint               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% sticky prices and wages %%
  GAM0(eq_res,v_y) =  1;
  GAM0(eq_res,v_c) = -c_y;
  GAM0(eq_res,v_i) = -i_y;
  GAM0(eq_res,v_z) = -z_y;
  GAM0(eq_res,v_g) = -1;
  
  %% flexible prices and wages %%
  GAM0(eq_res_F,v_y_F) =  1;
  GAM0(eq_res_F,v_c_F) = -c_y;
  GAM0(eq_res_F,v_i_F) = -i_y;
  GAM0(eq_res_F,v_z_F) = -z_y;
  GAM0(eq_res_F,v_g  ) = -1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%   Exogenous Processes                     %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %% government spending %%
  GAM0(eq_g,v_g) =  1;
  GAM1(eq_g,v_g) =  rhog;
  PSI(eq_g,e_g)  =  1;
  PSI(eq_g,e_a)  =  rhoga;
 
  %% asset shock %%
  GAM0(eq_b,v_b) =  1;
  GAM1(eq_b,v_b) =  rhob;
  PSI(eq_b,e_b)  =  1;
  
  %% investment specific tech change %%
  GAM0(eq_ia,v_ia) = 1;
  GAM1(eq_ia,v_ia) = rhoi;
  PSI(eq_ia,e_ia)  = 1;
 
  %% neutral technology %%
  GAM0(eq_a,v_a) = 1;
  GAM1(eq_a,v_a) = rhoa;
  PSI(eq_a,e_a) = 1;
  
  %% price mark-up shock %%
  GAM0(eq_lp,v_lp)  =  1;
  GAM1(eq_lp,v_lp)  =  rhop;
  GAM1(eq_lp,v_lp1) = -mup;
  PSI(eq_lp,e_lp)  =  1;
 
  GAM0(eq_lp1,v_lp1) = 1;
  PSI(eq_lp1,e_lp ) = 1;
 
  %% wage mark-up shock %%
  GAM0(eq_lw,v_lw)  =  1;
  GAM1(eq_lw,v_lw)  =  rhow;
  GAM1(eq_lw,v_lw1) = -muw;
  PSI(eq_lw,e_lw)   =  1;
 
  GAM0(eq_lw1,v_lw1) = 1;
  PSI(eq_lw1,e_lw ) = 1;
  
  %% monetary policy shock %%
  GAM0(eq_mps,v_mp) = 1;
  GAM1(eq_mps,v_mp) = rhor;
  PSI(eq_mps,e_mp) = 1;
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%    Rational Expectations Errors       %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% E(c) %%
  %% sticky prices and wages %%
  GAM0(eq_Ec,v_c ) = 1;
  GAM1(eq_Ec,v_Ec) = 1;
  PPI(eq_Ec,n_c ) = 1;
  
  %% flexible prices and wages %%
  GAM0(eq_Ec_F,v_c_F ) = 1;
  GAM1(eq_Ec_F,v_Ec_F) = 1;
  PPI(eq_Ec_F,n_c_F ) = 1;
  
  %% E(q) %%
  %% sticky prices and wages %%
  GAM0(eq_Eq,v_q ) = 1;
  GAM1(eq_Eq,v_Eq) = 1;
  PPI(eq_Eq,n_q ) = 1;

  %% flexible prices and wages %%
  GAM0(eq_Eq_F,v_q_F ) = 1;
  GAM1(eq_Eq_F,v_Eq_F) = 1;
  PPI(eq_Eq_F,n_q_F) = 1;
 
  %% E(i) %%
  %% sticky prices and wages %%
  GAM0(eq_Ei,v_i ) = 1;
  GAM1(eq_Ei,v_Ei) = 1;
  PPI(eq_Ei,n_i ) = 1;
  
  %% flexible prices and wages %%
  GAM0(eq_Ei_F,v_i_F ) = 1;
  GAM1(eq_Ei_F,v_Ei_F) = 1;
  PPI(eq_Ei_F,n_i_F ) = 1;

  %% E(pi) %%
  %% sticky prices and wages %%
  GAM0(eq_Epi,v_pi ) = 1;
  GAM1(eq_Epi,v_Epi) = 1;
  PPI(eq_Epi,n_pi ) = 1;
 
  %% E(l) %%
  %% sticky prices and wages %%
  GAM0(eq_El,v_l ) = 1;
  GAM1(eq_El,v_El) = 1;
  PPI(eq_El,n_l ) = 1;
  
  %% flexible prices and wages %%
  GAM0(eq_El_F,v_l_F ) = 1;
  GAM1(eq_El_F,v_El_F) = 1;
  PPI(eq_El_F,n_l_F ) = 1;

  %% E(rk) %%
  %% sticky prices and wages %%
  GAM0(eq_Erk,v_rk ) = 1;
  GAM1(eq_Erk,v_Erk) = 1;
  PPI(eq_Erk,n_rk ) = 1;
  
  %% flexible prices and wages %%
  GAM0(eq_Erk_F,v_rk_F ) = 1;
  GAM1(eq_Erk_F,v_Erk_F) = 1;
  PPI(eq_Erk_F,n_rk_F ) = 1;
  
  %% E(w) %%
  %% sticky prices and wages %%
  GAM0(eq_Ew,v_w ) = 1;
  GAM1(eq_Ew,v_Ew) = 1;
  PPI(eq_Ew,n_w ) = 1;

  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%    Augmentation                       %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %% y %%
  GAM0(eq_ylag,v_ylag) = 1;
  GAM1(eq_ylag,v_y)    = 1;
  
  %% c %%
  GAM0(eq_clag,v_clag) = 1;
  GAM1(eq_clag,v_c)    = 1;
  
  %% i %%
  GAM0(eq_ilag,v_ilag) = 1;
  GAM1(eq_ilag,v_i)    = 1;

  %% w %%
  GAM0(eq_wlag,v_wlag) = 1;
  GAM1(eq_wlag,v_w)    = 1;


  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      QZ(generalized Schur) decomposition by GENSYS
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  [T1,TC,T0,TY,M,TZ,GEV,RC] = gensys(GAM0,GAM1,C,PSI,PPI,1+1E-8);
  format long
% $$$   save('-ascii', 'GAM0.txt', 'GAM0')
% $$$   save('-ascii', 'GAM1.txt', 'GAM1')
% $$$   save('-ascii', 'PSI.txt', 'PSI')
% $$$   save('-ascii', 'PPI.txt', 'PPI')
 
  varargout{1} = T1;
  varargout{2} = TC;
  varargout{3} = T0;
  varargout{4} = RC;
  varargout{6} = GAM0;
  varargout{7} = GAM1;
  varargout{8} = C;
  varargout{9} = PSI;


end