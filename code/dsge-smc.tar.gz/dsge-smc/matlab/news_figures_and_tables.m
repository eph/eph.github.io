%%% nes_figures_and_tables.m --- 
%% 
%% Description: 
%% 
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 09/16/13
%% 
clear all

addpath('~/code/test')
addpath('~/code/test/MiscClasses')
addpath('~/code/matlab/mc')
addpath('~/code/matlab/misc')
addpath('~/code/matlab/dsge/prior')
addpath('~/code/matlab/misc/kde2d')
addpath('/mq/DSGE/production/pdfbox')

base = '~/code/fortran/models/news/';

parafile = strcat(base, 'news_spec.txt');
news_para = Parameters.read_from_textfile(parafile);
names = {'paranames', news_para};

% Read in regular prior.
regular_priofile = strcat(base, 'prior.txt');
news_regular_prior = Prior.read_from_frankfile(regular_priofile, names{:});
reg_prior_set = {news_regular_prior, 'prior', 'Regular Prior'};
mask = {'pmask', news_regular_prior.pmask};

% Read in regular prior RWMH/SMC runs.
smcruns = get_file_list('input/news_smc_standard.txt');
smc_set = {smcruns, 'smc'};

rwmhruns = get_file_list('input/news_rwmh_standard.txt');
rwmh_set = {rwmhruns, 'huge-rwmh'};

fprintf('Reading regular posteriors......')
regular_set = {rwmh_set, smc_set};
regular_rwmh_vs_smc = AlgorithmComparison(regular_set, names{:}, mask{:});
fprintf('DONE.\n')


% Read in diffuse posterior
smcruns = get_file_list('input/news_smc_diffuse.txt');
smc_set = {smcruns, 'smc'};

rwmhruns = get_file_list('input/news_rwmh_diffuse.txt');
rwmh_set = {rwmhruns, 'huge-rwmh'};

fprintf('Reading regular posteriors......')
diffuse_set = {rwmh_set, smc_set};
diffuse_rwmh_vs_smc = AlgorithmComparison(regular_set, names{:}, mask{:});
fprintf('DONE.\n')


%------------------------------------------------------------------------------
% Table 4 -- News Posterior
%------------------------------------------------------------------------------
parasel = {'sigzi4', 'sigg8', 'sigzi8', 'thet', 'sigzi0', 'sigg0', ...
           'kap', 'sigzet4', 'sigzet0', 'sigzet8', 'sigmu4', 'sigmu8'};


fprintf('\\begin{table}[t!]\n')
fprintf('\\begin{center}\n')
fprintf('\\caption{\\sc{Posterior Comparison for News Model}}\n')
fprintf('\\label{tab:news-posterior}\n')
fprintf('    \\vspace*{1cm}\n')
fprintf('\\begin{tabular}{l@{\\hspace*{0.5cm}}cccr@{\\hspace*{1cm}}cccr} \\hline\\hline\n')
fprintf('          & \\multicolumn{4}{c}{SMC} & \\multicolumn{4}{c}{RWMH} \\\\\n')
fprintf('Parameter & Mean & $[0.05, 0.95]$ & STD(Mean) & $N_{eff}$ & Mean & $[0.05, 0.95]$ & STD(Mean) & $N_{eff}$ \\\\ \\hline\n')
rne = regular_rwmh_vs_smc.RNE(2, parasel);
fprintf('\\hline\\hline\n')
fprintf('\\end{tabular}\n')
fprintf('\\end{center}\n')
fprintf('{\\it Notes:} Means and standard deviations are over 20 runs for\n')
fprintf('  each algorithm.  The RWMH algorithms use 10 million draws with the\n')
fprintf('  first 5 million discarded. The SMC algorithms use 30,048 particles and 500 stages.\n')
fprintf('  The two algorithms\n')
fprintf('  utilize approximately the same computational resources.\n')
fprintf('  We define   $N_{eff} = \\hat{\\mathbb{V}}_{\\pi}[\\theta] / STD^2$.\n')
fprintf('\\end{table}\n')

%------------------------------------------------------------------------------
% Table 5 -- News MDD
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:news-mdd', ...
            'tab_caption', 'news Model: Regular Prior Log MDD Estimates'};

standard_mdd = regular_rwmh_vs_smc.mdd_table(tab_args{:});
diffuse_mdd = diffuse_rwmh_vs_smc.mdd_table(tab_args{:});

fprintf('\\begin{table}[t!]\n')
fprintf('  \\begin{center}\n')
fprintf('    \\caption{\\sc{Log MDD Estimates for News Model}}\n')
fprintf('    \\label{tab:news-mdd}\n')
fprintf('    \\vspace*{1cm}\n')
fprintf('    \\begin{tabular}{lcc}\n')
fprintf('      \\hline\\hline\n')
fprintf('      Algorithm (Method) & MEAN(Log MDD) & STD(Log MDD) \\\\ \\hline\n')
fprintf('      \\multicolumn{3}{c}{Standard Prior} \\\\ \\hline\n')
fprintf('      SMC  (Particle Estimate) & %-7.3f & %5.2f \\\\\n', standard_mdd(2, :))
fprintf('      RWMH (Modified Harmonic Mean) & %-7.3f & %5.2f \\\\ \\hline\n', standard_mdd(1, :))
fprintf('      \\multicolumn{3}{c}{Diffuse Prior} \\\\ \\hline\n')
fprintf('      SMC (Particle Estimate)       & %-7.3f       & %5.2f \\\\\n', diffuse_mdd(2, :))
fprintf('      RWMH (Modified Harmonic Mean) & %-7.3f       & %5.2f \\\\\n', diffuse_mdd(1, :))
fprintf('      \\hline\\hline\n')
fprintf('    \\end{tabular}\n')
fprintf('  \\end{center}\n')
fprintf('  {\\it Notes:} Means and standard deviations are over 20 runs for\n')
fprintf('  each algorithm.\n')
fprintf('\\end{table}\n')



%
%
% Figures
%
%
%

%------------------------------------------------------------------------------
% Figure 5 -- News Model: Wage Markup
%------------------------------------------------------------------------------
box_para = {'rhom', 'sigmu0', 'sigmu4', 'sigmu8'};
box_grid = {linspace(0.9, 1, 11), linspace(0, 8, 22), linspace(0, 8, 22), linspace(0, 8, 22)};
regular_rwmh_vs_smc.hist_boxplot(box_para, box_grid, ...
                                 'file', 'figures/news_m.eps', 'ylim', [0, 0.4]);


fprintf('\\begin{figure}[t!]\n')
fprintf('\\begin{center}\n')
fprintf('\\caption{\\sc{News Model: RWMH and SMC Histogram of Wage Markup Process}}\n')
fprintf('\\label{fig:news-mu}\n')
fprintf('\\includegraphics[width=4.5in]{figures/news_m.pdf}\n')
fprintf('\\end{center}\n')
fprintf('{{\\it Notes}: The boxes show estimates of histograms from each of the simulators.  The\n')
fprintf('  RWMH algorithm is in red and the SMC is in black. Each box is centered at the\n')
fprintf('  mean of the number of elements in each, while the height of the box indicates\n')
fprintf('  plus or minus two standard deviations around this mean.}\n')
fprintf('\\end{figure}\n')


%------------------------------------------------------------------------------
% Figure 6 -- News Model: Gamma
%------------------------------------------------------------------------------
regular_rwmh_vs_smc.hist_boxplot('gam', [0.0 0.01 linspace(0.1, 1, 20)], 'file', 'figures/news_gam_full.eps');
regular_rwmh_vs_smc.hist_boxplot('gam', linspace(0.0, 1, 22), 'file', 'figures/news_gam.eps');
diffuse_rwmh_vs_smc.hist_boxplot('gam', linspace(0, 1, 22), 'file', 'figures/news_gam_diffuse.eps');
fprintf('\\begin{figure}[t!]\n')
fprintf('\\begin{center}\n')
fprintf('\\caption{\\sc{News Model: RWMH and SMC Histograms of $\\gamma$}}\n')
fprintf('\\label{fig:news-gam}\n')
fprintf('\\includegraphics[height=2.3in]{figures/news_gam_full_crop.pdf}\n')
fprintf('\\includegraphics[height=2.25in]{figures/news_gam.pdf}\n')
fprintf('\\hspace*{1cm}\n')
fprintf('\\includegraphics[height=2.25in]{figures/news_gam_diffuse.pdf}\n')
fprintf('\\end{center} {\\em Notes:} The boxes show estimates of histograms from each of\n')
fprintf('the simulators.  The RWMH algorithm is in red and the SMC is in black. The left\n')
fprintf('panel shows output from the standard prior model and the right panel shows\n')
fprintf('output from the diffuse prior model.  Each box is centered at the mean of the\n')
fprintf('number of elements in each, while the height of the box indicates plus or minus\n')
fprintf('two standard deviations around this mean.\n')
fprintf('\\end{figure}\n')



%------------------------------------------------------------------------------
% Figure 7 -- News Model: Variance Decompositions
%------------------------------------------------------------------------------
% see fig_news_hours_decomp.m
% $$$ 






%
%
% Appendix
%
%

%------------------------------------------------------------------------------
% Figure 6 -- Bivariate Contour Plot of sigmu4 and sigmu8
%------------------------------------------------------------------------------
smc = regular_rwmh_vs_smc.algorun(2).mc(1);

cont_para = {'sigmu4', 'sigmu8'};
fout = 'figures/news_bivariate_mu.eps';
smc.kde2d(cont_para, 'file', fout, 'xlim', [0.0, 8], 'ylim', [0.0, 8], 'line45', false, 'q0', 0.55);



%------------------------------------------------------------------------------
% Table A6 -- News Regular Prior 
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:news-prior', ...
            'tab_caption', 'News Model: SGU Prior Distribution'};
news_regular_prior.latex_table(tab_args{:});
fprintf('\n\n')


%------------------------------------------------------------------------------
% Table A7 -- News Regular Prior Posterior
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:news-pos', ...
            'tab_caption', 'Posterior Comparison for News Model (SGU Prior)'};
tab_para = find(1-news_regular_prior.pmask);
regular_rwmh_vs_smc.posterior_table(tab_para, tab_args{:});
fprintf('\n\n')


