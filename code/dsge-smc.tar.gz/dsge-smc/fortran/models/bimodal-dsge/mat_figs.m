% Creating some figures in matlab.
clf
addpath('/mq/home/m1eph00/projects/chandrasekhar-recursions/matlab/filter')

y = load('data.txt');

y = y(1:200);

TT = @(x) [x(1)^2, 0; -x(1)*x(2) + 1 - x(1)^2, 1 - x(1)^2]

lik = @(y, x) kf(y, TT(x), [1;0], 1, 0, [1, 1], 0, 0);

lik(y, [0.45, 0.45])
lik(y, [sqrt(1-0.45^2), 1/sqrt(1-0.45^2)-sqrt(1-0.45^2)])


ngrid = 99
% $$$ lnpy = zeros(ngrid, ngrid);
% $$$ x = 0.01:0.01:0.99;
% $$$ 
% $$$ for i = 1:99
% $$$     for j = 1:99
% $$$         lnpy(i, j) = lik(y, [x(i), x(j)]);
% $$$         lnpy(i, j);
% $$$     end
% $$$ end
hold on

level = -325:1:-305;
colormap('summer')
contourf(x, x, lnpy', level)
xlabel('\theta_1')
ylabel('\theta_2')


basedir = '/mq/scratch/m1eph00/smc-bimodal-dsge-npart-1024-nintmh-1-nphi-500-prior-b1-trial1/'

pfile = strcat(basedir, '500parasim.txt')
wfile = strcat(basedir, '500wtsim.txt')

p = load(pfile); 
w=load(wfile); 
[id, ~]=systematic_resampling(w', rand); 
p = p(id, :); 

scatter(p(1:190, 1), p(1:190, 2), 'filled',  'black')

mcmcfile = '/mq/scratch/m1eph00/rwmh-bimodal-dsge/parasim.txt';
p = load(mcmcfile);
scatter(p(500:50:10000, 1), p(500:50:10000, 2), 'filled', 'red');

hold off 
clf
hold on
pfile = strcat(basedir, '***parasim.txt'); wfile = strcat(basedir, '***wtsim.txt');
p = load(pfile); w=load(wfile); [id, ~]=systematic_resampling(w', rand); p = p(id, :); 
ksdensity(p(:, 1), 'red')
pfile = strcat(basedir, '100parasim.txt'); wfile = strcat(basedir, '100wtsim.txt');
p = load(pfile); w=load(wfile); [id, ~]=systematic_resampling(w', rand); p = p(id, :); 
ksdensity(p(:, 1))
pfile = strcat(basedir, '200parasim.txt'); wfile = strcat(basedir, '200wtsim.txt');
p = load(pfile); w=load(wfile); [id, ~]=systematic_resampling(w', rand); p = p(id, :); 
ksdensity(p(:, 1))
pfile = strcat(basedir, '300parasim.txt'); wfile = strcat(basedir, '300wtsim.txt');
p = load(pfile); w=load(wfile); [id, ~]=systematic_resampling(w', rand); p = p(id, :); 
ksdensity(p(:, 1))
pfile = strcat(basedir, '500parasim.txt'); wfile = strcat(basedir, '500wtsim.txt');
p = load(pfile); w=load(wfile); [id, ~]=systematic_resampling(w', rand); p = p(id, :); 
ksdensity(p(:, 1))
title('Density Estimates for p_n(\theta_1|Y)')