%%% news_construct_moments.m --- 
%% 
%% Description: Takes parameter draws from 'base' + 'nphi' (= '' RWMH), and
%%   computes model implied moments of the observables.  
%% 
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 09/16/13
%% 

spec_news
addpath(strcat(basedir,'/dsge/models/news'));
addpath(strcat(basedir,'/dsge/gensys'));
addpath('sgu-comparison/sgu-code')

nphi = '500' 
base = '/mq/scratch/m1eph00/dsge-smc/draft-2/news/smc/standard/smc-news-new-mix-npart-30048-nintmh-1-nphi-500-prior-b6-trial6-phibend/'


parafile = strcat(nphi, 'parasim.txt');

para1 = load(strcat(base, parafile));

if strcmp(nphi, '')                     
    nsim = size(para1, 1);
    para1 = para1(500000:100:nsim, :);
end


nsim = size(para1, 1);

astd = zeros(nsim, 7);
acor = zeros(nsim, 7);
aant = zeros(nsim, 7);

vdcmp = zeros(nsim, 7*22);
matlabpool open local 8
parfor i = 1:nsim
      vdcmp(i, :) = full_decomp(para1(i, :)');
%    [astd(i, :), acor(i, :), aant(i, :)] = decomp(para1(i, :)');
end
matlabpool close
save('-ascii', strcat(base, nphi, 'vdcmp.txt'), 'vdcmp');
% $$$ save('-ascii', strcat(base, nphi, 'std.txt'), 'astd');
% $$$ save('-ascii', strcat(base, nphi, 'corr.txt'), 'acor');
% $$$ save('-ascii', strcat(base, nphi, 'anticipated_share.txt'), 'aant');