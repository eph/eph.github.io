function [ind_s, ind_eps, ind_acpt] = mutation_RWMH(s0, eps0, Phi, sqrtS2, A, B, H, yy, tune)
% RWMH for mutation step


% RW proposal
epsx = eps0 + tune.c*chol(tune.R)'*randn(size(tune.R,1),1);

 sx_fore   = Phi*s0 + sqrtS2*epsx;
 s0_fore   = Phi*s0 + sqrtS2*eps0;
        
 perrorx = yy'-A - B*sx_fore;
 perror0 = yy'-A - B*s0_fore;
    
 postx = log(mvnpdf(perrorx', zeros(1,size(yy,2)), H)*mvnpdf(epsx'));
 post0 = log(mvnpdf(perror0', zeros(1,size(yy,2)), H)*mvnpdf(eps0'));

% Accept/Reject
alp = exp(postx - post0); % this is RW, so q is canceled out
if rand < alp % accept
    ind_s   = sx_fore;
    ind_eps  = epsx;
    ind_acpt   = 1;
else
    ind_s   = s0_fore;
    ind_eps  = eps0;
    ind_acpt   = 0;
end

% % outside of function
% parasim(i,j,:) = ind_para;
% loglh(j)       = ind_loglh;
% temp_acpt(j,1) = ind_acpt;
