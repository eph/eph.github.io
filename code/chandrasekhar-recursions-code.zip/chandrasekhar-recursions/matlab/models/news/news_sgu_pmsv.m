function para = news_sgu_pmsv()
thet= 	 	5.391074768466587;
gam = 		0.002185459183159;
kap       =	25.070737126434982;
del2_del1 = 	0.437424411405766;
b         =	0.928096009137826;
rhoxg     =	0.732796295529521;

rhoz   =       0.947889811865346;
rhoa   =       0.479642682043620;
rhog   =       0.952236769574842;
rhox   =       0.271551460749151+0.5;
rhom   =       0.972156137756487;
rhozet =       0.099915155559631;
rhozi  =       0.208756420031805;
alpk      = 0.225;
alph      = 0.675;
del0      = 0.025;
bet       = 0.99;
hss       = 0.20;
muss      = 0.15;
muass     = 0.9957;
muxss     = 1.00324407709013;
sig       = 1;
g_y       = 0.2;
sigmua0   = 0.162050841738623;
sigmua4	  = 0.197647876901814;
sigmua8	  = 0.187612606612498;
sigmux0   = 0.451364773252677;
sigmux4	  = 0.116807952048844;
sigmux8	  = 0.122579250799784;
sigzi0    = 34.813163825347871; 
sigzi4	  = 11.986095767601309; 
sigzi8	  = 14.908125488732368; 
sigz0     = 0.620700579189226;
sigz4	  = 0.112322391783455;
sigz8	  = 0.113336251904142;
sigmu0    = 1.511087229244606; 
sigmu4	  = 3.932906965349178; 
sigmu8	  = 3.198395880370730; 
sigg0     = 0.531014250285291; 
sigg4	  = 0.688557661528428; 
sigg8	  = 0.434035500465772; 
sigzet0   = 2.827023982975568; 
sigzet4	  = 2.760750599253194; 
sigzet8	  = 5.338103984144542; 
sigygr    = 0.299530635386202;

para = [thet; gam; kap; del2_del1; b; rhoxg; rhoz; rhoa; rhog; rhox; rhom;
        rhozet; rhozi; alpk; alph; del0; bet; hss; muss; muass; 
        muxss; sig; g_y;sigmua0; sigmua4; sigmua8; sigmux0; sigmux4; sigmux8;
        sigzi0; sigzi4; sigzi8; sigz0; sigz4; sigz8; sigmu0; sigmu4; sigmu8;
        sigg0; sigg4; sigg8; sigzet0; sigzet4; sigzet8; sigygr];


 
end