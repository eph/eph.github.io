%% Figure: Waterfall plot
fig = figure(1);

subplot(2,2,1)
parai = 2; % kappa
itsel = 1:1:tune.nphi;
nsel  = length(itsel);

bins = 0:0.01:1;
post = zeros(nsel, length(bins));
for i = 1:nsel
    
    phisel  = itsel(i);
    para    = squeeze(parasim(phisel, :, parai));
    [id, m] = multinomial_resampling(wtsim(:, phisel)');
    para    = para(id);
    
    post(i, :) = ksdensity(para, bins);
end

colscale = (0.65:-0.05:0);
colormap(repmat(colscale', 1, 3));

phigrid = (1:1:tune.nphi)';
waterfall(bins, phigrid, post)

set(gca, 'linewidth', 1, 'fontsize', 15)
xlabel(['$\kappa$'], 'fontsize', 20, 'interpreter', 'latex')
ylabel(['$N_{\phi}$'], 'fontsize', 20, 'interpreter', 'latex')

subplot(2,2,2)
parai = 7; % gammaQ
itsel = 1:1:tune.nphi;
nsel  = length(itsel);

bins = 0:0.01:1;
post = zeros(nsel, length(bins));
for i = 1:nsel
    
    phisel  = itsel(i);
    para    = squeeze(parasim(phisel, :, parai));
    [id, m] = multinomial_resampling(wtsim(:, phisel)');
    para    = para(id);
    
    post(i, :) = ksdensity(para, bins);
end

colscale = (0.65:-0.05:0);
colormap(repmat(colscale', 1, 3));

phigrid = (1:1:tune.nphi)';
waterfall(bins, phigrid, post)

set(gca, 'linewidth', 1, 'fontsize', 15)
xlabel(['$\gamma^{(Q)}$'], 'fontsize', 20, 'interpreter', 'latex')
ylabel(['$N_{\phi}$'], 'fontsize', 20, 'interpreter', 'latex')

subplot(2,2,3)
parai = 8; % rho_r
itsel = 1:1:tune.nphi;
nsel  = length(itsel);

bins = 0:0.01:1;
post = zeros(nsel, length(bins));
for i = 1:nsel
    
    phisel  = itsel(i);
    para    = squeeze(parasim(phisel, :, parai));
    [id, m] = multinomial_resampling(wtsim(:, phisel)');
    para    = para(id);
    
    post(i, :) = ksdensity(para, bins);
end

colscale = (0.65:-0.05:0);
colormap(repmat(colscale', 1, 3));

phigrid = (1:1:tune.nphi)';
waterfall(bins, phigrid, post)

set(gca, 'linewidth', 1, 'fontsize', 15)
xlabel(['$\rho_{r}$'], 'fontsize', 20, 'interpreter', 'latex')
ylabel(['$N_{\phi}$'], 'fontsize', 20, 'interpreter', 'latex')

subplot(2,2,4)
parai = 11; % sigma_r
itsel = 1:1:tune.nphi;
nsel  = length(itsel);

bins = 0:0.01:1;
post = zeros(nsel, length(bins));
for i = 1:nsel
    
    phisel  = itsel(i);
    para    = squeeze(parasim(phisel, :, parai));
    [id, m] = multinomial_resampling(wtsim(:, phisel)');
    para    = para(id);
    
    post(i, :) = ksdensity(para, bins);
end

colscale = (0.65:-0.05:0);
colormap(repmat(colscale', 1, 3));

phigrid = (1:1:tune.nphi)';
waterfall(bins, phigrid, post)

set(gca, 'linewidth', 1, 'fontsize', 15)
xlabel(['$\sigma_{r}$'], 'fontsize', 20, 'interpreter', 'latex')
ylabel(['$N_{\phi}$'], 'fontsize', 20, 'interpreter', 'latex')
