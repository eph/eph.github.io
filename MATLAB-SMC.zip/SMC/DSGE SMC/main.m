%==========================================================================
%                       DSGE MODEL ESTIMATION 
%                   Sequential Monte Carlo Algorithm
%                  (Small NK model in the textbook)
%
% Author: Minsu Chang        minsuc@sas.upenn.edu
% Last modified: 3/3/2016
%==========================================================================

%=========================================================================
%                            Housekeeping
%=========================================================================

close all
clear
clc
delete *.asv
path('Mfiles',path);
path('Optimization Routines',path);
path('LRE',path);
path('toolbox_ss',path);

picPath = [pwd, '/Figures/'];

%=========================================================================
%                            Load data
%=========================================================================
data = load('us.txt');
       
%=========================================================================
%                     Specify parameters of prior
%=========================================================================
prio= load('prior_dsge.txt');
 
pshape   = prio(:,1);
pmean    = prio(:,2);
pstdd    = prio(:,3);
pmask    = prio(:,4);
pfix     = prio(:,5);
pmaskinv = 1- pmask;
pshape   = pshape.*pmaskinv;

bounds   = load('bound_dsge.txt');

%=========================================================================
%                       Set Parameters of Algorithm
%=========================================================================

% General
tune.npara = 13;       % # of parameters
tune.npart = 1000;   % # of particles
tune.nphi  = 100;      % # of stages
tune.lam   = 2;     % # bending coeff, lam = 1 means linear cooling schedule

% Tuning for MH algorithms
%tune.nblock = 1;                    % Number of random blocks
tune.c      = 0.5;                  % initial scale cov
tune.acpt   = 0.25;                 % initial acpt rate
tune.trgt   = 0.25;                 % target acpt rate
tune.alp    = 0.9;                  % Mixture weight for mixture proposal

% Create the tempering schedule
tune.phi = (1:1:tune.nphi)';
tune.phi = ((tune.phi-1)/(tune.nphi-1)).^tune.lam;


% Define a function handle for Posterior evaluation

f = @(x1,x2) objfcn_dsge(x1,x2,prio,bounds,data);
 
% Matrices for storing

parasim = zeros(tune.nphi, tune.npart, tune.npara); % parameter draws
wtsim   = zeros(tune.npart, tune.nphi);        % weights
zhat    = zeros(tune.nphi,1);                  % normalization constant
nresamp = 0; % record # of iteration resampled

csim    = zeros(tune.nphi,1); % scale parameter
ESSsim  = zeros(tune.nphi,1); % ESS
acptsim = zeros(tune.nphi,1); % average acceptance rate
rsmpsim = zeros(tune.nphi,1); % 1 if re-sampled

%=========================================================================
%             Initialize Algorithm: Draws from prior
%=========================================================================

disp('                                                                  ');
disp('          SMC starts....         ');
disp('                                                                  ');

priorsim       = priodraws(prio, bounds, tune.npart);
parasim(1,:,:) = priorsim;        % from prior
wtsim(:, 1)    = 1/tune.npart;    % initial weight is equal weights
zhat(1)        = sum(wtsim(:,1));

% Posterior values at prior draws
loglh   = zeros(tune.npart,1); %log-likelihood
logpost = zeros(tune.npart,1); %log-posterior

for i=1:1:tune.npart
    p0                     = priorsim(i,:)';
    [logpost(i), loglh(i)] = f(p0,tune.phi(1)); % likelihood
end

% ------------------------------------------------------------------------
% Recursion: For n=2,...,N_{\phi}
% ------------------------------------------------------------------------
smctime   = tic;
totaltime = 0;

disp('SMC recursion starts ... ');

for i=2:1:tune.nphi
    
    %-----------------------------------
    % (a) Correction
    %-----------------------------------
    % incremental weights
    incwt = exp((tune.phi(i)-tune.phi(i-1))*loglh);
   
    % update weights
    wtsim(:, i) = wtsim(:, i-1).*incwt;
    zhat(i)     = sum(wtsim(:, i));
    
    % normalize weights
    wtsim(:, i) = wtsim(:, i)/zhat(i);
    
    %-----------------------------------
    % (b) Selection
    %-----------------------------------
    ESS = 1/sum(wtsim(:, i).^2); % Effective sample size
    
    if (ESS < tune.npart/2)
        
        [id, m] = systematic_resampling(wtsim(:,i)'); %systematic resampling
        
        parasim(i-1, :, :) = squeeze(parasim(i-1, id, :));
        loglh              = loglh(id);
        logpost            = logpost(id);
        wtsim(:, i)        = 1/tune.npart; % resampled weights are equal weights
        nresamp            = nresamp + 1;
        rsmpsim(i)         = 1;
        
    end
    
    %--------------------------------------------------------
    % (c) Mutuation
    %--------------------------------------------------------
    % Adapting the transition kernel
    
    tune.c = tune.c*(0.95 + 0.10*exp(16*(tune.acpt-tune.trgt))/(1 + ...
             exp(16*(tune.acpt-tune.trgt))));
    
    % Calculate estimates of mean and variance
    para      = squeeze(parasim(i-1, :, :));
    wght      = repmat(wtsim(:, i), 1, tune.npara);
   
    tune.mu      = sum(para.*wght); % mean
    z            = (para - repmat(tune.mu, tune.npart, 1));
    tune.R       = (z.*wght)'*z;       % covariance
    tune.Rdiag   = diag(diag(tune.R)); % covariance with diag elements
    tune.Rchol   = chol(tune.R, 'lower');
    tune.Rchol2  = sqrt(tune.Rdiag);
 
     
    % Particle mutation (RWMH 2)
    temp_acpt = zeros(tune.npart,1); %initialize accpetance indicator
    
    parfor j = 1:tune.npart %iteration over particles
 
[ind_para, ind_loglh, ind_post, ind_acpt] = mutation_RWMH(para(j,:)', ...
                                         loglh(j), logpost(j), tune, i, f); 
        parasim(i,j,:) = ind_para;
        loglh(j)       = ind_loglh;
        logpost(j)     = ind_post;
        temp_acpt(j,1) = ind_acpt;
        
    end
    
    tune.acpt = mean(temp_acpt); % update average acceptance rate
    
    % store
    csim(i,:)    = tune.c; % scale parameter
    ESSsim(i,:)  = ESS; % ESS
    acptsim(i,:) = tune.acpt; % average acceptance rate
    
    % print some information
    if mod(i, 1) == 0
        
        para = squeeze(parasim(i, :, :));
        wght = repmat(wtsim(:, i), 1, 13);

mu  = sum(para.*wght);
sig = sum((para - repmat(mu, tune.npart, 1)).^2 .*wght);
sig = (sqrt(sig));

        % time calculation
        totaltime = totaltime + toc(smctime);
        avgtime   = totaltime/i;
        remtime   = avgtime*(tune.nphi-i);
        
         % print
        fprintf('-----------------------------------------------\n')
        fprintf(' Iteration = %10.0f / %10.0f \n', i, tune.nphi);
        fprintf('-----------------------------------------------\n')
        fprintf(' phi  = %5.4f    \n', tune.phi(i));
        fprintf('-----------------------------------------------\n')
        fprintf('  c    = %5.4f\n', tune.c);
        fprintf('  acpt = %5.4f\n', tune.acpt);
        fprintf('  ESS  = %5.1f  (%d total resamples.)\n', ESS, nresamp);
        fprintf('-----------------------------------------------\n')
        fprintf('  time elapsed   = %5.2f\n', totaltime);
        fprintf('  time average   = %5.2f\n', avgtime);
        fprintf('  time remained  = %5.2f\n', remtime);
        fprintf('-----------------------------------------------\n')
        fprintf('para      mean    std\n')
        fprintf('------    ----    ----\n')
        fprintf('tau   %4.2f    %4.3f\n', mu(1), sig(1))
        fprintf('kappa   %4.2f    %4.3f\n', mu(2), sig(2))
        fprintf('psi1   %4.2f    %4.3f\n', mu(3), sig(3))
        fprintf('phi2   %4.2f    %4.3f\n', mu(4), sig(4))
        fprintf('rA   %4.2f    %4.3f\n', mu(5), sig(5))
        fprintf('piA   %4.2f    %4.3f\n', mu(6), sig(6))
        fprintf('gammaQ   %4.2f    %4.3f\n', mu(7), sig(7))
        fprintf('rho_R   %4.2f    %4.3f\n', mu(8), sig(8))
        fprintf('rho_g   %4.2f    %4.3f\n', mu(9), sig(9))
        fprintf('rho_z   %4.2f    %4.3f\n', mu(10), sig(10))
        fprintf('sigma_R   %4.2f    %4.3f\n', mu(11), sig(11))
        fprintf('sigma_g   %4.2f    %4.3f\n', mu(12), sig(12))
        fprintf('sigma_z   %4.2f    %4.3f\n', mu(13), sig(13))
        
      
        smctime = tic; % re-start clock
    end
end

% -------------------------------
%         Save the draws/paths
% -------------------------------

save Matfiles/smcdraws parasim acptsim csim ESSsim tune wtsim

%% Objects to Save

load Matfiles/smcdraws;


% -----------------------------------------------------------------------
%        Waterfall Plots
% ----------------------------------------------------------------------
figure_waterfall

print('-dpng', [picPath, 'waterfall'])

close all

% ----------------------------------------------------------------------
%         Acceptance Ratio
% ----------------------------------------------------------------------
plot(tune.phi, acptsim, 'linewidth',2.5), hold on
plot(tune.phi, tune.trgt * ones(tune.nphi,1), 'k--','linewidth',2.5)
print('-dpng',[picPath, 'acceptsim'])
hold off

% -----------------------------------------------------------------------
%           C parameter
% ----------------------------------------------------------------------

plot(tune.phi, csim, 'linewidth',2.5)
print('-dpng',[picPath, 'csim'])

% -----------------------------------------------------------------------
%           Effective Sample Size
% ----------------------------------------------------------------------

plot(tune.phi, ESSsim, 'linewidth',2.5)
print('-dpng',[picPath, 'ESSsim'])

