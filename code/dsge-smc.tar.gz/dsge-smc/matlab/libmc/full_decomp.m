%%% full_decomp.m --- 
%% 
%% Description: Function which takes parameters p, solves the DSGE model, and
%%   computes the implied covariances with and without news.  
%% 
%%   std -- implied standard deviation of observables.
%%   cor -- implied correlation with output of observables.
%%   antvar -- ratio with implied variances without and with unanticipated
%%   shocks. 
%%
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 08/16/12
%% 
function [variance_decomp] = full_decomp(p)

[sm, rc] = sysmat(p); 

[sigy, sigx] = mom(sm.ZZ/100, sm.TT, 10000*sm.RR*sm.QQ*sm.RR');

sigy(1, 1) = sigy(1, 1) + p(end)^2;

std = sqrt(diag(sigy))';
cor = sigy(1, :) ./ (std(1, 1)*std);

u = [1 4 7 10 13 16 19];
QQu = sm.QQ;
QQu(u, u) = zeros(7, 7);

variance_decomp = zeros(1, 7*22);
for i = 24:44
    
    iind = i-23;
    QQu = zeros(size(sm.QQ));
    QQu(iind, iind) = sm.QQ(iind, iind);
    [siga, sigx] = mom(sm.ZZ/100, sm.TT, 10000*sm.RR*QQu*sm.RR');
    siga = sqrt(diag(siga)');
    variance_decomp(1, (iind-1)*7+1:iind*7) = siga;
    
end

stda = sqrt(diag(siga))';


variance_decomp = (variance_decomp ./ repmat(std, 1, 22)).^2;
end