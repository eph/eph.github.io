%%% sysmat.m --- 
%% 
%% Description: System matrices for generic state space system.
%% 
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 08/12/13
%% 
function [sm, RC] = sysmat(para)


    TT = zeros(5, 5);
    RR = eye(5);
    QQ = eye(5);

    ZZ = zeros(10, 5);
    DD = zeros(10, 1);
    HH = zeros(10, 10);
    
    pwedge = 8;
    j = 6;
    for i = 1:5
        
        TT(i, i) = para(i);
        
        ZZ(i, i) = 1;
        ZZ(i+1:10, i) = para(j:j+pwedge);
        
        j = j + pwedge + 1;
        pwedge = pwedge - 1;
    end
    
    DD(:, 1) = para(41:50);
    
    for i = 1:10
        HH(i, i) = exp(para(50+i));
    end

    RC = 0;
    
    sm.TT = TT;
    sm.RR = RR;
    sm.QQ = QQ;
    
    sm.DD = DD;
    sm.ZZ = ZZ;
    sm.HH = HH;
    
end