%moments_shares_and_likelihood.m
%Computes:
%(a)  population second moments and variance decompositions of variables of interest.  
%(b)  second moments of observed empirical counterparts. 
%(c) the classical log likelihood
% In computing moments and variance decompositions, the variables of interest are, in this order:
%output growth (gy)
%consumption growth (gc)
%investment growth (giv)
%hours growth (gh)
%government spending growth (gg)
%growth rate of TFP (gtfp)
%growth rate of nonstationary  investment-specific technology (mua)
%predictions for other variables can also be accommodated. 
%Before running this problem run model.m, which creates model.mat  to create symbolic expressions for the function f, which depends on the vector of current and future states (x and xp) and controls (y and yp).  The function f defines the equilibrium conditions of the model by the implicit stochastic difference equation E_t f = 0. The first partial derivatives of f are fx fxp fy and fyp. 
%The output of this program is:
%
%(1) nfx nfy nfxp nfyp numerical expressions for the first derivatives of f
%
%(2) gx hx ETASHOCK  law of motion of x and y up to first order (see equations (7) and (8) in ``What's News in Business Cycles'') and the explanation around them. 
%
%(3) G  matrix defining the law of motion of the 7 variables of interest (gy gc giv gh gg gtfp mua)
%
%(4) stds = predicted population standard deviations of (gy gc giv gh gg gtfp mua)
%
%(5) corry = predicted population contemporaneous correlation of  (gy gc giv gh gg gtfp mua) with gy
%
%(6) autocorr = predicted population first-order autocorrelation of  (gy gc giv gh gg gtfp mua) 
%
%(7)  Estds, Ecorry, Eautocorr = empirical   (data) counterparts of stds, corry, and autocorr. 
%
%(8) Vyr a 21-by-7 matrix displaying the variance decomposition of  the 7 variables (gy gc giv gh gg gtfp mua) in the 21 shocks ordered as follows:
%stationary tech shock horizon 0 
%stationary tech shock horizon 4
%stationary tech shock horizon 8 
%nonstationary investment specific tech shock horizon 0 
%nonstationary investment specific tech shock horizon 4 
%nonstationary investment specific tech shock horizon 8 
%government spending shock horizon 0
%government spending shock horizon 4
%government spending shock horizon 8
%nonstationary neutral tech. shock horizon 0 
%nonstationary neutral tech. shock horizon 4
%nonstationary neutral tech. shock horizon 8
%wage markup shock horizon 0
%wage markup shock horizon 4
%wage markup shock horizon 8
%preference shock horizon 0
%preference shock horizon 4
%preference shock horizon 8
%stationary investment-specific tech shock horizon 0
%stationary investment-specific tech shock horizon 4
%stationary investment-specific tech shock horizon 8
%
%(9) share_news a 1-by-7 vector displaying the share of anticipated shocks in the variance of  the 7 variables (gy gc giv gh gg gtfp mua)
%
%(10) L = The log likelihood for a given vector of parameters, param_estim. L is a scalar. 
%
%
%Calls:
%gx_hx_inputs.m, gx_hx.m, mom.m, read_data.mat parameter_vector.mat, acf.m,
%variance_decomposition.m , log_like_kalman.m
%(c) Stephanie Schmitt-Grohe and Martin Uribe, 2009.

clear all


%load vector of parameter values 
load  parameter_vector.mat 
%note these parameter vectors are not ordered or transformed exactly as they appear on table 2 in the paper  ``What's News in Business Cycles.'' To obain the right order and transformation, see the beginning of the program gx_hx_inputs.m. 

%In this example, we will use the maximum likelihood estimate:
param_estim = mean_mle;

%param_estim = mean_bayesian;
%param_estim = median_bayesian;
%param_estim = median_prior;





%evaluate the derivatives of f with respect to x xp y yp
[nfx, nfy, nfxp, nfyp, nvarshock, nvarme, nETASHOCK ] = gx_hx_inputs(param_estim); 

%Obtain numerical values for the matrices defining the law of motion of the economy up to first order
[gx,hx,exitflag]=gx_hx(nfy,nfx,nfyp,nfxp);

%Collect the law of motion of the variables of interest in the matrix G. The laws of motion of the first  6 variables of interest are the first 6 rows of the matrix gx. The law of motioin of mua is in the matrix hx.  So we have to identify the location of the growth rate of the investment-specific technology shock
load model statevar_cu
ns = length(statevar_cu);
nmua = find(statevar_cu=='mua');
emua = zeros(1,ns);
emua(nmua) = 1;
%stack the law of motion of variables of interest in one matrix
GX = [gx(1:6 ,:); emua];

%Predicted Var/Cov matrix with  measurement error
varcov = mom(GX,hx,nvarshock) + nvarme;

%Standard Deviations 
stds = sqrt(diag(varcov))';

%Correlation with Output Growth
corry = varcov(1,:) ./ stds / stds(1);

%Predicted autocov matrix
autocov = mom(GX,hx,nvarshock,1);

%Serial Correlations
autocorr = diag(autocov)' ./ stds.^2;

%Empirical Moments
load read_data

Estds = std(Y);
Evarcov = cov(Y);
Ecorry = Evarcov(1,:)./Estds/Estds(1);
Eautocorr = [acf(Y(:,1)) acf(Y(:,2)) acf(Y(:,3)) acf(Y(:,4)) acf(Y(:,5)) acf(Y(:,6)) acf(Y(:,7)) ];

disp('Table 3')
disp('Standard Deviations')
disp([Estds;stds])

disp('Correlations with Output Growth')
disp([Ecorry;corry])

disp('Autocorrelations')
disp([Eautocorr;autocorr])


disp('Table 5, Variance Decomposition of [gy, gc, giv, gh ]')
%Find Variance Decomposition
Vyr =variance_decomposition(GX,hx,nETASHOCK);

share_nn = sum(Vyr([1:3:19],:));

disp('Share of variance explained by anticipated shocks')
share_news = (1- share_nn(1:4))


disp('evaluate the log  Likelihood function')
%L = log_like_kalman(Y, hx, nvarshock, GX', nvarme)