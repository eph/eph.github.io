%==========================================================================
%                       DSGE MODEL ESTIMATION:  
%           Evaluation of Likelihood with Different Filters 
%
%
% Author: Minsu Chang        minsuc@sas.upenn.edu
% Last modified: 5/17/2017
%==========================================================================


clear
clc
close all
delete *.asv

tic

l = path;

path('Mfiles',path);
path('LRE',path);
figurePath = [pwd, '\Figures\'];

% load data and consider parameters in Table 8.1.

yt      = load('us.txt');
param_m = [2.09 0.98 2.25 0.65 0.34 3.16 0.51 0.81 0.98 0.93 0.19 0.65 0.24];

[T1, ~, T0, ~, ~, ~] = model_solution(param_m);
[A,B,H,R,S2,Phi] = sysmat(T1,T0,param_m);

%============================================%
%             Kalman Filter                  %
%============================================%

[liki, measurepredi, statepredi, varstatepredi] = kalman(A,B,H,R,S2,Phi,yt);

ns      = size(B,2);
T       = size(yt,1);

% initialize
rng(111122,'twister')
x0 = zeros(ns,1);
P0 = nearestSPD(dlyap(Phi, R*S2*R'));  % to make it positive semidefinite   

N       = 500; % number of particles 

%============================================%
%         Bootstrap Particle Filter          %
%============================================%
% Last input denotes the indicator for bootstrap particle filtering.
% if == 1, it performs bootstrap particle filtering. otherwise, it does
% conditionally-optimal particle filtering.

[lik_BS, all_s_up_BS, Neff_BS] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 1,1);


%============================================%
%   Conditionally Optimal Particle Filter    %
%============================================%

[lik_CO, all_s_up_CO, Neff_CO] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 1,0);


%============================================%
%         Tempered Particle Filter           %
%============================================%

% tuning parameters (section 2.3.)

tune.rstar= 2.0;
tune.acpt = 0.5;
tune.trgt = 0.25;
tune.c    = 0.1;
tune.N_mh = 2;

[lik_TPF, all_s_up, Neff, len_phis] = tempered_PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, tune);

%% 
%=========================================================================
%           FIGURE 1: Log Likelihood Increments (Kalman vs. BSPF)
%=========================================================================

USquarter=1983.00:0.25:2002.75;
figure('Position',[20,20,900,600],'Name',...
    'Log Likelihood Increments: BSPF vs KF','Color','w')

plot(USquarter, liki,'LineStyle','-','Color','b','LineWidth',2.5) % from Kalman filter
hold on 
plot(USquarter, lik_BS,'LineStyle','--','Color','r','LineWidth',2.5) % from tempered BSPF
title('$ln \hat{p} (y_{t}|Y_{1:t-1}, \theta^{m}$) vs. $lnp(y_{t}|Y_{1:t-1}, \theta^{m})$','Interpreter','latex')
axis([USquarter(1) USquarter(end) min(min(liki), min(lik_BS))-1 max(max(liki), max(lik_BS))+1])
set(gca,'FontSize',20)

print('-dpng', [figurePath, 'Liki_KFvBS'])

%=========================================================================
%           FIGURE 2: Log Likelihood Increments (Kalman vs. COPF)
%=========================================================================

USquarter=1983.00:0.25:2002.75;
figure('Position',[20,20,900,600],'Name',...
    'Log Likelihood Increments: COPF vs KF','Color','w')

plot(USquarter, liki,'LineStyle','-','Color','b','LineWidth',2.5) % from Kalman filter
hold on 
plot(USquarter, lik_CO,'LineStyle','--','Color','r','LineWidth',2.5) % from tempered BSPF
title('$ln \hat{p} (y_{t}|Y_{1:t-1}, \theta^{m}$) vs. $lnp(y_{t}|Y_{1:t-1}, \theta^{m})$','Interpreter','latex')
axis([USquarter(1) USquarter(end) min(min(liki), min(lik_CO))-1 max(max(liki), max(lik_CO))+1])
set(gca,'FontSize',20)

print('-dpng', [figurePath, 'Liki_KFvCO'])



%=========================================================================
%           FIGURE 3: Log Likelihood Increments (Kalman vs. TPF)
%=========================================================================

USquarter=1983.00:0.25:2002.75;
figure('Position',[20,20,900,600],'Name',...
    'Log Likelihood Increments: Tempered PF vs KF','Color','w')

plot(USquarter, liki,'LineStyle','-','Color','b','LineWidth',2.5) % from Kalman filter
hold on 
plot(USquarter, lik_TPF,'LineStyle','--','Color','r','LineWidth',2.5) % from tempered BSPF
title('$ln \hat{p} (y_{t}|Y_{1:t-1}, \theta^{m}$) vs. $lnp(y_{t}|Y_{1:t-1}, \theta^{m})$','Interpreter','latex')
axis([USquarter(1) USquarter(end) min(min(liki), min(lik_TPF))-1 max(max(liki), max(lik_TPF))+1])
set(gca,'FontSize',20)

print('-dpng', [figurePath, 'Liki_KFvTPF'])

path(l);
disp(['         ELAPSED TIME:   ', num2str(toc)]);
elapsedtime=toc;



