%%% decomp.m --- 
%% 
%% Description: Function which takes parameters p, solves the DSGE model, and
%%   computes the implied covariances with and without news.  
%% 
%%   std -- implied standard deviation of observables.
%%   cor -- implied correlation with output of observables.
%%   antvar -- ratio with implied variances without and with unanticipated
%%   shocks. 
%%
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 06/15/12
%% 
function [std, cor, antvar] = decomp(p)

[sm, rc] = sysmat(p); 

[sigy, sigx] = mom(sm.ZZ/100, sm.TT, 10000*sm.RR*sm.QQ*sm.RR');

sigy(1, 1) = sigy(1, 1) + p(end)^2;

std = sqrt(diag(sigy))';
cor = sigy(1, :) ./ (std(1, 1)*std);

u = [1 4 7 10 13 16 19];
QQu = sm.QQ;
QQu(u, u) = zeros(7, 7);

[siga, sigx] = mom(sm.ZZ/100, sm.TT, 10000*sm.RR*QQu*sm.RR');

stda = sqrt(diag(siga))';

antvar = (stda ./ std).^2;
end