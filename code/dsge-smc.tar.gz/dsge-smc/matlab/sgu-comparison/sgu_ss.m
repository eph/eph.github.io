function ss = sgu_ss(param_estim)

THETA = param_estim(1)+1;
GAMA = param_estim(2);
KAPA = param_estim(3);
DELTA2  = param_estim(4);
B = param_estim(5)*0.99;
RHOXG  = param_estim(6)*0.99;
RHOz = param_estim(7)*0.99;
RHOmua = param_estim(8)*0.99;
RHOg = param_estim(9)*0.99;
RHOmux = param_estim(10)-0.5;
RHOmuw = param_estim(11)*0.99;
RHOzetta = param_estim(12)*0.99;
RHOziv = param_estim(13)*0.99;
STDz = param_estim(14);
STDz4_0 = param_estim(15);
STDz8_0 = param_estim(16);
STDmua = param_estim(17);
STDmua4_0 = param_estim(18);
STDmua8_0 = param_estim(19);
STDg = param_estim(20);
STDg4_0 = param_estim(21);
STDg8_0 = param_estim(22);
STDmux = param_estim(23);
STDmux4_0 = param_estim(24);
STDmux8_0 = param_estim(25);
STDmuw = param_estim(26);
STDmuw4_0 = param_estim(27);
STDmuw8_0 = param_estim(28);
STDzetta = param_estim(29);
STDzetta4_0 = param_estim(30);
STDzetta8_0 = param_estim(31);
STDziv = param_estim(32);
STDziv4_0 = param_estim(33);
STDziv8_0 = param_estim(34);
STDmey = param_estim(35);

STDmec  = 0;
STDmeiv  = 0;
STDmeh  = 0;
STDmeg  = 0;
STDmetfp  = 0;
STDmesp  = 0;
STDmea  = 0;


RHOMUWC = 0; % minus consumption elasticity of wage markup. 

IHF = 1;%1; Internal Habit Formation

DODR = 0.1; %degree of decreasing returns

MUW = 1.15; %Wage markup (gross)
muw = MUW; %Wage markup (gross)


ALFAK = 0.25*(1-DODR); %Capital share in production

ALFAL = DODR;

SIG = 1; %intertemporal elasticity of substitution

MUY = 1.0045; %Steady-state gdp per capita  growth rate estimated as the mean of the means of gy gc giv  gg over 1955:Q1 to 2006:Q4

MUA = 0.9957; %Steady-State gross growth rate of relative price of investment 1947:Q1 to 2006:Q4

BETTA = 0.99;%subjective discount factor

SG = 0.2; %Government spending share in GDP (govern't consumption + gov't investment)/GDP

u = 1; %capacity utilization

DELTA0 = 0.025; %depreciation rate 

h = 0.2; %labor suppy

%Implied Parameters
q = 1;

BETTATILDE = BETTA * MUA * MUY^(-SIG);

MUX = MUY * MUA^(ALFAK/(1-ALFAK)); %Gross growth rate of permanent neutral tech. shock

MUK = MUX * MUA^(1/(ALFAK-1)); %gross growth rate of capital

i_t_muk_o_k = MUK - 1 + DELTA0; %investment-to_capital ratio

y_t_muk_o_k = (1/BETTATILDE-1+DELTA0) / ALFAK; %y*muk/k

DELTA1  = ALFAK * y_t_muk_o_k; %slope of cost of changing capacity utilization

DELTA2 = DELTA2 * DELTA1; %cost of varying capacity utilization

SC = 1 - i_t_muk_o_k / y_t_muk_o_k - SG; %consumption share

k = MUK * h^((ALFAK+ALFAL-1)/(ALFAK-1)) * y_t_muk_o_k^(1/(ALFAK-1)); %capital

y = y_t_muk_o_k * k / MUK;

yb = y; %lagged output

Y = y;

c = SC * y;

iv = i_t_muk_o_k * k / MUK; %stationary investment

xg = MUY^(1/(RHOXG-1));

g = SG * y / xg; %stationary gov't spending

G = g;

muy = MUY;

mua = MUA;

mux = MUX;

muk = MUK;

gy = MUY;

gc = gy;

giv = gy;

gg = gy;

z = 1;

zetta = 1;

ziv = 1;

gh = 1;

stock = c*(1-B/MUY)*MUY^((GAMA-1)/GAMA); %Stock of habit

AUX1 = h^THETA / (1-BETTA*(1-GAMA) * MUY^(1-SIG));

AUX2 = (1-ALFAK-ALFAL) / MUW * Y / (THETA*h^THETA*stock);

AUX3 = AUX2 * (1-IHF*BETTA*B*MUY^(-SIG));

AUX4 = GAMA * stock / (c*(1-B/MUY));

PSSI = AUX3 / (1+AUX1*AUX3*AUX4); %preference parameter;

v = c  * (1-B/MUY)- PSSI * h^THETA * stock;

pai = PSSI * v^(-SIG) * AUX1;

la = v^(-SIG)*PSSI/AUX2; %marginal utility of wealth

w = (1-ALFAK-ALFAL) * y/h; %real wage rate

vv = (y-w*h-iv) / (1-BETTA*MUY^(1-SIG)); %beginning of period value of the firm

gv = MUY;

XI = 1-BETTA*(1-GAMA) * MUY^(1-SIG); 
ETA = PSSI*h^THETA*GAMA*(1/MUY)^((1-GAMA)/GAMA)/XI;
ss = [MUK; MUY; xg; g/y; y/k; iv/k; iv/y; c/y; y/c; B*BETTATILDE/MUA;B/MUY;PSSI;DELTA1;DELTA2;XI;ETA;k;stock;c;y;SC;y];
end