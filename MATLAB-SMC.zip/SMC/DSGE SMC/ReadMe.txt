<Readme file for DSGE SMC>
- In this folder, you can find a set of MATLAB codes that generates posterior draws of small NK model using SMC algorithm. 
- Last modified: 3/5/2016


main.m file runs the SMC algorithm to estimate small NK model in the textbook. (Chapter 5.3.) All SMC tuning parameters are collected in one structure variable called tune.
figure_waterfall.m file generates 2x2 waterfall plots of selected parameters. 


This file uses a number of procedures collected in the subfolders. The most relevant files are


	a) model_solution.m  : Takes as inputs the vector of structural parameters. Returns the coefficient 
                               matrices of the log-linear approximate solution of the DSGE model. Please, 
                               refer to Sims () for details on the procedure.

	b) sysmat.m          : Takes as inputs the solution of the DSGE model and the vector of structural parameters.
                               Returns the matrices for the state space representation. 

	c) kalman.m          : Takes as inputs the state space matrices. Returns the likelihood function and the 
                               filtered states. 

	d) objfcn_dsge.m        : Takes as inputs the vector of structural parameters, tempering parameter, prior, bounds and data. 
				  Returns the value of tempered log posterior, log likelihood, and log prior.  

	e) priodens.m           : Takes as inputs the vector of structural parameters. Returns the value of the log-prior. 
	


The folder contains two additional subfolders: "LRE" and "Optimization Routines". These two folders collect files
to solve the linear rational expectation model and to find the posterior mode. 

There is also "Figures" which collects all saved images

us.txt is the data file whose first column is output growth, second column is inflation, third column is federal fund rates. 
The observations used in the estimation range from 1983:I to 2002:IV, giving a total of 80 observations. 
See Appendix for detailed definition of the variables.


	
