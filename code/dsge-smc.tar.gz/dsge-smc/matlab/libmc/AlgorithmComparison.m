classdef AlgorithmComparison
    
    properties
        nalgo
        algorun
        algonames
        
        paranames
        pmask
        npara
    end
    
    methods
        
        function obj = AlgorithmComparison(algos, varargin);
   
            obj.nalgo = length(algos);

            if (obj.nalgo > 5) error('too many algorithms.'); end
                
            obj.algonames = {};
            obj.algorun = [];
            for i = 1:obj.nalgo
                algo_set = algos{i};
                main_arg  = algo_set{1};
                algo_type = algo_set{2};
                if length(algo_set)==3
                    obj.algonames{i} = algo_set{3};
                else
                    switch algo_type
                      case {'smc'}
                        obj.algonames{i} = 'SMC';
                      case {'huge-rwmh', 'rwmh'};
                        obj.algonames{i} = 'RWMH';
                      otherwise
                        obj.algonames = '';
                    end
                end

                if ~iscell(main_arg) main_arg = {main_arg}; end
                x = MCCollection(main_arg, algo_type, varargin{:});
                obj.algorun = [obj.algorun x];
            end
            obj.paranames = obj.algorun(1).paranames;
            obj.pmask = obj.algorun(1).pmask;
            obj.npara = obj.algorun(2).npara;
        end
    
        
        function box_plot(obj, psel, varargin);
            
            i_p = inputParser;
            i_p.KeepUnmatched = true;
            i_p.addRequired('obj');
            i_p.addOptional('psel', find(1-obj.pmask));
            i_p.addParamValue('file', '');
            i_p.addParamValue('ylim', []);
            i_p.parse(obj, psel, varargin{:});
            
            fout = i_p.Results.file;
            ylim = i_p.Results.ylim;
            
            psel = obj.paranames.get_selected_indices(psel);

            nbox = length(psel);
            
            dcolor = {'Black', 'Red', 'Blue', 'Green', 'Gray'};
            
            bar_width = 1.00;
            padding = 0.20;
            x0 = 0;
            
            xtick = [];
            xnames = {};

            muhmax = 0;
            mulmin = 0;
            
            clf, hold on
            for i = 1:nbox

                xnames{i} = ['$' strtrim(obj.paranames.ptexnames{psel(i)}) '$'];
                xtick = [xtick; x0 + bar_width/2];                
                    
                for j = 1:obj.nalgo
                    
                    colspec = {'Facecolor', dcolor{j}, 'EdgeColor', 'Black'};
                   
                    % posterior mean 
                    [mu, sig] = obj.algorun(j).mean;
                    

                    mu = mu(psel(i));
                    sig = sig(psel(i));
                    if (psel(i)==1) mu = mu - 6; end
                    
                    muh = mu + 2*sig;
                    mul = mu - 2*sig;
                    
                    mul0 = mul;
                    muh0 = muh;
                    
                    rpos = [x0, mul, bar_width/obj.nalgo, 4*sig];
                    rectangle('Position', rpos, colspec{:});
                    

                    % 5th percentile
                    [mu05, sig05] = obj.algorun(j).quantile(0.05);
                    
                    mu05 = mu05(psel(i));
                    sig05 = sig05(psel(i));
                    if (psel(i)==1) mu05 = mu05 - 6; end
                    muh = mu05 + 2*sig05;
                    mul = mu05 - 2*sig05;
                    
                    mulmin = min([mulmin; mul]);
                    
                    rpos = [x0, mul, bar_width/obj.nalgo, 4*sig05];
                    rectangle('Position', rpos, colspec{:});

                    if (muh < mul0)
                        div = obj.nalgo*2;
                        xcoor = [x0+bar_width/div, x0+bar_width/div]';
                        line(xcoor, [muh, mul0]', 'Color', 'Black');
                    end
                    
                    % 95 Percentile                    
                    [mu95, sig95] = obj.algorun(j).quantile(0.95);
                    mu95 = mu95(psel(i));
                    sig95 = sig95(psel(i));
                    if (psel(i)==1) mu95 = mu95 - 6; end
                    muh = mu95 + 2*sig95;
                    mul = mu95 - 2*sig95;
                    
                    muhmax = max([muhmax; muh]);
                    
                    rpos = [x0, mul, bar_width/obj.nalgo, 4*sig95];
                    rectangle('Position', rpos, colspec{:});
                    
                    if (muh0 < mul)
                        div = obj.nalgo*2;
                        xcoor = [x0+bar_width/div, x0+bar_width/div]';
                        line(xcoor, [muh0, mul]', 'Color', 'Black');
                    end

                    x0 = x0 + bar_width/obj.nalgo;
                end


                x0 = x0 + bar_width/obj.nalgo + padding;

            end

            if isempty(ylim), ylim = get(gca, 'YLim'); end
            axis([0 (x0-padding) ylim(1) ylim(2)])

            set(gca, 'XTickLabel', xnames);
            set(gca, 'XTick', xtick);

            % xlabh = get(gca, 'XTicklabel');
            % set(xlabh, 'Position', get(xlabh, 'Position') + [10 0 0])


            plotTickLatex2D('FontSize', 12); 
            set(gca, 'XTick', [])


            if not(isempty(fout))
                saveas(gcf, fout, 'epsc')
            end 
            
        end


        function varargout = ksdensity(obj, psel, varargin);

            i_p = inputParser;
            i_p.KeepUnmatched = true;
            i_p.addRequired('obj');
            i_p.addOptional('psel', find(1-obj.pmask));
            i_p.addParamValue('file', '')
            i_p.parse(obj, psel, varargin{:})
            
            psel = i_p.Results.psel;
            psel = obj.paranames.get_selected_indices(psel);

            fout = i_p.Results.file;
            

            ndens = length(psel);
            dcolor = {'Black', 'Red', 'Blue', 'Green', 'Gray'};
            
            switch ndens
              case 1
                sub0 = 1;
                sub1 = 1;
              case 2
                sub0 = 1;
                sub1 = 2;
              case 3
                sub0 = 1;
                sub1 = 3;
              case 4
                sub0 = 2;
                sub1 = 2;
            end


            for i = 1:obj.nalgo
                algodens(i).dens = obj.algorun(i).ksdensity(psel, varargin{:});
            end

            if (nargout == 1)
                varargout{1} = algodens;
                return
            end
            
            clf
            for i = 1:ndens
                
                subplot(sub0, sub1, i)
                for j = 1:obj.nalgo
                    
                    for k = 1:obj.algorun(j).nruns
                        
                        
                        x = algodens(j).dens(k).x(i, :);
                        f = algodens(j).dens(k).f(i, :);
                        
                        line(x, f, 'Color', dcolor{j}, 'LineWidth', 5);
                        title([strtrim(obj.paranames.ptexnames{psel(i)})], 'Fontsize', 16)
                    end
                end
                
            end
                
            if not(isempty(fout))
                saveas(gcf, fout, 'epsc')
            end 
        end


        function prop = hist_boxplot(obj, parasel, grid, varargin);

            i_p = inputParser;
            i_p.KeepUnmatched = true;
            i_p.addRequired('obj');
            i_p.addRequired('parasel');
            i_p.addRequired('grid');
            i_p.addParamValue('file', '');
            i_p.addParamValue('ylim', []);
            i_p.parse(obj, parasel, grid, varargin{:});
            
            fout = i_p.Results.file;
            ylim = i_p.Results.ylim;

            parasel = obj.paranames.get_selected_indices(parasel);
            ndens = length(parasel);
            
            if (ndens== 1) & not(iscell(grid)), grid = {grid}; end

            switch ndens
              case 1
                sub0 = 1;
                sub1 = 1;
              case 2
                sub0 = 1;
                sub1 = 2;
              case 3
                sub0 = 1;
                sub1 = 3;
              case 4
                sub0 = 2;
                sub1 = 2;
            end


            dcolor = {'Black', 'Red', 'Blue', 'Green', 'Gray'};
            bcolor = {[0.5 0.5 0.5], [1 0.3 0.3], [0.3 0.3 1]};

            muhmax = 0;
            mulmin = 0;
            
            clf, hold on

            for ii = 1:ndens;

                subplot(sub0, sub1, ii)

                igrid = grid{ii};
                nigrid = length(igrid)-1;
                
                x0 = igrid(1);
                
                xtick = [];
                xnames = {};

                for i = 1


                    for j = 1:obj.nalgo
                        
                        colspec = {'Facecolor', dcolor{j}, 'EdgeColor', 'Black'};
                        
                        % posterior mean 
                        [mu, sig] = obj.algorun(j).in_interval(parasel(ii), [igrid(i), igrid(i+1)]);

                        %if (j == 1), sig, sig=0.01, end                        
                        muh = mu + 2*sig;
                        mul = mu - 2*sig;
                        
                        if (sig == 0), sig = 1e-6; end


                        base = max([mul; 0]);
                        height = 4*sig + mul - base;
                        height = min([height;1]);
                        
                        rpos = [x0, base, (igrid(i+1)-igrid(i))/obj.nalgo, height];
                        rectangle('Position', rpos, colspec{:});
 
                       
                        if (mu == 0), mu = 1e-6; end
% $$$                              bpos = [x0, 0, (igrid(i+1)-igrid(i))/obj.nalgo, mu];
% $$$                              rectangle('Position', bpos, 'Facecolor', bcolor{j})
                        
                        x0 = x0 + (igrid(i+1)-igrid(i))/obj.nalgo;
                    end
                        

                end

                for i = 2:nigrid
                    
                    for j = 1:obj.nalgo
                        
                        colspec = {'Facecolor', bcolor{j}, 'EdgeColor', 'Black'};
                        
                        % posterior mean 
                        [mu, sig] = obj.algorun(j).in_interval(parasel(ii), [igrid(i), igrid(i+1)]);
                        
                        muh = mu + 2*sig;
                        mul = mu - 2*sig;
                        
                        if (sig == 0), sig = 1e-6; end
                        
                        base = max([mul; 0]);
                        height = 4*sig + mul - base;
                        height = min([height;1]);
                        
                        rpos = [x0, base, (igrid(i+1)-igrid(i))/obj.nalgo, height];
                        rectangle('Position', rpos, colspec{:});
 
                       
                        if (mu == 0), mu = 1e-6; end
% $$$                              bpos = [x0, 0, (igrid(i+1)-igrid(i))/obj.nalgo, mu];
% $$$                              rectangle('Position', bpos, 'Facecolor', bcolor{j})
                        
                        x0 = x0 + (igrid(i+1)-igrid(i))/obj.nalgo;
                    end


                    x0 = x0;

                end

                if isempty(ylim), ylim = get(gca, 'YLim'); end
                axis([igrid(1) (x0) ylim(1) 1e-2])
                
                title([strtrim(obj.paranames.ptexnames{parasel(ii)})], 'FontSize', 16)
            end
            %set(gca, 'XTickLabel', xnames);
            %set(gca, 'XTick', xtick);

            % xlabh = get(gca, 'XTicklabel');
            % set(xlabh, 'Position', get(xlabh, 'Position') + [10 0 0])


            %plotTickLatex2D('FontSize', 12); 
            %set(gca, 'XTick', [])


            if not(isempty(fout))
                saveas(gcf, fout, 'epsc')
            end 
            
            
        end

        function eff = RNE(obj, base, parasel)
           
            i_p = inputParser;

            parasel = obj.paranames.get_selected_indices(parasel);            
            outstr = '$%-25s $';
            row_str = outstr;
            for i = 1:obj.nalgo
                outstr = [outstr ' %10.3f '];

                [run(i).mu run(i).sigmu] = obj.algorun(i).mean;
                [run(i).q05, ~] = obj.algorun(i).quantile(0.05);
                [run(i).q95, ~] = obj.algorun(i).quantile(0.95);
            
                
                row_str = [row_str '& %6.2f & [%5.2f, %5.2f] & %5.2f & %5i '];
                %                title_str = [title_str '& \multicolumn{3}{c}{' obj.algonames{i} '} ' ];
                
            end
            row_str = [row_str '\\\\ \n'];

                        
            outstr = [outstr '\n'];
            

            [sig ~] = obj.algorun(base).sig;
            
            muvar = zeros(obj.npara, obj.nalgo);
            eff = zeros(obj.npara, obj.nalgo);
            
            outmat = [];
            for i = 1:obj.nalgo
                [~, muvar(:, i)] = obj.algorun(i).mean;
                eff(:, i) = sig.^2 ./ (muvar(:, i).^2);

            end
            
            for i = 1:length(parasel)
 
                parai = parasel(i);
                outmat = [];
                for j = obj.nalgo:-1:1
                   
                    outmat = [outmat, run(j).mu(parai), run(j).q05(parai), run(j).q95(parai), run(j).sigmu(parai), floor(eff(parai, j))];
                    
                end
                fprintf(row_str, obj.paranames.ptexnames{parai}, outmat)

            end
 
            eff = eff(parasel, :);
        end

        function prop = greater_than(obj, parasel, varargin);
            
            i_p = inputParser;
            i_p.addRequired('obj')
            i_p.addOptional('parasel', find(1-obj.pmask));
            i_p.addParamValue('file', '');
            i_p.parse(obj, parasel, varargin{:})

            fout = i_p.Results.file;
            
            nprops = length(parasel);
            prop = zeros(nprops, obj.nalgo, 2);

            bar_width = 1.0;
            padding   = 3.0;
            dcolor = {'Black', 'Red', 'Blue', 'Green', 'Gray'};
            
            xnames = {};
            xtick = [];
            x0 = 0;
            clf, hold on
            for i = 1:nprops

                paras = parasel{i};
                para1 = paras{1};
                para2 = paras{2};

                ind1 = obj.paranames.get_selected_indices(para1);
                ind2 = obj.paranames.get_selected_indices(para2);
                
                pname1 = strtrim(obj.paranames.ptexnames{ind1});
                pname2 = strtrim(obj.paranames.ptexnames{ind2});
                xnames{i} = ['$P(' pname1 ' > ' pname2 ')$'];
                
                xtick = [xtick; x0 + bar_width/2];

                for j = 1:obj.nalgo
                    [prop(i, j, 1) prop(i, j, 2)]= obj.algorun(j).greater_than(para1, para2);

                    colspec = {'Facecolor', dcolor{j}, 'EdgeColor', 'Black'};

                    mu  = prop(i, j, 1);
                    sig = prop(i, j, 2);

                    muh = mu + 2*sig;
                    mul = mu - 2*sig;

                    muh = min([muh;1]);
                    mul = max([mul;0]);
                    height = muh - mul;
                    rpos = [x0, mul, bar_width/obj.nalgo, height];
                    rectangle('Position', rpos, colspec{:});

                    x0 = x0 + bar_width/obj.nalgo;
                end

                x0 = x0 + bar_width/obj.nalgo + padding;
                
            end

            set(gca, 'XTickLabel', xnames);
            set(gca, 'XTick', xtick);

            plotTickLatex2D('FontSize', 12); 
            set(gca, 'XTick', [])
            %axis([0 (x0-padding) 0 1])


            if not(isempty(fout))
                saveas(gcf, fout, 'epsc')
            end 

            
        end


        function post_tab = posterior_table(obj, psel, varargin);

            i_p = inputParser;
            i_p.addRequired('obj')
            i_p.addOptional('psel', find(1-obj.pmask));
            i_p.addParamValue('tab_caption', '');
            i_p.addParamValue('tab_label', '');
            i_p.parse(obj, psel, varargin{:})
            
            psel = i_p.Results.psel;
            psel = obj.paranames.get_selected_indices(psel);

            tab_caption = i_p.Results.tab_caption;
            tab_label = i_p.Results.tab_label;
            
            
            row_str = '%-25s ';
            title_str = '          ';
            for i = 1:obj.nalgo
                [run(i).mu run(i).sigmu] = obj.algorun(i).mean;
                [run(i).q05, ~] = obj.algorun(i).quantile(0.05);
                [run(i).q95, ~] = obj.algorun(i).quantile(0.95);
            
                
                row_str = [row_str '& %6.2f & [%5.2f, %5.2f] & %5.2f '];
                title_str = [title_str '& \multicolumn{3}{c}{' obj.algonames{i} '} ' ];
                
            end
            title_str = [title_str '\\'];
            row_str = [row_str '\\\\ \n'];
            
            fprintf('\\begin{table}[h!]\n')
            fprintf('\\begin{center}\n')
            fprintf('\\caption{\\sc{%s}}\n', tab_caption)
            fprintf('\\label{%s}\n', tab_label)
            fprintf('\\vspace*{1cm}\n')
            fprintf('\\begin{tabular}{l@{\\hspace*{0.5cm}}ccc@{\\hspace*{1cm}}ccc}\n')
            fprintf('\\hline\\hline \n')
            fprintf('%s \n', title_str)
            fprintf('Parameter & Mean & $[0.05, 0.95]$ & STD(Mean) & Mean & $[0.05, 0.95]$ & STD(Mean)\\\\ \n\\hline\n')


            row_str = '$%-25s$ & %6.2f & [%5.2f, %5.2f] & %5.2f & %6.2f & [%5.2f, %5.2f] & %5.2f \\\\ \n';
            
            for i = psel'

                out_mat = [];
                
                for j = 1:obj.nalgo
                   out_mat = [out_mat, ...
                              run(j).mu(i), run(j).q05(i), ...
                              run(j).q95(i), run(j).sigmu(i)];
                end

                fprintf(row_str, strtrim(obj.paranames.ptexnames{i}), out_mat);
                
            end
            
            fprintf('\\hline\\hline\n')
            fprintf('\\end{tabular}\n')
            fprintf('\\end{center}\n')
            fprintf('\\end{table}\n')

        end
        
        function [mu_pit, sig_pit] = stat_table(obj, psel, varargin)

            i_p = inputParser;
            i_p.addRequired('obj')
            i_p.addOptional('psel', find(1-obj.pmask));
            i_p.addParamValue('tab_caption', '');
            i_p.addParamValue('tab_label', '');
            i_p.addParamValue('print_star', 0);
            i_p.parse(obj, psel, varargin{:})

            psel = i_p.Results.psel;
            psel = obj.paranames.get_selected_indices(psel);

            tab_caption = i_p.Results.tab_caption;
            tab_label = i_p.Results.tab_label;
            print_star = i_p.Results.print_star;
            
            row_str = '%-25s ';
            title_str = '          ';
            stat_name = {'Mean(Mean)', 'Std(Mean)'};
            for i = 1:obj.nalgo
                [run(i).mu run(i).sigmu] = obj.algorun(i).mean;
                run(i).nruns = obj.algorun(i).nruns;
                
                row_str = [row_str '& %6.2f & %5.2f & %5.2f'];
                title_str = [title_str '& \multicolumn{3}{c}{' stat_name{i} '} ' ];
                
            end
            title_str = [title_str '\\'];
            row_str = [row_str '\\\\ \n'];
            
% $$$             fprintf('\\begin{table}[h!]\n')
% $$$             fprintf('\\begin{center}\n')
% $$$             fprintf('\\caption{\\sc{%s}}\n', tab_caption)
% $$$             fprintf('\\label{%s}\n', tab_label)
% $$$             fprintf('\\vspace*{1cm}\n')
% $$$             fprintf('\\begin{tabular}{l@{\\hspace*{0.5cm}}ccc@{\\hspace*{1cm}}ccc}\n')
% $$$             fprintf('\\hline\\hline \n')
% $$$             fprintf('%s \n', title_str)
% $$$             fprintf(['Parameter & %s & %s & PIT & %s & %s & PIT \\\\ \n\\hline\n'], ...
%$$$                   obj.algonames{1}, obj.algonames{2}, obj.algonames{1}, obj.algonames{2})


            %row_str = '$%-25s$ & %6.2f & [%5.2f, %5.2f] & %5.2f & %6.2f & [%5.2f, %5.2f] & %5.2f \\\\ \n';
            if print_star == 0
                row_str = ['$%-25s$ & %6.4f & %6.4f & %5.2f %s & %6.4f & %6.4f & %5.2f %s \\\\ \n'];
            else
                row_str = '$%-25s$ & %6.4f & %6.4f & %s & %6.4f & %6.4f & %s \\\\ \n';
            end
            mu_pit = zeros(obj.npara, 1);
            sig_pit = zeros(obj.npara, 1);
            
            for i = psel'

                out_mat = [];
                
                mu1  = run(1).mu(i);
                sig1 = run(1).sigmu(i);
                n1   = run(1).nruns;
                
                mu2  = run(2).mu(i);
                sig2 = run(2).sigmu(i);
                n2   = run(2).nruns;
                
                shat = sqrt(sig1^2/n1 + sig2^2/n2);
                df   = shat^2/((sig1^2/n1)^2/(n1-1) + (sig2^2/n2)^2/(n2-1));
                
                t = (mu1 - mu2)/shat;
                F = sig1^2/sig2^2;
                mu_pit(i) = tcdf(t, df);
                sig_pit(i)  = fcdf(F, n1, n2);
                
                if print_star == 0
                    mu_str = '   ';
                    sig_str = '   ';
                    if mu_pit(i) < 0.025 | mu_pit(i) > 0.975
                        mu_str = '(*)';
                    end
                        
                    if sig_pit(i) < 0.025 | sig_pit(i) > 0.975
                        sig_str = '(*)';
                    end
                    
                    out_mat1 = [out_mat, mu1, mu2, mu_pit(i)];
                    out_mat2 = [sig1, sig2, sig_pit(i)];
                else 
                    mu_str = '   ';
                    sig_str = '   ';
                    if mu_pit(i) < 0.025 | mu_pit(i) > 0.975
                        mu_str = '(*)';
                    end
                        
                    if sig_pit(i) < 0.025 | sig_pit(i) > 0.975
                        sig_str = '(*)';
                    end
                    out_mat = [out_mat, mu1, mu2, mu_str, sig1, sig2, sig_str];
                end

                fprintf(row_str, strtrim(obj.paranames.ptexnames{i}), out_mat1, strtrim(mu_str), ...
                        out_mat2, strtrim(sig_str));
                
            end
            
% $$$             fprintf('\\hline\\hline\n')
% $$$             fprintf('\\end{tabular}\n')
% $$$             fprintf('\\end{center}\n')
% $$$             fprintf('\\end{table}\n')


        end

        function mdd_stats = mdd_table(obj, varargin)


            i_p = inputParser;
            i_p.addRequired('obj')
            i_p.addParamValue('tab_caption', '');
            i_p.addParamValue('tab_label', '');
            i_p.parse(obj, varargin{:})
            
            tab_caption = i_p.Results.tab_caption;
            tab_label = i_p.Results.tab_label;

            mdd_stats = zeros(obj.nalgo, 2);


            fprintf('\\begin{table}\n')
            fprintf('\\begin{center}\n')
            fprintf('\\caption{\\sc:{%s}}\n', tab_caption)
            fprintf('\\label{%s}\n', tab_label)
            fprintf('\\vspace*{1cm}\n')
            fprintf('\\begin{tabular}{lcc}\n')
            fprintf('\\hline\\hline \n')
            fprintf('Algorithm, Method & MDD Estimation & Standard Deviation \\\\ \n')
            for i = 1:obj.nalgo
                
                [mu sig] = obj.algorun(i).mdd;
                switch obj.algorun(i).type
                  case 'smc'
                    algo_str = 'SMC, Particle Estimate';
                  case {'rwmh', 'huge-rwmh'}
                    algo_str = 'RWMH, Modified Harmonic Mean';
                  otherwise
                    algo_str = '';
                end
                
                fprintf('%25s & %5.3f & %4.2f \\\\ \n', algo_str, mu, sig);
                
                mdd_stats(i, :) = [mu, sig];

            end
            fprintf('\\hline\\hline\n')
            fprintf('\\end{tabular}\n')
            fprintf('\\end{center}\n')
            fprintf('\\end{table}\n')


        end


 end
         
end