%CREATE_ANTICIPATED_SHOCKS.M
%November 2009 by SSG and MU

eval(['EPS=[];'])
eval(['EPSp=[];'])
eval(['EQ=[];'])
eval(['innovations=[];'])
eval(['STDinnovations=[];'])

nshock = length(SHOCK);

for jshock = 1:nshock
shock = SHOCK{jshock};
eval(['syms ' shock])

eval(['syms EPS' shock ' EPS' shock  'p ANTICIP' shock ' EQ' shock ])

eval(['EPS' shock '=[];'])
eval(['EPS' shock 'p=[];'])
eval(['ANTICIP' shock '=0;'])
eval(['EQ' shock '=[];'])

eval(['innovations=[innovations;' shock '];'])

eval(['syms STD' shock])
eval(['STDinnovations=[STDinnovations;STD' shock '];'])

if max(anticipation_horizons{jshock})>0 %contemplate the possibility of no anticipation
for H = anticipation_horizons{jshock}

for horizon=0:H-1
eval(['syms eps' shock num2str(H) '_' num2str(horizon)])

eval(['syms eps' shock num2str(H) '_' num2str(horizon) 'p'])

eval(['EPS' shock num2str(H) '(' num2str(horizon+1) ',1) = eps' shock num2str(H) '_' num2str(horizon) ';'])


eval(['EPS' shock num2str(H) 'p(' num2str(horizon+1) ',1) = eps' shock num2str(H) '_' num2str(horizon) 'p;'])


end %for horizon=0:H-1

eval(['RHO' shock num2str(H) '= zeros(' num2str(H) ');'])

eval(['RHO' shock num2str(H) '(2:end,1:end-1)= eye(' num2str(H-1) ');']);

eval(['EQ' shock num2str(H) '=-EPS' shock num2str(H) 'p+RHO' shock num2str(H) '*EPS' shock num2str(H) ';'])


eval(['A' shock num2str(H) '(1,' num2str(H) ')= 1;']);

eval(['EPS' shock '=[EPS' shock '; EPS' shock num2str(H) '];']);

eval(['EPS' shock 'p=[EPS' shock 'p; EPS' shock num2str(H) 'p];']);

eval(['ANTICIP' shock '=ANTICIP' shock '+ A' shock num2str(H) '* EPS' shock num2str(H) ';']);

eval(['EQ' shock '=[EQ' shock '; EQ' shock num2str(H) '];']);

%Clean clutter
eval(['clear  EPS' shock num2str(H) ' EQ' shock num2str(H) ' A' shock num2str(H) ' EPS' shock num2str(H) 'p  RHO' shock num2str(H)])

eval(['syms STD' shock num2str(H) '_0']);
eval(['innovations=[innovations; eps' shock num2str(H) '_0];'])

eval(['STDinnovations=[STDinnovations; STD' shock num2str(H) '_0];'])

end %for H = HORIZONS

end %if max(anticipation_horizons{jshock})>0


eval(['EPS = [EPS;EPS' shock '];']);
eval(['EPSp = [EPSp;EPS' shock 'p];']);
eval(['EQ = [EQ;EQ' shock '];']);


eval(['clear EPS' shock ' EPS' shock 'p EQ' shock]);

end %for shock=SHOCK