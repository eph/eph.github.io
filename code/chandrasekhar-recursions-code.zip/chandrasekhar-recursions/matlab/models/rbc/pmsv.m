function para = pmsv;
%% Parameter starting values - change at will.

  alp  = 0.34;        % capital share 
  bet  = 0.995;       % discount factor 
  del  = 0.015;       % depreciation 
  gam  = 2.5;         % labor supply elasticity 
  theta= 4.0;
  rhoA = 0.50;        % Persistence: neutral technology shock 
  rhoG = 0.50;        % Persistence: preference shock 
  sigA = 0.10;        % Stdev: neutral technology shock 
  sigG = 0.60;        % Stdev: preference shock 

  rhoAG  = 0.0;
  rhoGA  =-3.0;
  corrAG = 0.0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%      Parameter selection according to model                    %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
para = [alp;bet;del;gam;theta;rhoA;rhoG;sigA;sigG;rhoAG;rhoGA;corrAG]; 

%{para,pnames} = psel(paratemp,msel);

end
