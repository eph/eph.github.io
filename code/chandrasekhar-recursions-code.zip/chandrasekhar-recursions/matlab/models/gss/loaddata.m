y = load('CRM.txt');
y = y(1:200, :);