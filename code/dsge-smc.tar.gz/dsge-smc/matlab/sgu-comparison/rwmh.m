addpath('prior')
load parameter_vector
load read_data

% Prior
global pshape pmean pstdd pfix
load sgu_prior.txt;
pshape = sgu_prior(:, 1);
pmean  = sgu_prior(:, 2);
pstdd  = sgu_prior(:, 3);
pfix   = sgu_prior(:, 4);

f = @(x) lnpy(Y, x);
f0 = f(mean_mle);
nsim = 1000;

npara = size(mean_mle, 1);
parasim = zeros(nsim, npara);

c = 0.0005;
parasim(1, :) = mean_mle';
postsim(1) = f0;

p0 = parasim(1, :)';
acpt = 1

for i = 2:1000
    
    p1 = p0 + c*randn(npara, 1);
    
    f1 = f(p1);
    
    alp = exp(f1 - f0);
    
    if rand < alp
        p0 = p1;
        f0 = f1;
        
        acpt = acpt + 1;
        
    end
    
    parasim(i, :) = p0;
    postsim(i) = f0;
    
    if mod(i, 10) == 0
        f0, acpt/i, i
    end

end