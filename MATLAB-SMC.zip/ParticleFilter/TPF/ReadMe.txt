<Readme file for Tempered Particle Filtering>
- Last modified: 5/25/2017
- Written by Minsu Chang (Penn)
- These programs implement the tempered particle filter in
  Herbst and Schorfheide (2017): "Tempered Particle Filtering", NBER Working Paper 23448
- The programs compute the log likelihood function for the small-scale New Keynesian
  DSGE model in Herbst and Schorfheide (2005) "Bayesian Estimation of DSGE Models"
  using the parameters in Table 8.1.
- The programs also implement the Kalman filter, the bootstrap particle filter, and the
  conditionally-optimal particle filter discussed in the book.
- Note that the results in the paper were NOT generated with these codes. The MATLAB
  programs are not optimized for speed, nor do they automatically generate the performance statistics
  reported in the paper (which are obtained by repeatedly running the filters).

 
These files use a number of procedures collected in the folder "Mfiles". The most relevant files are


	a) model_solution.m  : Takes as inputs the vector of structural parameters. Returns the coefficient 
                               matrices of the log-linear approximate solution of the DSGE model. Please, 
                               refer to Sims () for details on the procedure.

	b) sysmat.m          : Takes as inputs the solution of the DSGE model and the vector of structural parameters.
                               Returns the matrices for the state space representation. 

	c) PF_lik.m          : Takes as inputs the matrices for the state space representation, number of particles, data, 
                               initial prior for the filter, indicator for bootstrap particle filter method. Returns the 
                               period log likelihood, updated particles, and effective sample size.  

	c) tempered_PF_lik.m : Takes as inputs the matrices for the state space representation, number of particles, data, 
                               initial prior for the filter, tuning parameters for tempered particle filter. Returns the 
                               period log likelihood, updated particles, effective sample size, and number of tempering schedule.   
	


The folder contains a subfolder "LRE" including files to solve the linear rational expectation model. 

us.txt is the data file whose first column is output growth, second column is inflation, third column is federal fund rates. 
The observations used in the estimation range from 1983:I to 2002:IV, giving a total of 80 observations. 
See Appendix for detailed definition of the variables.


	