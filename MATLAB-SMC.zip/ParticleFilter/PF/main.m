%==========================================================================
%                       DSGE MODEL ESTIMATION:  
%              Particle Filter Approximation of Likelihood 
%
%
% Author: Minsu Chang        minsuc@sas.upenn.edu
% Last modified: 2/24/2016
%==========================================================================


clear
clc
close all
delete *.asv

tic

l = path;

path('Mfiles',path);
path('LRE',path);
figurePath = [pwd, '\Figures\'];

% load data and consider parameters in Table 8.1.

yt      = load('us.txt');
param_m = [2.09 0.98 2.25 0.65 0.34 3.16 0.51 0.81 0.98 0.93 0.19 0.65 0.24];

[T1, ~, T0, ~, ~, ~] = model_solution(param_m);
[A,B,H,R,S2,Phi] = sysmat(T1,T0,param_m);

% Kalman filter result
[liki, measurepredi, statepredi, varstatepredi] = kalman(A,B,H,R,S2,Phi,yt);

ns      = size(B,2);
T       = size(yt,1);

% initialize
%rng(111122)
x0 = zeros(ns,1);
P0 = nearestSPD(dlyap(Phi, R*S2*R'));  % to make it positive semidefinite   

N       = 400; % number of particles (for BSPF: 40000, for COPF: 400)

[lik, all_s_up, Neff] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 1,0);
% Last input denotes the indicator for bootstrap particle filtering.
% if == 1, it performs bootstrap particle filtering. otherwise, it does
% conditionally-optimal particle filtering.


%=========================================================================
%                  FIGURE 1: Log Likelihood Increments
%=========================================================================


figure('Position',[20,20,900,600],'Name',...
    'Log Likelihood Increments','Color','w')

plot(liki,'LineStyle','-','Color','b','LineWidth',2.5) % from Kalman filter
hold on 
plot(lik,'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('$ln \hat{p} (y_{t}|Y_{1:t-1}, \theta^{m}$) vs. $lnp(y_{t}|Y_{1:t-1}, \theta^{m})$','Interpreter','latex')

print('-dpng', [figurePath, 'Liki'])


%=========================================================================
%                  FIGURE 2: Filtered States 
%=========================================================================

figure('Position',[20,20,1200,800],'Name',...
    'Filtered States','Color','w')

subplot(3,1,1)
plot(squeeze(all_s_up(:,5,:)), 'Color',[0,0,0] + .8)
hold on
plot(statepredi(1:end-1,5),'LineStyle','-','Color','b','LineWidth',2.5) % g from Kalman filter
hold on 
plot(mean(all_s_up(:,5,:),3),'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('$\hat{E} (\hat{g}_{t} |Y_{1:t}, \theta^{m}$) vs. $E(\hat{g}_{t}|Y_{1:t}, \theta^{m})$','Interpreter','latex')

subplot(3,1,2)
plot(squeeze(all_s_up(:,6,:)), 'Color',[0,0,0] + .8)
hold on
plot(statepredi(1:end-1,6),'LineStyle','-','Color','b','LineWidth',2.5) % z from Kalman filter
hold on 
plot(mean(all_s_up(:,6,:),3),'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('$\hat{E} (\hat{z}_{t} |Y_{1:t}, \theta^{m}$) vs. $E(\hat{z}_{t}|Y_{1:t}, \theta^{m})$','Interpreter','latex')
ylim([-1,1])

subplot(3,1,3)
plot(squeeze(all_s_up(:,1,:)), 'Color',[0,0,0] + .8)
hold on
plot(statepredi(1:end-1,1),'LineStyle','-','Color','b','LineWidth',2.5) % y from Kalman filter
hold on 
plot(mean(all_s_up(:,1,:),3),'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('$\hat{E} (\hat{y}_{t} |Y_{1:t}, \theta^{m}$) vs. $E(\hat{y}_{t}|Y_{1:t}, \theta^{m})$','Interpreter','latex')

print('-dpng',[figurePath, 'states'])

%=========================================================================
%                  FIGURE 3: Effective Sample Size
%=========================================================================


figure('Position',[20,20,900,600],'Name',...
    'Effective Sample Size','Color','w')

plot(Neff,'LineStyle','-','Color','b','LineWidth',2.5) % from CO Particle filter
title('Effective Sample Size')

print('-dpng', [figurePath, 'EFF'])


%% Number of Bootstrap Particles

%kalman exact likelihood
[liki, measurepredi, statepredi, varstatepredi] = kalman(A,B,H,R,S2,Phi,yt);

N_opts = [50, 100, 1000];

Nrep = 100;

lik_store = zeros(Nrep, length(N_opts));

for r = 1:Nrep
    
    for n = 1:length(N_opts)
        
        N = N_opts(n);
        
        [lik, all_s_up, Neff] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 1,1);
        
        lik_store(r,n) = sum(lik) - sum(liki);
        
    end
    
end

[f1, xi1] = ksdensity(lik_store(:,1));
[f2, xi2] = ksdensity(lik_store(:,2));
[f3, xi3] = ksdensity(lik_store(:,3));

maxF = max([f1, f2, f3]);

a = maxF + .01;

figure('Position',[20,20,900,600],'Name',...
    'Effective Sample Size','Color','w')

plot(xi1, f1, 'LineStyle','-','Color','b','LineWidth',2.5); hold on;
plot(xi2, f2, 'LineStyle',':','Color','g','LineWidth',2.5);
plot(xi3, f3, 'LineStyle','--','Color','k','LineWidth',2.5);
legend('50', '100','400', 'Location','northwest')
axis tight;
title('Bootstrap Likelihood Error')

print('-dpng',[figurePath, 'Liki_error_b'])

%% Number of CO particles

%kalman exact likelihood
[liki, measurepredi, statepredi, varstatepredi] = kalman(A,B,H,R,S2,Phi,yt);

N_opts = [50, 100, 1000];

Nrep = 100;

lik_store = zeros(Nrep, length(N_opts));

for r = 1:Nrep
    
    for n = 1:length(N_opts)
        
        N = N_opts(n);
        
        [lik, all_s_up, Neff] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 1,0);
        
        lik_store(r,n) = sum(lik) - sum(liki);
        
    end
    
end

[f1, xi1] = ksdensity(lik_store(:,1));
[f2, xi2] = ksdensity(lik_store(:,2));
[f3, xi3] = ksdensity(lik_store(:,3));

maxF = max([f1, f2, f3]);

a = maxF + .01;

figure('Position',[20,20,900,600],'Name',...
    'Effective Sample Size','Color','w')

plot(xi1, f1, 'LineStyle','-','Color','b','LineWidth',2.5); hold on;
plot(xi2, f2, 'LineStyle',':','Color','g','LineWidth',2.5);
plot(xi3, f3, 'LineStyle','--','Color','k','LineWidth',2.5);
legend('50', '100','400', 'Location','northwest')
axis tight;
title('CO Likelihood Error')

print('-dpng', [figurePath,'Liki_error_CO'])

%% What if no resampling?


%kalman exact likelihood
[liki, measurepredi, statepredi, varstatepredi] = kalman(A,B,H,R,S2,Phi,yt);

N = 400;
[lik_co, all_s_up_co, Neff_co] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 0,0);

N = 100000;
[lik_b, all_s_up_b, Neff_b] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 0,1);



figure('Position',[20,20,900,600],'Name',...
    'No Resampling','Color','w')
subplot(2,2,1)
plot(liki,'LineStyle','-','Color','b','LineWidth',2.5) % from Kalman filter
hold on 
plot(lik_co,'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('CO Likelihood')

subplot(2,2,3)
plot(Neff_co, 'LineStyle','--','Color','r','LineWidth',2.5);
title('CO Effective Sample Size')

subplot(2,2,2)
plot(liki,'LineStyle','-','Color','b','LineWidth',2.5) % from Kalman filter
hold on 
plot(lik_b,'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('Bootstrap Likelihood')

subplot(2,2,4)
plot(Neff_b, 'LineStyle','--','Color','r','LineWidth',2.5);
title('Bootstrap Effective Sample Size')

print('-dpng', [figurePath, 'Resample'])



%% What if there is an outlier?

yt = load('us.txt');

yt(50,:) = yt(50,:) + 4*sqrt(var(yt))  ;

% Kalman filter result
[liki1, measurepredi, statepredi, varstatepredi] = kalman(A,B,H,R,S2,Phi,yt);

N = 10000;

[lik_p, all_s_up_b4, Neff_b] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 1,1);

N = 400;

[lik_co, all_s_up_co4, Neff_co] = PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, 1,0);


% ------------------------------------------------------------------------
%               Plot particle Swarm
% ------------------------------------------------------------------------

figure('Position',[20,20,1200,800],'Name',...
    'Filtered States','Color','w')

subplot(2,2,1)
plot(squeeze(all_s_up_b4(:,6,:)), 'Color',[0,0,0] + .8)
hold on
plot(statepredi(1:end-1,6),'LineStyle','-','Color','b','LineWidth',2.5) % g from Kalman filter
hold on 
plot(mean(all_s_up_b4(:,6,:),3),'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('Bootstrap $\hat{E} (\hat{g}_{t} |Y_{1:t}, \theta^{m}$) vs. $E(\hat{g}_{t}|Y_{1:t}, \theta^{m})$','Interpreter','latex')
ylim([-1,2])

subplot(2,2,2)
plot(squeeze(all_s_up_co4(:,6,:)), 'Color',[0,0,0] + .8)
hold on
plot(statepredi(1:end-1,6),'LineStyle','-','Color','b','LineWidth',2.5) % g from Kalman filter
hold on 
plot(mean(all_s_up_co4(:,6,:),3),'LineStyle','--','Color','r','LineWidth',2.5) % from CO Particle filter
title('C.O. $\hat{E} (\hat{g}_{t} |Y_{1:t}, \theta^{m}$) vs. $E(\hat{g}_{t}|Y_{1:t}, \theta^{m})$','Interpreter','latex')
ylim([-1,2])

% ------------------------------------------------------------------------
%               Effective Sample Size
% ------------------------------------------------------------------------

subplot(2,2,3)
plot(Neff_b, 'LineStyle','-','Color','b','LineWidth',2.5)
title('Bootstrap Effective Sample Size')

subplot(2,2,4)
plot(Neff_co, 'LineStyle','-','Color','b','LineWidth',2.5)
title('C.O. Effective Sample Size')

print('-dpng',[figurePath, 'Outlier'])


path(l);
disp(['         ELAPSED TIME:   ', num2str(toc)]);
elapsedtime=toc;



