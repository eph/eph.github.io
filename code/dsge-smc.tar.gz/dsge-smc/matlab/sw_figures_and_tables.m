%%% sw_figures_and_tables.m --- 
%% 
%% Description: This script produces the figures for SW model for
%%    "Sequential Monte Carlo Sampling for DSGE Models"
%%     by Ed Herbst and Frank Schorfheide
%% 
%% Author: Ed Herbst [edward.p.herbst@frb.gov]
%% Last-Updated: 09/16/13
%% 
clear all

addpath('~/code/test')
addpath('~/code/test/MiscClasses')
addpath('~/code/matlab/mc')
addpath('~/code/matlab/misc')
addpath('~/code/matlab/dsge/prior')
addpath('~/code/matlab/misc/kde2d')
addpath('/mq/DSGE/production/pdfbox')
base = '~/code/fortran/models/sw/';
addpath('libmc')
%------------------------------------------------------------------------------
% 0. Preliminaries
%------------------------------------------------------------------------------
% Read in parameter specifications.
parafile = strcat(base, 'sw_spec.txt');
sw_para = Parameters.read_from_textfile(parafile);
names = {'paranames', sw_para};


% Read in regular prior.
regular_priofile = strcat(base, 'prior.txt');
sw_regular_prior = Prior.read_from_frankfile(regular_priofile, names{:});
reg_prior_set = {sw_regular_prior, 'prior', 'Regular Prior'};
mask = {'pmask', sw_regular_prior.pmask};


% Read in regular prior RWMH/SMC runs.
smcruns = get_file_list('input/sw_smc_standard.txt');
smc_set = {smcruns, 'smc'};

rwmhruns = get_file_list('input/sw_rwmh_standard.txt');
rwmh_set = {rwmhruns, 'huge-rwmh'};

fprintf('Reading regular posteriors......')
regular_set = {rwmh_set, smc_set};
regular_rwmh_vs_smc = AlgorithmComparison(regular_set, names{:}, mask{:});
fprintf('DONE.\n')



% Read in diffuse prior.
diffuse_priofile = strcat(base, 'prior_diffuse_rr.txt');
sw_diffuse_prior = Prior.read_from_frankfile(diffuse_priofile, names{:});
dif_prior_set = {sw_diffuse_prior, 'prior', 'Diffuse Prior'};


% Read in diffuse prior RWMH/SMC runs.
smcruns = get_file_list('input/sw_smc_diffuse.txt');
smc_set = {smcruns, 'smc'};

rwmhruns = get_file_list('input/sw_rwmh_diffuse.txt');
rwmh_set = {rwmhruns, 'huge-rwmh'};

diffuse_set = {rwmh_set, smc_set};
diffuse_rwmh_vs_smc = AlgorithmComparison(diffuse_set, names{:}, mask{:});



%------------------------------------------------------------------------------ 
% 
% FIGURES
% 
%------------------------------------------------------------------------------ 

%------------------------------------------------------------------------------ 
% Figure 2 -- Box Plots
%------------------------------------------------------------------------------ 
box_para = {'lbar', 'iotaw', 'mup', 'muw', 'rhow', 'xiw', 'rpi'};
ylim = [-4 4];
fout = 'figures/sw_boxplot.eps';
regular_rwmh_vs_smc.box_plot(box_para, 'file', fout, 'ylim', ylim);

fout = 'figures/sw_diffuse_boxplot.eps';
diffuse_rwmh_vs_smc.box_plot(box_para, 'file', fout, 'ylim', ylim);



fprintf('\\begin{figure}[t!]\n')
fprintf('\\begin{center}\n')
fprintf('\\caption{\\sc{SW Model: Estimates of Posterior Means and Quantiles}}\n')
fprintf('\\label{fig:sw-boxplot}\n')
fprintf('\\vspace*{1cm}\n')
fprintf('\\begin{tabular}{cc}\n')
fprintf('Standard Prior & Diffuse Prior \\\\\n')
fprintf('\\includegraphics[height=2.25in]{figures/sw_boxplot.pdf}\n')
fprintf('%\\hspace*{1cm}\n')
fprintf('&\n')
fprintf('\\includegraphics[height=2.25in]{figures/sw_diffuse_boxplot.pdf}\n')
fprintf('\\end{tabular}\n')
fprintf('\\end{center}\n')
fprintf('{\\em Notes:} This figure shows estimates of the mean, $5^{th}$ and\n')
fprintf('$95^{th}$ percentile for the RWMH (black) and SMC (red) simulators for the SW\n')
fprintf('model under the standard prior (left) and diffuse prior (right).  The boxes are\n')
fprintf('centered at the mean estimate (across 20 simulations) for each statistic while\n')
fprintf('the shaded region shows plus and minus two standard deviations around this mean.\n')
fprintf('\\end{figure}\n')


%------------------------------------------------------------------------------ 
% Figure 3 -- Bivariate contout plot
%------------------------------------------------------------------------------ 
smc = diffuse_rwmh_vs_smc.algorun(2).mc(1);

cont_para = {'xiw', 'rhow'};
fout = 'figures/sw_contour_xiw_rhow.eps';
smc.kde2d(cont_para, 'file', fout, 'xlim', [0.6, 1], 'ylim', [0, 1], 'line45', true);

cont_para = {'mup', 'rhop'};
fout = 'figures/sw_contour_rhop_mup.eps';
smc.kde2d(cont_para, 'file', fout, 'xlim', [0.6, 1], 'ylim', [0.7, 1], 'line45', true, 'q0', 0.55);

fprintf('\\begin{figure}[t!]\n')
fprintf('  \\begin{center}\n')
fprintf('    \\caption{\\sc{SW Model with Diffuse Prior: Bivariate Contour Plots}}\n')
fprintf('    \\label{fig:sw-joint-posterior}\n')
fprintf('    \\vspace*{1cm}\n')
fprintf('    \\includegraphics[height=2in]{figures/sw_contour_xiw_rhow.pdf}\n')
fprintf('    \\hspace*{1cm}\n')
fprintf('    \\includegraphics[height=2in]{figures/sw_contour_rhop_mup.pdf}\n')
fprintf('\\end{center}\n')
fprintf('{\\em Notes:} This figure shows contour plots for bivariate kernel density estimates of\n')
fprintf('the posteriors for $[\\rho_w, \\xi_w]$ (left) and $[\\rho_p, \\mu_p]$ (right) from\n')
fprintf('the SMC simulator.  The black solid line is the $45^\\circ$ line.\n')
fprintf('\\end{figure}\n')


%------------------------------------------------------------------------------ 
% Figure 4 -- Posterior Probability Statements
%------------------------------------------------------------------------------ 
fout = 'figures/sw_mode_comp.eps'
para_comp = {{'xiw', 'rhow'}, {'rhow', 'muw'}, {'xiw', 'muw'}, ...
             {'xip', 'rhop'}, {'rhop', 'mup'}, {'xip', 'mup'}};
diffuse_rwmh_vs_smc.greater_than(para_comp, 'file', fout);

fprintf('\\begin{figure}[t!]\n')
fprintf('\\begin{center}\n')
fprintf('\\caption{\\sc{SW Model with Diffuse Prior: Posterior Probability Statements}}\n')
fprintf('\\label{fig:sw-diffuse-densities}\n')
fprintf('\\vspace*{1cm}\n')
fprintf('\\includegraphics[height=2.5in]{figures/sw_mode_comp.pdf}\n')
fprintf('\\end{center}\n')
fprintf('{\\em Notes:} This figure shows estimates of various posterior probability\n')
fprintf('statements.  The black (RWMH) and red (SMC) boxes are centered at the mean\n')
fprintf('(across the 20 simulations) estimate of each probability statement.  The shaded\n')
fprintf('region shows plus and minus two standard deviations around this mean.\n')
fprintf('\\end{figure}\n')



% 
% 
% Tables
% 
% 

%------------------------------------------------------------------------------
% Table 1 -- Marginal Data Density Comparison
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:sw-mdd', ...
            'tab_caption', 'SW Model: Regular Prior Log MDD Estimates'};

standard_mdd = regular_rwmh_vs_smc.mdd_table(tab_args{:});
diffuse_mdd = diffuse_rwmh_vs_smc.mdd_table(tab_args{:});

fprintf('\\begin{table}[t!]\n')
fprintf('  \\begin{center}\n')
fprintf('    \\caption{\\sc{SW Model: Log MDD Estimates}}\n')
fprintf('    \\label{tab:sw-mdd}\n')
fprintf('    \\vspace*{1cm}\n')
fprintf('    \\begin{tabular}{lcc}\n')
fprintf('      \\hline\\hline\n')
fprintf('      Algorithm (Method) & MEAN(Log MDD) & STD(Log MDD) \\\\ \\hline\n')
fprintf('      \\multicolumn{3}{c}{Standard Prior} \\\\ \\hline\n')
fprintf('      SMC  (Particle Estimate) & %-7.3f & %5.2f \\\\\n', standard_mdd(2, :))
fprintf('      RWMH (Modified Harmonic Mean) & %-7.3f & %5.2f \\\\ \\hline\n', standard_mdd(1, :))
fprintf('      \\multicolumn{3}{c}{Diffuse Prior} \\\\ \\hline\n')
fprintf('      SMC (Particle Estimate)       & %-7.3f       & %5.2f \\\\\n', diffuse_mdd(2, :))
fprintf('      RWMH (Modified Harmonic Mean) & %-7.3f       & %5.2f \\\\\n', diffuse_mdd(1, :))
fprintf('      \\hline\\hline\n')
fprintf('    \\end{tabular}\n')
fprintf('  \\end{center}\n')
fprintf('  {\\it Notes:} Means and standard deviations are over 20 runs for\n')
fprintf('  each algorithm.\n')
fprintf('\\end{table}\n')



%------------------------------------------------------------------------------
% Table 2 -- SW Diffuse Posterior
%------------------------------------------------------------------------------
parasel = {'sigmal', 'lbar', 'iotap', 'h', 'capphi', 'rpi', 'rhob', 'varphi', ...
           'sigmap', 'xip', 'iotaw', 'mup', 'rhow', 'muw', 'xiw'};

fprintf('\\begin{table}[t!]\n')
fprintf('\\begin{center}\n')
fprintf('\\caption{\\sc{SW Model with Diffuse Prior: Posterior Comparison}}\n')
fprintf('\\label{tab:sw-diffuse-pos}\n')
fprintf('\\vspace*{1cm}\n')
fprintf('\\begin{tabular}{l@{\\hspace*{0.5cm}}cccr@{\\hspace*{1cm}}cccr}\n')
fprintf('\\hline\\hline\n')
fprintf('         & \\multicolumn{4}{c}{SMC} & \\multicolumn{4}{c}{RWMH}  \\\\\n')
fprintf('Parameter & Mean & $[0.05, 0.95]$ & STD(Mean) & $N_{eff}$ & Mean & $[0.05, 0.95]$ & STD(Mean) & $N_{eff}$ \\\\ \\hline\n')
rne = diffuse_rwmh_vs_smc.RNE(2, parasel);
fprintf('\\end{tabular}\n')
fprintf('\\end{center}\n')
fprintf('\n\n')

fprintf('{\\it Notes:} Means and standard deviations are over 20 runs for\n')
fprintf('  each algorithm.  The RWMH algorithms use 10 million draws with the\n')
fprintf('  first 5 million discarded.\n')
fprintf('  The SMC algorithms use 12,000 particles and 500 stages. The two algorithms\n')
fprintf('  utilize approximately the same computational resources.\n')
fprintf('  We define $N_{eff} = \\hat{\\mathbb{V}}_{\\pi}[\\theta] / STD^2$.\n')
fprintf('\\end{table}\n')



%------------------------------------------------------------------------------
% Table 3 -- SW Diffuse Prior Posterior Modes
%------------------------------------------------------------------------------
mode_para = {'xiw', 'iotaw', 'rhow', 'muw', 'xip', 'iotap', 'rhop', 'mup'};
[paramode, postmode, propmode] = diffuse_rwmh_vs_smc.algorun(2).max_under_restriction('rhow', 'xiw', mode_para);






%
%
%  Appendix
%
%

%------------------------------------------------------------------------------ 
% Figure A-1 -- Prior Comparison
%------------------------------------------------------------------------------ 
prior_comparison = AlgorithmComparison({reg_prior_set, dif_prior_set});

prior_para = {'h', 'xiw', 'pibar', 'gambar'};
prior_comparison.ksdensity(prior_para, 'file', 'figures/sw_prior.eps');

fprintf('\\begin{figure}\n')
fprintf('  \\begin{center}\n')
fprintf('    \\caption{\\sc{SW Model: SW Prior Comparison}}\n')
fprintf('    \\label{fig:sw-prior}\n')
fprintf('    \\includegraphics[height=3.5in]{figures/sw_prior.pdf}\n')
fprintf('\\end{center}\n')
fprintf('\\end{figure}\n')

fprintf('\n\n')






%------------------------------------------------------------------------------
% Table A1 -- SW Regular Prior 
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:sw-prior', ...
            'tab_caption', 'SW Model: Standard Prior'};
sw_regular_prior.latex_table(tab_args{:});
fprintf('\n\n')


%------------------------------------------------------------------------------
% Table A2 -- SW Regular Prior Posterior
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:sw-pos', ...
            'tab_caption', 'SW Model with Standard Prior: Posterior Comparison'};
tab_para = find(1-sw_regular_prior.pmask);
regular_rwmh_vs_smc.posterior_table(tab_para, tab_args{:});
fprintf('\n\n')


%------------------------------------------------------------------------------
% Table A3 -- SW Diffuse Prior 
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:sw-diffuse-prior', ...
            'tab_caption', 'SW Model: Diffuse Prior'};
sw_diffuse_prior.latex_table(tab_args{:});
fprintf('\n\n');


%------------------------------------------------------------------------------
% Table A4 -- SW Diffuse Prior Posterior
%------------------------------------------------------------------------------
tab_args = {'tab_label', 'tab:sw-diffuse-pos-all', ...
            'tab_caption', ['SW Model with Diffuse Prior: Posterior Comparison']};
diffuse_rwmh_vs_smc.posterior_table(tab_para, tab_args{:})


%------------------------------------------------------------------------------
% Table A5 -- Effects of Adaptation
%------------------------------------------------------------------------------
fixed_runs = get_file_list('input/sw_smc_nonadaptive.txt');
fixed_set = {fixed_runs, 'smc'};

smcruns = get_file_list('input/sw_smc_diffuse.txt');
smc_set = {smcruns, 'smc'};


tab_args = {'tab_label', 'tab:sw-diffuse-prior', ...
            'tab_caption', 'SW Model: Diffuse Prior'};

tab_para = find(1-sw_regular_prior.pmask);

adapt_set = {smc_set, fixed_set};
nonadaptive_rwmh_vs_smc = AlgorithmComparison(adapt_set, names{:}, mask{:});



fprintf('\\begin{table}[h!]\n')
fprintf('\\begin{center}\n')
fprintf('\\caption{\\sc{SW Model: Diffuse Prior -- Effects of Adaption}}\n')
fprintf('\\label{tab:sw-adaption}\n')
fprintf('\\vspace*{1cm}\n')
fprintf('\\scalebox{0.95}{\n')
fprintf('\\begin{tabular}{l@{\\hspace*{0.5cm}}ccc@{\\hspace*{1cm}}ccc}\n')
fprintf('\\hline\\hline\n')
fprintf('          & \\multicolumn{3}{c}{Mean(Mean)} & \\multicolumn{3}{c}{Std(Mean)} \\\\\n')
fprintf('Parameter & Adaptive & Non- & T-stat & Adaptive  & Non- & F-stat \\\\\n')
fprintf('          & ($\\hat{\\zeta}_n$) & Adaptive ($\\zeta_n$) & PIT & ($\\hat{\\zeta}_n$) & Adaptive ($\\zeta_n$) & PIT \\\\\n')
fprintf('\\hline\n')
[mu_p, sig_p] = nonadaptive_rwmh_vs_smc.stat_table(tab_para, tab_args{:});
fprintf('\\hline\\hline\n')
fprintf('\\end{tabular}\n')
fprintf('}\n')
fprintf('\\end{center}\n')
fprintf('{\\em Notes:} This table shows the Probability Integral Transforms (PIT) of the $t$ and\n')
fprintf('$F$ statistics for tests for differences in means and variances of the posterior\n')
fprintf('means from the SMC algorithm with adaptive and non-adaptive tuning parameters. Stars\n')
fprintf('refer to PITs in the 5 percent extremes of the distribution. For the adaptive algorithm,\n')
fprintf('we also generate a new sequence of random blocks $\\{B_n\\}$ for every repetition of the\n')
fprintf('algorithm and we determine the resampling indicators $\\{ \\rho_n \\}$ adaptively.\n')
fprintf('For the non-adaptive algorithm, we determine sequences $\\{\\rho_n\\}$, $\\{B_n\\}$, and $\\{\\zeta_n\\}$\n')
fprintf('in a trial run and hold these sequences fixed across repetitions of the algorithm.\n')
fprintf('\\end{table}\n')
