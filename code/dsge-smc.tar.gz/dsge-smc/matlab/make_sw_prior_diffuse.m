prior = load('/mq/home/m1eph00/code/fortran/models/sw/prior.txt');

npara = size(prior, 1);

for i = 1:npara
    ptype = prior(i, 1);
    
    switch ptype
      case 1
        prior(i, 1:3) = [5 0 1];
      case 2
        prior(i, 3) = 3*prior(i, 3);
      case 3
        prior(i, 3) = 3*prior(i, 3);
    end
end

save('-ascii', '~/code/fortran/models/sw/sw_diffuse_rr.txt', 'prior');
    