function para = eph2sgu_para(param_estim)

   thet      = param_estim(1,:);
   gam       = param_estim(2,:);
   kap       = param_estim(3,:);
   del2_del1 = param_estim(4,:);
   b         = param_estim(5,:);
   rhoxg     = param_estim(6,:);
   rhoz      = param_estim(7,:);
   rhoa      = param_estim(8,:);
   rhog      = param_estim(9,:);
   rhox      = param_estim(10,:);
   rhom      = param_estim(11,:);
   rhozet    = param_estim(12,:);
   rhozi     = param_estim(13,:);

   % no need for calibrated parameters
   sigmua0   = param_estim(24,:); 
   sigmua4   = param_estim(25,:); 
   sigmua8   = param_estim(26,:); 
   sigmux0   = param_estim(27,:); 
   sigmux4   = param_estim(28,:); 
   sigmux8   = param_estim(29,:); 
   sigzi0    = param_estim(30,:); 
   sigzi4    = param_estim(31,:); 
   sigzi8    = param_estim(32,:); 
   sigz0     = param_estim(33,:);
   sigz4     = param_estim(34,:);
   sigz8     = param_estim(35,:);
   sigmu0    = param_estim(36,:);  
   sigmu4    = param_estim(37,:);  
   sigmu8    = param_estim(38,:);  
   sigg0     = param_estim(39,:);  
   sigg4     = param_estim(40,:);  
   sigg8     = param_estim(41,:);  
   sigzet0   = param_estim(42,:);  
   sigzet4   = param_estim(43,:);  
   sigzet8   = param_estim(44,:);  
   sigygr    = param_estim(45,:);

   para = [thet; gam; kap; del2_del1; b; rhoxg; rhoz; rhoa; rhog; rhox; rhom; ...
           rhozet; rhozi; sigz0; sigz4; sigz8; sigmua0; sigmua4; ...
           sigmua8; sigg0; sigg4; sigg8; sigmux0; sigmux4; sigmux8; 
           sigmu0; sigmu4; sigmu8; sigzet0; sigzet4; sigzet8; 
           sigzi0; sigzi4; sigzi8; sigygr;];

end 