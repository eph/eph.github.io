function X = dlyap2(a, c)

[ma, na] = size(a);
[mc, nc] = size(c);


% Check dimension of matrices
% omitted
%

a = inv( a+eye(ma) )*( a-eye(ma) );
c = 0.5*( eye(ma)-a )*c*( eye(ma)-a' );
b = a';


[mb, nb] = size(b);
% Perform Schur decomposition on A and convert to complex form
%
[ua, ta] = schur(a);
[ub, tb] = schur(b);

%{ta, ua} = schtoc(schur(a));
%{tb, ub} = schtoc(schur(b));


% Transform C
%
ucu = -ua'*c*ub;

% solve for first column of transformed solution
%
y = zeros(ma,mb);
ema = eye(ma);
y(:,1) = inv(ta + ema*tb(1,1))*ucu(:,1);

% solve for remaining columns of transformed solution
%
k = 2;
for k = 2:mb
    
   km1 = 1:1:(k-1);%seqa(1,1,k-1);
   y(:,k) = inv( ta+ema*tb(k,k) )*( ucu(:,k) - y(:,km1)*tb(km1,k) ); 
end

   
% Find untransformed solution
%
X = ua*y*ub';

% Ignore complex part
%
X = real(X);

% Force X to be symmetric if C is symmetric
%
if c == c';
   X = 0.5*(X+X');
end;

end