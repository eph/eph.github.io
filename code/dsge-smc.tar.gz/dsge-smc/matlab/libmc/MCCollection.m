classdef MCCollection
    
    properties
        nruns
        type
        mc
        paranames
        pmask
        npara
    end
    
    methods
        function obj = MCCollection(runs, type, varargin)
            
            i_p = inputParser;
            i_p.KeepUnmatched = true;
            i_p.addRequired('runs', @iscell);
            i_p.addRequired('type', @ischar);

            obj.nruns = length(runs);
            obj.type = type;

            
            switch obj.type
              case 'smc'
                constructor = @SMCDraws;
              case 'rwmh'
                constructor = @RWMHDraws;
              case 'huge-rwmh'
                constructor = @HugeRWMHDraws;
              case 'prior'
                constructor = @(x) x;
              otherwise
                constructor = @ParameterDraws;
            end
            
            obj.mc = [];
            
            for i = 1:obj.nruns
                x = constructor(runs{i}, varargin{:});
                obj.mc = [obj.mc x];
            end
            
            obj.paranames = obj.mc(1).paranames;
            obj.pmask = obj.mc(1).pmask;
            obj.npara = obj.mc(1).npara;

        end


        function [mu sigmu] = mean(obj);

            if (obj.nruns==1)
                mu = obj.mc(1).mean;
                sigmu = zeros(obj.npara, 1);
                return
            end

            mu_mat = [];
            for i = 1:obj.nruns;
                mu_mat = [mu_mat; obj.mc(i).mean'];
            end

            mu = mean(mu_mat)';
            sigmu = std(mu_mat)';
        end

        function [sig sigsig] = sig(obj)
            if (obj.nruns==1)
                sig = obj.mc(1).std;
                sigsig = zeros(obj.npara, 1);
                return
            end
            
            sig_mat = [];
            for i = 1:obj.nruns;
                sig_mat = [sig_mat; obj.mc(i).std'];
            end

            sig = mean(sig_mat)';
            sigsig = std(sig_mat)';
        end
        
        function [q sigq] = quantile(obj, pval)
            if (obj.nruns==1)
                q = obj.mc(1).quantile(pval);
                sigq = zeros(obj.npara, 1);
                return
            end

            q_mat = [];
            for i = 1:obj.nruns;
                q_mat = [q_mat; obj.mc(i).quantile(pval)'];
            end

            q = mean(q_mat)';
            sigq = std(q_mat)';
        end
        
        function [mu sig] = mdd(obj)
            
            mdd = zeros(obj.nruns, 1);
            
            for i = 1:obj.nruns;
                mdd(i, 1) = obj.mc(i).mdd;
            end
            
            mu = mean(mdd);
            sig = std(mdd);
            
        end

        function [mu sig] = greater_than(obj, para1, para2);

            prop = zeros(obj.nruns, 1);
            
            for i = 1:obj.nruns
                prop(i, 1) = mean(obj.mc(i).greater_than(para1, para2));
            end

            mu = mean(prop);
            sig = std(prop);
            
        end


        function [mu sig] = in_interval(obj, para1, interval);

            prop = zeros(obj.nruns, 1);
            
            for i = 1:obj.nruns
                prop(i, 1) = mean(obj.mc(i).in_interval(para1, interval));
            end

            mu = mean(prop);
            sig = std(prop);
            
        end

        function [px, postx, propx] = max_under_restriction(obj, para1, para2, psel)
            
            p1 = obj.paranames.get_selected_indices(para1);
            p2 = obj.paranames.get_selected_indices(para2);
            psel = obj.paranames.get_selected_indices(psel);
            
            xpara = [];
            xpost = [];
            
            for i = 1:obj.nruns
               
                xpara = [xpara;obj.mc(i).parasmc];
                xpost = [xpost;obj.mc(i).postsmc];
                
            end

            mode1 = xpara(:, p1) > xpara(:, p2);
            mode2 = 1 - mode1;
            
            [m1, ind1] = max(xpost(mode1 == 1));
            [m2, ind2] = max(xpost(mode2 == 1));

            para1 = xpara(mode1 == 1, :);
            para2 = xpara(mode2 == 1, :);

            
            px = [para1(ind1, :)' para2(ind2, :)'];
            postx = [m1, m2];
            
            propx = [mean(mode1) mean(mode2)];
            
            fprintf('\\begin{table}\n')
            fprintf('\\begin{center}\n')
            fprintf('\\begin{tabular}{lc@{\\hspace*{0.5cm}}c}\n');
            fprintf('\\hline\\hline \n')
            fprintf(' Parameter & Mode 1 & Mode 2 \\\\ \n')
            fprintf('\\hline\n')
            for ii = 1:length(psel);
                parai = psel(ii);
                fprintf('%-12s & %5.3f & %5.3f \\\\ \n', ...
                        ['$' strtrim(obj.paranames.ptexnames{parai}) '$'], ...
                        [para1(ind1, parai)' para2(ind2, parai)'])
            end

            fprintf('\\hline\n')
            fprintf('%-15s & %5.2f & %5.2f \\\\ \n', 'Log Posterior', m1, m2);

            fprintf('\\hline\\hline\n')
            fprintf('\\end{tabular}\n')
            fprintf('\\end{center}\n')
            fprintf('\\end{table}\n')
            
        end

        function varargout = ksdensity(obj, psel, varargin)

            for i = 1:obj.nruns
                [dens(i).f dens(i).x] = obj.mc(i).ksdensity(psel, varargin{:});
            end
            
            if nargout == 0
                nplots = size(dens(1).f, 1);

                clf
                for i = 1:obj.nruns
                    
                    hold on
                    for j = 1:nplots
                        line(dens(i).x(j, :), dens(i).f(j, :))
                    end
                end
            else
                varargout{1} = dens;
            end
            
            
                    
        end
        
    end
    
    
end