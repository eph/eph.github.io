#!/bin/bash
#PBS -l procs=48,mem=30gb,walltime=1000:00:00 -S /bin/csh

mpicmd=$ARC_MPI
outdir=$OUTPUT_BASE/dsge-smc/draft-3/news/smc/diffuse/
exedir=~/code/staging/

#hypdir=$OUTPUT_BASE/dsge-smc/draft-3/sw/smc/diffuse/smc-sw-new-diffuse-mix-npart-12000-nintmh-1-nphi-500-prior-b6-trial2-phibend

cd $ARC_MPI_LOC
cat $PBS_NODEFILE


cd $exedir

for i in {1..1}
do
    $mpicmd -np 48 ./smc_driver_mpi -n 32048 -o 6 -i $i --output-dir $outdir > $outdir/log_update$i.txt
done