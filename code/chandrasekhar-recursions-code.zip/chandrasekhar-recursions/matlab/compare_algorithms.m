% file: compare_algorithms.m
%   
%   Compares 
%      - Standard Kalman Filtering equations.
%      - The Strid-Walentin (2009) Block KF algorithm.
%      - The Chandrasekhar-type recursions algorithm (Morf et al. 1974).
%   
%   By evaluated the likelihood of RBC/Smets-Wouters/News Model `nsim' times.
%    
%   Obviously "timing" algorithms in this way is not ideal.  This is
%   just meant to give a quick comparison between the algorithms.  I
%   have tried reordering, running each one individually, and playing
%   with the threading and compiler settings.  The qualitative results
%   stay the same and are in line with my experience using the
%   Chandrasekhar-type recursions for a variety of economic models.
%   
% Implemented by Ed Herbst [edward.p.herbst@frb.gov]
%------------------------------------------------------------------------------- 
clear all
addpath('gensys')
addpath('filter')
addpath('objfun')
addpath('from-dynare');
rmpath(genpath('/models'))

% Select the model.
% model = {'news', 'rbc', 'gss', 'sw'}
model = 'rbc' 

switch model
  case 'gss'
    addpath('models/gss')
  case 'rbc'
    addpath('models/rbc')
  case 'sw'
    addpath('models/sw')
  case 'news'
    addpath('models/news')
  otherwise
    error('Bad model selection.')
end
% If you want to view the profiler.
% profile on
nsim = 100;

% Uncomment this region and change `nthreads' if you want to change the number
% of threads used by matlab in multithreaded BLAS and the JIT compiler.  I
% haven't found that much difference in the ranking of the algorithms wrt serial
% or threaded execution.
%
% nthreads = 8
% LastN = maxNumCompThreads(nthreads);

% Without the JIT compiler
% feature accel on

% load data
loaddata

% get parameters
p0 = pmsv();

%-------------------------------------------------------------------------------
% Begin comparison
%-------------------------------------------------------------------------------
t0 = 4;                                 % condition on first four observations

%-----------------------------------------------------------
% Standard Kalman Filter
%-----------------------------------------------------------
tic
for i = 1:nsim
    f0 = objfun(y, p0, t0);
end
toc
y0 = y;
fprintf('Standard Kalman Filter: f(p0) = %7.2f.\n\n', f0)

%-----------------------------------------------------------
% Strid-Walentin (only for SW model)
%-----------------------------------------------------------
if strcmp(model, 'sw')|strcmp(model, 'rbc')
    tic
    for i = 1:nsim
        f0 = objfun_sw(y, p0, t0);
    end
    toc
    fprintf('Strid-Walentin: f(p0) = %7.2f.\n\n', f0)
end

%-----------------------------------------------------------
% Chandrasekhar-type Recursions
%-----------------------------------------------------------
tic
for i = 1:nsim
    f0 = objfun_cr(y, p0, t0);
end
toc
fprintf('Chandrasekhar-type Recursions: f(p0) = %7.2f.\n\n', f0)

% profile viewer                          