function para = sgu2eph_para(param_estim)

   thet      = param_estim(1);
   gam       = param_estim(2);
   kap       = param_estim(3);
   del2_del1 = param_estim(4);
   b         = param_estim(5);
   rhoxg     = param_estim(6);
   rhoz      = param_estim(7);
   rhoa      = param_estim(8);
   rhog      = param_estim(9);
   rhox      = param_estim(10);
   rhom      = param_estim(11);
   rhozet    = param_estim(12);
   rhozi     = param_estim(13);
   alpk      = 0.225;
   alph      = 0.675;
   del0      = 0.025;
   bet       = 0.99;
   hss       = 0.20;
   muss      = 1.15;
   muass     = 0.9957;
   muxss     = 1.00324407709013;
   sig       = 1;
   g_y       = 0.2;
   sigmua0   = param_estim(17); 
   sigmua4   = param_estim(18); 
   sigmua8   = param_estim(19); 
   sigmux0   = param_estim(23); 
   sigmux4   = param_estim(24); 
   sigmux8   = param_estim(25); 
   sigzi0    = param_estim(32); 
   sigzi4    = param_estim(33); 
   sigzi8    = param_estim(34); 
   sigz0     = param_estim(14);
   sigz4     = param_estim(15);
   sigz8     = param_estim(16);
   sigmu0    = param_estim(26);  
   sigmu4    = param_estim(27);  
   sigmu8    = param_estim(28);  
   sigg0     = param_estim(20);  
   sigg4     = param_estim(21);  
   sigg8     = param_estim(22);  
   sigzet0   = param_estim(29);  
   sigzet4   = param_estim(30);  
   sigzet8   = param_estim(31);  
   sigygr    = param_estim(35);

   para = [thet; gam; kap; del2_del1; b; rhoxg; rhoz; rhoa; rhog; rhox; rhom;
           rhozet; rhozi; alpk; alph; del0; bet; hss; muss; muass; 
           muxss; sig; g_y;sigmua0; sigmua4; sigmua8; sigmux0; sigmux4; sigmux8;
           sigzi0; sigzi4; sigzi8; sigz0; sigz4; sigz8; sigmu0; sigmu4; sigmu8;
           sigg0; sigg4; sigg8; sigzet0; sigzet4; sigzet8; sigygr];
   
end
