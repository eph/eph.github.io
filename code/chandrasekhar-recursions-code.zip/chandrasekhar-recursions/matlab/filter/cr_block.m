% file: cr.m
% 
%  function: cr(y, TT, RR, QQ, DD, ZZ, HH, A0, P0) 
% 
%  Evaluates the log-likelihood of a stationary LGSS model using the
%  Chandrasekhar-type recursions.  See Morf et al (1974). 
%    s_t = TT*s_{t-1} + RR*eps_t,  eps_t ~ iidN(0, QQ)
%    y_t = DD + ZZ*s_t + eta_t, eta_t ~ iidN(0, HH)
% 
%  y should be nobs x ny, that is, each row corresponding to a time period. 
%
%  The state are initialized from the stationary distribution.
%
%  t0 is the number of initial observations to condition on.
%
%  Returns:
%    loglh -- the log likelihood (scalar).
%
%  In the code write Kt as TT*Pt*ZZ*iFt, rather than TT*Pt*ZZ. 
%  I.e., it is K_{g, t} in the notes.
%
% Implemented by Ed Herbst <edward.p.herbst@frb.gov>
%------------------------------------------------------------------------------- 
function loglh = cr_block(y, TT, RR, QQ, DD, ZZ, HH, t0)

    
    [nobs, ny] = size(y);
    [ns, ~] = size(TT);
    [nexo, ~] = size(QQ);
    
    B = TT(nexo+1:ns, 1:nexo)*inv(TT(1:nexo, 1:nexo));
    At = zeros(ns, 1);
    Pt = dlyap(TT, RR*QQ*RR');
    
    Pt = TT*Pt*TT' + RR*QQ*RR';
    Ft = ZZ*Pt*ZZ' + HH;
    iFt = inv(Ft);

    St = TT*Pt*ZZ';
    Mt = -iFt;    
    Kt = St*iFt;  

    loglh = 0;
    for i = 1:nobs

        % calculate the forecast errors
        yhat = ZZ*At + DD;
        nut = y(i, :) - yhat';
    
        %iFtnu = Ft \ nut';
        if i > t0 
            loglh = loglh - 0.5*ny*log(2*pi) - 0.5*log(det(Ft)) - 0.5*nut*iFt*nut';
        end

        % updating
        At = TT*At + Kt*nut';

        % these are intermediate calculations we can re-use
        % MSpZp = Mt*St'*ZZ';
        ZZSt = ZZ*St;
        MSpZp = Mt*(ZZSt');
        St1 = St(1:nexo, :);
        St2 = St(nexo+1:ns, :);
        TTSt1 = TT(1:nexo, 1:nexo)*St1;
        TTSt = [TTSt1; B*TTSt1 + TT(nexo+1:ns, nexo+1:ns)*St2];
        %TTSt = TT*St
        
        Ft1  = Ft + ZZSt*MSpZp;         % F_{t+1}
        Ft1 = 0.5*(Ft1+Ft1');           
        iFt1 = inv(Ft1);
        
        Kt = (Kt*Ft + TTSt*MSpZp)*iFt1; % K_{t+1}
        St = TTSt - Kt*ZZSt;            % S_{t+1}
        Mt = Mt + MSpZp*iFt*MSpZp';     % M_{t+1}

        Ft = Ft1;
        iFt = iFt1;
    end
    
end