function [lik, all_s_up, Neff, len_phis] = tempered_PF_lik(A, B, H, Phi, R, S2, N, yt, x0, P0, tune)
% -----------------------------------------------------------------------
% tempered particle filtering for DSGE model with measurement error
%
% Author: Minsu Chang        minsuc@sas.upenn.edu
% Last modified: 5/8/2017
% -----------------------------------------------------------------------
%                        Model( Linear Model)
%               y(t) = A + B*s(t) + u(t), u(t) ~ N(0,H)
%           s(t) = Phi*s(t-1) + R*e(t), e(t) ~ iid N(0,S2)
% -----------------------------------------------------------------------
% Input
%   A, B, H : parameters for measurement equation
%   Phi, R, S2 : parameters for transition equation
%   N       : number of particles
%   yt      : data
%   x0, P0  : initial prior for the filter
% -----------------------------------------------------------------------
% Output
%   lik       : likelihood (T by 1)
%   all_s_up  : particles resampled (updated) (T by N)
%   Neff      : Effective sample size
% -----------------------------------------------------------------------

% housekeeping
ne        = size(S2,1);
[~, ns] = size(B);
T         = size(yt,1);
sqrtS2    = R*chol(S2)';

% matrix for store
all_s_up  = zeros(T, ns, N);   % resampled
lik       = zeros(T,1);
Neff      = zeros(T,1);
len_phis  = ones(T,1);

% initialization
temp_s = x0;
temp_P = P0;
s_up   = repmat(temp_s, 1, N) + chol(temp_P)'*randn(ns, N);

weights = ones(N,1);


for tt=1:1:T

    yy = yt(tt,:);
    
        % Propagate
        
        eps = randn(ne, N);
        s_fore   = Phi*s_up + sqrtS2*eps;
        
        % Un-normalized weights (naive boostrap particle filter)
        perror  = repmat(yy'-A, 1, N) - B*s_fore;
        
        % initial tempering phi_1
        init_InEff_func = @(phi)(init_InEff_diff(phi,yy,perror,H,tune.rstar));
        phi_interval = [0.000001 1.0]; % initial interval (note that the signs at the end points should differ)
        phi_1 = fzero(init_InEff_func, phi_interval);
        
        density = zeros(N,1);   
            for nn = 1:N
                density(nn,1) = (2*pi)^(-size(yy,2)/2)*phi_1^(size(yy,2)/2)*det(H)^(-1/2)* ...
                    exp(-1/2*perror(:,nn)'*phi_1*inv(H)*perror(:,nn));
            end
        
        weights = (density.*weights)./(mean(density.*weights)); 
      
        id_up = randsample(N,N,true,weights)';
        s_up = s_up(:,id_up);  % Resampling 
        eps_up = eps(:,id_up);  % Resampling 

        weights = ones(N,1) ;
        
        lik(tt,1)  = lik(tt,1)+log(mean(density.*weights));
   
        
    
        % tempering iterations
        count = 2;
        phi_old = phi_1;
        
        s_fore   = Phi*s_up + sqrtS2*eps_up;
        perror  = repmat(yy'-A, 1, N) - B*s_fore;
        check_InEff = InEff(1.0, phi_1, yy, perror, H);
        
        while (check_InEff > tune.rstar)
            
            count = count + 1;
            InEff_func = @(phi)(InEff(phi, phi_old, yy, perror, H) - tune.rstar);
            phi_interval = [phi_old 1.0];
            fphi_interval = [InEff_func(phi_old) InEff_func(1.0)];
            
            if prod(sign(fphi_interval))==-1
            
                phi_new = fzero(InEff_func, phi_interval);
                check_InEff = InEff(1.0, phi_new, yy, perror, H);
            
            for nn = 1:N
                density(nn,1) = (phi_new/phi_old)^(size(yy,2)/2)* ...
                    exp(-1/2*perror(:,nn)'*(phi_new-phi_old)*inv(H)*perror(:,nn));
            end

            weights = (density.*weights)./(mean(density.*weights));       
          
            id_up = randsample(N,N,true,weights)';
            s_up = s_up(:,id_up);  % Resampling 
            eps_up = eps_up(:,id_up);
        
            weights = ones(N,1) ;
            lik(tt,1)  = lik(tt,1)+log(mean(density.*weights));
            
             tune.c = tune.c*(0.95 + 0.10*exp(16*(tune.acpt-tune.trgt))/(1 + ...
             exp(16*(tune.acpt-tune.trgt))));
 
        tune.mu = mean(eps_up,2);
        cov_s = 1/N*(eps_up - repmat(tune.mu,1,N))*(eps_up - repmat(tune.mu,1,N))';
                        
        [~,checkp] = chol(cov_s);
                if checkp ~= 0 
                    tune.R = diag(diag(cov_s));%eye(size(cov_s,1));
                else
                    tune.R = cov_s;
                end
           
        % mutation
            
        temp_acpt = zeros(N,1); %initialize accpetance indicator
            parfor nn = 1:N
                %[ind_s, ind_eps, ind_acpt] = mutation_RWMH(s_up(:,nn), eps_up(:,nn), Phi, sqrtS2, A, B, H, yy, tune)
                [ind_s, ind_eps, ind_acpt] = mutation_RWMH_multistep(s_up(:,nn), eps_up(:,nn), Phi, sqrtS2, A, B, H, yy, tune)
   
                s_fore(:,nn) = ind_s;
                eps_up(:,nn) = ind_eps;    
                temp_acpt(nn,1) = ind_acpt;
            end 
    
        tune.acpt = mean(temp_acpt); % update average acceptance rate
     
             perror  = repmat(yy'-A, 1, N) - B*s_fore;
   
    
            phi_old = phi_new;
            len_phis(tt) = len_phis(tt)+1;
     
     
            fprintf(' phi  = %2.5f    \n', phi_old);
      
            else
                check_InEff = tune.rstar;
            end
     
        end
    
        phi_new = 1.0;
          
            for nn = 1:N
                density(nn,1) = (phi_new/phi_old)^(size(yy,2)/2)* ...
                    exp(-1/2*perror(:,nn)'*(phi_new-phi_old)*inv(H)*perror(:,nn));
            end

        weights = (density.*weights)./(mean(density.*weights));
       
        id_up = randsample(N,N,true,weights)';
        s_up = s_up(:,id_up);  % Resampling 
        eps_up = eps_up(:,id_up);
        
        weights = ones(N,1) ;
        lik(tt,1)  = lik(tt,1)+log(mean(density.*weights));
     
    
        tune.c = tune.c*(0.95 + 0.10*exp(16*(tune.acpt-tune.trgt))/(1 + ...
             exp(16*(tune.acpt-tune.trgt))));
 
        tune.mu = mean(eps_up,2);
        cov_s = 1/N*(eps_up - repmat(tune.mu,1,N))*(eps_up - repmat(tune.mu,1,N))';
                        
        [~,checkp] = chol(cov_s);
                if checkp ~= 0 
                    tune.R = diag(diag(cov_s));%eye(size(cov_s,1));
                else
                    tune.R = cov_s;
                end
   
            
        % mutation
            
        temp_acpt = zeros(N,1); %initialize accpetance indicator
            parfor nn = 1:N
%               [ind_s, ind_eps, ind_acpt] = mutation_RWMH(s_up(:,nn), eps_up(:,nn), Phi, sqrtS2, A, B, H, yy, tune)
                [ind_s, ind_eps, ind_acpt] = mutation_RWMH_multistep(s_up(:,nn), eps_up(:,nn), Phi, sqrtS2, A, B, H, yy, tune)
               
                s_fore(:,nn) = ind_s;
                eps_up(:,nn) = ind_eps;    
                temp_acpt(nn,1) = ind_acpt;
            end 
    
        tune.acpt = mean(temp_acpt); % update average acceptance rate
      
               
    
       % Store results
    
       Neff(tt,1) = (N^2)/sum(weights.^2);
       all_s_up(tt,:,:) = s_up;               
       s_up = s_fore;
      
       fprintf(' time  = %d    \n', tt);
       fprintf('-----------------------------------------------\n')
      

end



