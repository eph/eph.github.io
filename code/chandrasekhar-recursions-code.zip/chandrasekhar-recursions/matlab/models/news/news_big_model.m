function varargout = news_big_model (para);

  retcode = 0;
  valid   = 1;

  thet		= para(1)+1;
  gam		= para(2);
  kap		= para(3);
  del2_del1	= para(4);
  b		= 0.99*para(5);
  rhoxg		= 0.99*para(6);
  rhoz		= 0.99*para(7);
  rhoa		= 0.99*para(8);
  rhog		= 0.99*para(9);
  rhox		= para(10);
  rhom		= 0.99*para(11);
  rhozet	= 0.99*para(12);
  rhozi		= 0.99*para(13);

  %% set calibrated parameters -- not the optimal way of doing things
  alpk  = para(14);
  alph	= para(15);
  del0	= para(16);
  bet	= para(17);
  hss	= para(18);
  muss	= para(19);
  muass = para(20);
  muxss = para(21);
  sig	= para(22);
  g_y	= para(23);

  %% find steady states, et cetera 
  ss = news_ss(para);
  mukss = ss(1);
  muyss = ss(2);
  xgss	= ss(3);
  g_y	= ss(4);
  y_k	= ss(5);
  i_k	= ss(6);
  i_y	= ss(7);
  c_y	= ss(8);
  y_c	= ss(9);
  betbar= ss(10);
  badj	= ss(11);
  ppsi	 =ss(12);
  del1	= ss(13);
  del2	= ss(14);
  xi	= ss(15);
  eta	= ss(16);


  %% equations  
  eq_muy	= 1;
  eq_muk	= 2;
  eq_xg		= 3;
  eq_mua	= 4;
  eq_mua8_1	= 5;
  eq_mua8_2	= 6;
  eq_mua8_3	= 7;
  eq_mua8_4	= 8;
  eq_mua8_5	= 9;
  eq_mua8_6	= 10;
  eq_mua8_7	= 11;
  eq_mua8_8	= 12;
  eq_mux        = 13;
  eq_mux8_1	= 14;
  eq_mux8_2	= 15;
  eq_mux8_3	= 16;
  eq_mux8_4	= 17;
  eq_mux8_5	= 18;
  eq_mux8_6	= 19;
  eq_mux8_7	= 20;
  eq_mux8_8	= 21;
  eq_zi         = 22;
  eq_zi8_1	= 23;
  eq_zi8_2	= 24;
  eq_zi8_3	= 25;
  eq_zi8_4	= 26;
  eq_zi8_5	= 27;
  eq_zi8_6	= 28;
  eq_zi8_7	= 29;
  eq_zi8_8	= 30;
  eq_z          = 31;
  eq_z8_1	= 32;
  eq_z8_2	= 33;
  eq_z8_3	= 34;
  eq_z8_4	= 35;
  eq_z8_5	= 36;
  eq_z8_6	= 37;
  eq_z8_7	= 38;
  eq_z8_8	= 39;
  eq_mu         = 40;
  eq_mu8_1	= 41;
  eq_mu8_2	= 42;
  eq_mu8_3	= 43;
  eq_mu8_4	= 44;
  eq_mu8_5	= 45;
  eq_mu8_6	= 46;
  eq_mu8_7	= 47;
  eq_mu8_8	= 48;
  eq_g          = 49;
  eq_g8_1	= 50;
  eq_g8_2	= 51;
  eq_g8_3	= 52;
  eq_g8_4	= 53;
  eq_g8_5	= 54;
  eq_g8_6	= 55;
  eq_g8_7	= 56;
  eq_g8_8	= 57;
  eq_zet        = 58;
  eq_zet8_1	= 59;
  eq_zet8_2	= 60;
  eq_zet8_3	= 61;
  eq_zet8_4	= 62;
  eq_zet8_5	= 63;
  eq_zet8_6	= 64;
  eq_zet8_7	= 65;
  eq_zet8_8	= 66;
  eq_glag	= 80;
  eq_xglag	= 78;
  eq_zlag	= 79;
  eq_inv	= 67;
  eq_res	= 68;
  eq_v		= 69;
  eq_s		= 70;
  eq_c          = 71;
  eq_h		= 72;
  eq_p		= 73;
  eq_y		= 74;
  eq_cap	= 75;
  eq_eul	= 76;
  eq_pinv	= 77;
  eq_ylag	= 81;
  eq_clag	= 82;
  eq_ilag	= 83;
  eq_hlag	= 84;
  eq_Elam	= 85;
  eq_Emuy	= 86;
  eq_Emuk	= 87;
  eq_Ei		= 88;
  eq_Eu		= 89;
  eq_Ez		= 90;
  eq_Eh		= 91;
  eq_Emua	= 92;
  eq_Eq		= 93;
  eq_Ep         = 94;
  eq_Es         = 95;
  eq_Ezet       = 96;
  eq_Ec         = 97;
  eq_Ev         = 98;
  
  %% variables   
  v_muy		= 1;
  v_muk		= 2;
  v_xg		= 3;
  v_mua		= 4;
  v_mua8_1	= 5;
  v_mua8_2	= 6;
  v_mua8_3	= 7;
  v_mua8_4	= 8;
  v_mua8_5	= 9;
  v_mua8_6	= 10;
  v_mua8_7	= 11;
  v_mua8_8	= 12;
  v_mux		= 13;
  v_mux8_1	= 14;
  v_mux8_2	= 15;
  v_mux8_3	= 16;
  v_mux8_4	= 17;
  v_mux8_5	= 18;
  v_mux8_6	= 19;
  v_mux8_7	= 20;
  v_mux8_8	= 21;
  v_zi		= 22;
  v_zi8_1	= 23;
  v_zi8_2	= 24;
  v_zi8_3	= 25;
  v_zi8_4	= 26;
  v_zi8_5	= 27;
  v_zi8_6	= 28;
  v_zi8_7	= 29;
  v_zi8_8	= 30;
  v_z		= 31;
  v_z8_1	= 32;
  v_z8_2	= 33;
  v_z8_3	= 34;
  v_z8_4	= 35;
  v_z8_5	= 36;
  v_z8_6	= 37;
  v_z8_7	= 38;
  v_z8_8	= 39;
  v_mu	        = 40;
  v_mu8_1	= 41;
  v_mu8_2	= 42;
  v_mu8_3	= 43;
  v_mu8_4	= 44;
  v_mu8_5	= 45;
  v_mu8_6	= 46;
  v_mu8_7	= 47;
  v_mu8_8	= 48;
  v_g		= 49;
  v_g8_1	= 50;
  v_g8_2	= 51;
  v_g8_3	= 52;
  v_g8_4	= 53;
  v_g8_5	= 54;
  v_g8_6	= 55;
  v_g8_7	= 56;
  v_g8_8	= 57;
  v_zet	        = 58;
  v_zet8_1	= 59;
  v_zet8_2	= 60;
  v_zet8_3	= 61;
  v_zet8_4	= 62;
  v_zet8_5	= 63;
  v_zet8_6	= 64;
  v_zet8_7	= 65;
  v_zet8_8	= 66;
  v_glag        = 67;
  v_xglag       = 68;
  v_zlag        = 69;
  v_k1		= 70;
  v_u		= 71;
  v_i		= 72;
  v_c		= 73;
  v_y		= 74;
  v_s		= 75;
  v_h		= 76;
  v_p		= 77;
  v_q           = 78;
  v_v           = 79;
  v_lam		= 80;
  v_ylag        = 81;
  v_clag        = 82;
  v_ilag        = 83;
  v_hlag        = 84;
  v_Elam        = 85;
  v_Emuy        = 86;
  v_Emuk        = 87;
  v_Ei          = 88;
  v_Eu          = 89;
  v_Ez          = 90;
  v_Eh          = 91;
  v_Emua        = 92;
  v_Eq          = 93;
  v_Ep          = 94;
  v_Es          = 95;
  v_Ezet        = 96;
  v_Ec          = 97;
  v_Ev          = 98;

  %% shocks
  e_mua0	= 1;
  e_mua4	= 2;
  e_mua8	= 3;
  e_mux0	= 4;
  e_mux4	= 5;
  e_mux8	= 6;
  e_zi0		= 7;
  e_zi4		= 8;
  e_zi8		= 9;
  e_z0		= 10;
  e_z4		= 11;
  e_z8		= 12;
  e_mu0		= 13;
  e_mu4		= 14;
  e_mu8		= 15;
  e_g0		= 16;
  e_g4		= 17;
  e_g8		= 18;
  e_zet0	= 19;
  e_zet4	= 20;
  e_zet8	= 21;

  %% expectation errors
  sh_Elam       = 1;
  sh_Emuy       = 2;
  sh_Emuk       = 3;
  sh_Ei         = 4;
  sh_Eu         = 5;
  sh_Ez         = 6;
  sh_Eh         = 7;
  sh_Emua       = 8;
  sh_Eq         = 9;
  sh_Ep         = 10;
  sh_Es         = 11;
  sh_Ezet	= 12;
  sh_Ec		= 13;
  sh_Ev		= 14;
  
  %%  summary
  neq  = 98;
  neta = 14;
  neps = 21;

  %% definitions  
  GAM0 = zeros (neq, neq);
  GAM1 = zeros (neq, neq);
  PPI  = zeros (neq, neta);
  PSI  = zeros (neq, neps);
  C    = zeros (neq, 1);

  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      1. Capital Accumulation                          %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_inv, v_k1) = -1;
  GAM0(eq_inv, v_u)  = -del1/mukss;
  GAM0(eq_inv, v_muk)= -(1-del0)/mukss;
  GAM1(eq_inv, v_k1) = -(1-del0)/mukss;
  GAM0(eq_inv, v_i)  =  i_k;
  GAM0(eq_inv, v_zi) =  i_k;
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      2. Resource Constraint                           %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_res, v_c)   = c_y;
  GAM0(eq_res, v_i)   = i_y;
  GAM0(eq_res, v_g)   = g_y*xgss;
  GAM0(eq_res, v_xg)  = g_y*xgss;
  GAM0(eq_res, v_y)   = -1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      3. Consumption Bundle                           %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_v, v_v)   = -(1-badj)*(1-ppsi*hss^thet*(1/muyss)^((1-gam)/gam));
  GAM0(eq_v, v_c)   =  1;
  GAM0(eq_v, v_muy) =  badj;
  GAM1(eq_v, v_c)   =  badj;
  GAM0(eq_v, v_h)   = -ppsi*hss^thet*(1-badj)*(1/muyss)^((1-gam)/gam)*thet;
  GAM0(eq_v, v_s)   = -ppsi*hss^thet*(1-badj)*(1/muyss)^((1-gam)/gam);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      4. Consumption Decision                          %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_c, v_lam)  = -(1-betbar)*(1-eta);
  GAM0(eq_c, v_zet)  =  1;
  GAM0(eq_c, v_v)    = -sig;
  GAM0(eq_c, v_c)    =  eta*(1+betbar*badj)/(1-badj);
  GAM1(eq_c, v_c)    =  eta*badj/(1-badj);
  GAM0(eq_c, v_muy)  =  eta*badj/(1-badj);
  GAM0(eq_c, v_p)    = -eta;
  GAM0(eq_c, v_s)    = -eta;    
  GAM0(eq_c, v_Ezet) = -betbar;
  GAM0(eq_c, v_Ev)   =  betbar*sig;
  GAM0(eq_c, v_Ep)   =  betbar*eta;
  GAM0(eq_c, v_Es)   =  betbar*eta;
  GAM0(eq_c, v_Ec)   = -betbar*eta/(1-badj);
  GAM0(eq_c, v_Emuy) =  betbar*((1-eta)*sig-eta*badj/(1-badj));
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      5. Jaimovich-Rebelo Thing                        %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_s,v_s)    = -1;
  GAM0(eq_s,v_c)    =  gam/(1-badj);
  GAM1(eq_s,v_c)    =  gam*badj/(1-badj);
  GAM0(eq_s,v_muy)  =  gam*badj/(1-badj)-(1-gam);
  GAM1(eq_s,v_s)    = -(1-gam);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      6. Hours Decision                                %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_h,v_zet)  =  1;
  GAM0(eq_h,v_v)    = -sig;
  GAM0(eq_h,v_h)    =  thet;
  GAM0(eq_h,v_s)    =  1;
  GAM0(eq_h,v_lam)  = -1;
  GAM0(eq_h,v_y)    = -1;
  GAM0(eq_h,v_mu)   =  1;muss/(1+muss);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      7. Shadow Price                                  %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_p,v_p)    = -1;
  GAM0(eq_p,v_zet)  =  xi;
  GAM0(eq_p,v_v)    = -xi*sig;
  GAM0(eq_p,v_h)    =  xi*thet;
  GAM0(eq_p,v_Emuy) =  (1-xi)*(1-sig);
  GAM0(eq_p,v_Ep)   =  1-xi;
  GAM0(eq_p,v_Es)   =  1-xi;
  GAM0(eq_p,v_s)    = -(1-xi);
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      8. Output                                        %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM1(eq_y, v_k1) = -alpk;
  GAM0(eq_y, v_y)  = -1;
  GAM0(eq_y, v_z)  =  1;
  GAM0(eq_y, v_u)  =  alpk;
  GAM0(eq_y, v_muk)= -alpk;
  GAM0(eq_y, v_h)  =  alph;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      9. Capacity Utilization                          %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_cap, v_q)   = -1;
  GAM0(eq_cap, v_z)   =  1;
  GAM0(eq_cap, v_u)   =  alpk-1-del2/del1;
  GAM1(eq_cap, v_k1)  = -(alpk-1);
  GAM0(eq_cap, v_muk) = -(alpk-1);
  GAM0(eq_cap, v_h)   =  alph;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      10. Euler Equation                               %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_eul, v_lam)  = -1;
  GAM0(eq_eul, v_q)    = -1;
  GAM0(eq_eul, v_Elam) =  1;
  GAM0(eq_eul, v_Emua) =  1;
  GAM0(eq_eul, v_Emuy) = -sig;
  GAM0(eq_eul, v_Ez)   =  bet*muass*muyss^-sig*del1;
  GAM0(eq_eul, v_Eu)   =  bet*muass*muyss^-sig*del1*(alpk-1);
  GAM0(eq_eul, v_k1)   =  bet*muass*muyss^-sig*del1*(alpk-1);
  GAM0(eq_eul, v_Emuk) = -bet*muass*muyss^-sig*del1*(alpk-1);
  GAM0(eq_eul, v_Eh)   =  bet*muass*muyss^-sig*del1*alph;
  GAM0(eq_eul, v_Eq)   =  bet*muass*muyss^-sig*(1-del0);
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      11. Value of Firm                                %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_pinv, v_q)    =  1;
  GAM0(eq_pinv, v_zi)   =  1;
  GAM0(eq_pinv, v_i)    = -kap*(bet*muass*muyss^-sig*mukss^3 + mukss^2);
  GAM1(eq_pinv, v_i)    = -kap*mukss^2;
  GAM0(eq_pinv, v_muk)  = -kap*mukss^2;
  GAM0(eq_pinv, v_Ei)   =  kap*bet*muass*muyss^-sig*mukss^3;
  GAM0(eq_pinv, v_Emuk) =  kap*bet*muass*muyss^-sig*mukss^3;
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      12-14. Stochastic Trends                         %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_muy, v_muy) = -1;
  GAM0(eq_muy, v_mua) =  alpk/(alpk-1);
  GAM0(eq_muy, v_mux) =  1;

  GAM0(eq_muk, v_muk) = -1;
  GAM0(eq_muk, v_mua) =  1/(alpk-1);
  GAM0(eq_muk, v_mux) =  1;
  
  GAM0(eq_xg,  v_xg ) =  1;
  GAM1(eq_xg,  v_xg ) =  rhoxg;
  GAM0(eq_xg,  v_muy) =  1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      15+. Shock Processes                             %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% MUA %%
  GAM0(eq_mua,v_mua)    = 1;
  GAM1(eq_mua,v_mua)    = rhoa;
  GAM1(eq_mua,v_mua8_1) = 1;
  PSI(eq_mua,e_mua0) = 1;

  GAM0(eq_mua8_1,v_mua8_1) = 1;
  GAM1(eq_mua8_1,v_mua8_2) = 1;
  
  GAM0(eq_mua8_2,v_mua8_2) = 1;
  GAM1(eq_mua8_2,v_mua8_3) = 1;
  
  GAM0(eq_mua8_3,v_mua8_3) = 1;
  GAM1(eq_mua8_3,v_mua8_4) = 1;
  
  GAM0(eq_mua8_4,v_mua8_4) = 1;
  GAM1(eq_mua8_4,v_mua8_5) = 1;
  PSI(eq_mua8_4,e_mua4)    = 1;

  GAM0(eq_mua8_5,v_mua8_5) = 1;
  GAM1(eq_mua8_5,v_mua8_6) = 1;

  GAM0(eq_mua8_6,v_mua8_6) = 1;
  GAM1(eq_mua8_6,v_mua8_7) = 1;
  
  GAM0(eq_mua8_7,v_mua8_7) = 1;
  GAM1(eq_mua8_7,v_mua8_8) = 1;
  
  GAM0(eq_mua8_8,v_mua8_8) = 1;
  PSI(eq_mua8_8,e_mua8)    = 1;

  %% MUX %%
  GAM0(eq_mux,v_mux)    = 1;
  GAM1(eq_mux,v_mux)    = rhox-0.5;
  GAM1(eq_mux,v_mux8_1) = 1;
  PSI(eq_mux,e_mux0) = 1;

  GAM0(eq_mux8_1,v_mux8_1) = 1;	
  GAM1(eq_mux8_1,v_mux8_2) = 1;	
  			       	
  GAM0(eq_mux8_2,v_mux8_2) = 1;	
  GAM1(eq_mux8_2,v_mux8_3) = 1;	
  			       	
  GAM0(eq_mux8_3,v_mux8_3) = 1;	
  GAM1(eq_mux8_3,v_mux8_4) = 1;	
  			       	
  GAM0(eq_mux8_4,v_mux8_4) = 1;	
  GAM1(eq_mux8_4,v_mux8_5) = 1;
  PSI(eq_mux8_4,e_mux4)     = 1;

  GAM0(eq_mux8_5,v_mux8_5) = 1;
  GAM1(eq_mux8_5,v_mux8_6) = 1;

  GAM0(eq_mux8_6,v_mux8_6) = 1;
  GAM1(eq_mux8_6,v_mux8_7) = 1;
  
  GAM0(eq_mux8_7,v_mux8_7) = 1;
  GAM1(eq_mux8_7,v_mux8_8) = 1;
  
  GAM0(eq_mux8_8,v_mux8_8) = 1;
  PSI(eq_mux8_8,e_mux8)   = 1;


  %% zi %%
  GAM0(eq_zi,v_zi)    = 1;
  GAM1(eq_zi,v_zi)    = rhozi;
  GAM1(eq_zi,v_zi8_1) = 1;
  PSI(eq_zi,e_zi0) = 1;

  GAM0(eq_zi8_1,v_zi8_1) = 1;
  GAM1(eq_zi8_1,v_zi8_2) = 1;
  
  GAM0(eq_zi8_2,v_zi8_2) = 1;
  GAM1(eq_zi8_2,v_zi8_3) = 1;
  
  GAM0(eq_zi8_3,v_zi8_3) = 1;
  GAM1(eq_zi8_3,v_zi8_4) = 1;
  
  GAM0(eq_zi8_4,v_zi8_4) = 1;
  GAM1(eq_zi8_4,v_zi8_5) = 1;
  PSI(eq_zi8_4,e_zi4)     = 1;

  GAM0(eq_zi8_5,v_zi8_5) = 1;
  GAM1(eq_zi8_5,v_zi8_6) = 1;

  GAM0(eq_zi8_6,v_zi8_6) = 1;
  GAM1(eq_zi8_6,v_zi8_7) = 1;
  
  GAM0(eq_zi8_7,v_zi8_7) = 1;
  GAM1(eq_zi8_7,v_zi8_8) = 1;
  
  GAM0(eq_zi8_8,v_zi8_8) = 1;
  PSI(eq_zi8_8,e_zi8)   = 1;

  %% z %% 
  GAM0(eq_z,v_z)    = 1;
  GAM1(eq_z,v_z)    = rhoz;
  GAM1(eq_z,v_z8_1) = 1;
  PSI(eq_z,e_z0) = 1;

  GAM0(eq_z8_1,v_z8_1) = 1;
  GAM1(eq_z8_1,v_z8_2) = 1;
  
  GAM0(eq_z8_2,v_z8_2) = 1;
  GAM1(eq_z8_2,v_z8_3) = 1;
  
  GAM0(eq_z8_3,v_z8_3) = 1;
  GAM1(eq_z8_3,v_z8_4) = 1;
  
  GAM0(eq_z8_4,v_z8_4) = 1;
  GAM1(eq_z8_4,v_z8_5) = 1;
  PSI(eq_z8_4,e_z4)     = 1;

  GAM0(eq_z8_5,v_z8_5) = 1;
  GAM1(eq_z8_5,v_z8_6) = 1;

  GAM0(eq_z8_6,v_z8_6) = 1;
  GAM1(eq_z8_6,v_z8_7) = 1;
  
  GAM0(eq_z8_7,v_z8_7) = 1;
  GAM1(eq_z8_7,v_z8_8) = 1;
  
  GAM0(eq_z8_8,v_z8_8) = 1;
  PSI(eq_z8_8,e_z8)   = 1;

  %% mu %%
  GAM0(eq_mu,v_mu)    = 1;
  GAM1(eq_mu,v_mu)    = rhom;
  GAM1(eq_mu,v_mu8_1) = 1;
  PSI(eq_mu,e_mu0) = 1;

  GAM0(eq_mu8_1,v_mu8_1) = 1;
  GAM1(eq_mu8_1,v_mu8_2) = 1;
  
  GAM0(eq_mu8_2,v_mu8_2) = 1;
  GAM1(eq_mu8_2,v_mu8_3) = 1;
  
  GAM0(eq_mu8_3,v_mu8_3) = 1;
  GAM1(eq_mu8_3,v_mu8_4) = 1;
  
  GAM0(eq_mu8_4,v_mu8_4) = 1;
  GAM1(eq_mu8_4,v_mu8_5) = 1;
  PSI(eq_mu8_4,e_mu4)     = 1;

  GAM0(eq_mu8_5,v_mu8_5) = 1;
  GAM1(eq_mu8_5,v_mu8_6) = 1;

  GAM0(eq_mu8_6,v_mu8_6) = 1;
  GAM1(eq_mu8_6,v_mu8_7) = 1;
  
  GAM0(eq_mu8_7,v_mu8_7) = 1;
  GAM1(eq_mu8_7,v_mu8_8) = 1;
  
  GAM0(eq_mu8_8,v_mu8_8) = 1;
  PSI(eq_mu8_8,e_mu8)   = 1;

  %% g %%
  GAM0(eq_g,v_g)    = 1;
  GAM1(eq_g,v_g)    = rhog;
  GAM1(eq_g,v_g8_1) = 1;
  PSI(eq_g,e_g0)    = 1;

  GAM0(eq_g8_1,v_g8_1) = 1;
  GAM1(eq_g8_1,v_g8_2) = 1;
  
  GAM0(eq_g8_2,v_g8_2) = 1;
  GAM1(eq_g8_2,v_g8_3) = 1;
  
  GAM0(eq_g8_3,v_g8_3) = 1;
  GAM1(eq_g8_3,v_g8_4) = 1;
  
  GAM0(eq_g8_4,v_g8_4) = 1;
  GAM1(eq_g8_4,v_g8_5) = 1;
  PSI(eq_g8_4,e_g4)     = 1;

  GAM0(eq_g8_5,v_g8_5) = 1;
  GAM1(eq_g8_5,v_g8_6) = 1;

  GAM0(eq_g8_6,v_g8_6) = 1;
  GAM1(eq_g8_6,v_g8_7) = 1;
  
  GAM0(eq_g8_7,v_g8_7) = 1;
  GAM1(eq_g8_7,v_g8_8) = 1;
  
  GAM0(eq_g8_8,v_g8_8) = 1;
  PSI(eq_g8_8,e_g8)   = 1;

  %% zet %%
  GAM0(eq_zet,v_zet)    = 1;
  GAM1(eq_zet,v_zet)    = rhozet;
  GAM1(eq_zet,v_zet8_1) = 1;
  PSI(eq_zet,e_zet0) = 1;

  GAM0(eq_zet8_1,v_zet8_1) = 1;
  GAM1(eq_zet8_1,v_zet8_2) = 1;
  
  GAM0(eq_zet8_2,v_zet8_2) = 1;
  GAM1(eq_zet8_2,v_zet8_3) = 1;
  
  GAM0(eq_zet8_3,v_zet8_3) = 1;
  GAM1(eq_zet8_3,v_zet8_4) = 1;
  
  GAM0(eq_zet8_4,v_zet8_4) = 1;
  GAM1(eq_zet8_4,v_zet8_5) = 1;
  PSI(eq_zet8_4,e_zet4)     = 1;

  GAM0(eq_zet8_5,v_zet8_5) = 1;
  GAM1(eq_zet8_5,v_zet8_6) = 1;

  GAM0(eq_zet8_6,v_zet8_6) = 1;
  GAM1(eq_zet8_6,v_zet8_7) = 1;
  
  GAM0(eq_zet8_7,v_zet8_7) = 1;
  GAM1(eq_zet8_7,v_zet8_8) = 1;
  
  GAM0(eq_zet8_8,v_zet8_8) = 1;
  PSI(eq_zet8_8,e_zet8)   = 1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      7. Euler Equation                                %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_Elam, v_lam)  = 1;
  GAM1(eq_Elam, v_Elam) = 1;
  PPI(eq_Elam, sh_Elam) = 1;

  GAM0(eq_Emuy, v_muy)  = 1;
  GAM1(eq_Emuy, v_Emuy) = 1;
  PPI(eq_Emuy, sh_Emuy) = 1;
  
  GAM0(eq_Emuk, v_muk)  = 1;
  GAM1(eq_Emuk, v_Emuk) = 1;
  PPI(eq_Emuk, sh_Emuk) = 1;

  GAM0(eq_Ei, v_i)  = 1;
  GAM1(eq_Ei, v_Ei) = 1;
  PPI(eq_Ei, sh_Ei) = 1;

  GAM0(eq_Eu, v_u)  = 1;
  GAM1(eq_Eu, v_Eu) = 1;
  PPI(eq_Eu, sh_Eu) = 1;

  GAM0(eq_Ez, v_z)  = 1;
  GAM1(eq_Ez, v_Ez) = 1;
  PPI(eq_Ez, sh_Ez) = 1;

  GAM0(eq_Eh, v_h)  = 1;
  GAM1(eq_Eh, v_Eh) = 1;
  PPI(eq_Eh, sh_Eh) = 1;

  GAM0(eq_Emua, v_mua)  = 1;
  GAM1(eq_Emua, v_Emua) = 1;
  PPI(eq_Emua, sh_Emua) = 1;

  GAM0(eq_Eh, v_h)  = 1;
  GAM1(eq_Eh, v_Eh) = 1;
  PPI(eq_Eh, sh_Eh) = 1;

  GAM0(eq_Eq, v_q)  = 1;
  GAM1(eq_Eq, v_Eq) = 1;
  PPI(eq_Eq, sh_Eq) = 1;

  GAM0(eq_Ep, v_p)  = 1;
  GAM1(eq_Ep, v_Ep) = 1;
  PPI(eq_Ep, sh_Ep) = 1;

  GAM0(eq_Es, v_s)  = 1;
  GAM1(eq_Es, v_Es) = 1;
  PPI(eq_Es, sh_Es) = 1;

  GAM0(eq_Ezet, v_zet)  = 1;
  GAM1(eq_Ezet, v_Ezet) = 1;
  PPI(eq_Ezet, sh_Ezet) = 1;

  GAM0(eq_Ec, v_c)  = 1;
  GAM1(eq_Ec, v_Ec) = 1;
  PPI(eq_Ec, sh_Ec) = 1;

  GAM0(eq_Ev, v_v)  = 1;
  GAM1(eq_Ev, v_Ev) = 1;
  PPI(eq_Ev, sh_Ev) = 1;

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%      42-46. Lags                                      %%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  GAM0(eq_ylag, v_ylag) = 1;
  GAM1(eq_ylag, v_y)    = 1;

  GAM0(eq_clag, v_clag) = 1;
  GAM1(eq_clag, v_c)    = 1;
  
  GAM0(eq_ilag, v_ilag) = 1;
  GAM1(eq_ilag, v_i)    = 1;
  
  GAM0(eq_glag, v_glag) = 1;
  GAM1(eq_glag, v_g)    = 1;
    
  GAM0(eq_xglag, v_xglag) = 1;
  GAM1(eq_xglag, v_xg)    = 1;

  GAM0(eq_hlag, v_hlag) = 1;
  GAM1(eq_hlag, v_h)    = 1;

  GAM0(eq_zlag, v_zlag) = 1;
  GAM1(eq_zlag, v_z)    = 1; 

  [T1,TC,T0,TY,M,TZ,GEV,RC] = gensys(GAM0,GAM1,C,PSI,PPI,1);

  VSEL = [];%get_VSEL(GAM0, GAM1, PPI);
 
  varargout{1} = T1;
  varargout{2} = TC;
  varargout{3} = T0;
  varargout{4} = VSEL;
  varargout{5} = RC;
  varargout{6} = GAM0;
  varargout{7} = GAM1;
  varargout{8} = C;
  varargout{9} = PSI;

end


% $$$ function VSEL = get_VSEL (GAM0, GAM1, PPI);
% $$$    
% $$$    ns = rows(GAM0);
% $$$    [eq_Ev, ~] = find (PPI);
% $$$    
% $$$    m = GAM0 (eq_Ev, :) .* repmat(1:ns, size (eq_Ev));
% $$$    m = m'(:);
% $$$    m = m( m > 0);
% $$$    
% $$$    Em = GAM1 (eq_Ev, :) .* repmat(1:ns, size (eq_Ev));
% $$$    Em = Em'(:);
% $$$    Em = Em( Em > 0);
% $$$    
% $$$    VSEL = [Em, m, eq_Ev];
% $$$ endfunction

